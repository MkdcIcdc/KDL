import asyncpg # для работы с базой данных postresql в асинхронном режиме
import asyncio
import json # для работы с json-объектами
from datetime import datetime
# import pickle # для преобразования объектов python в строки и обратно

# устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения
async def connect_db_async(param_db):
    """
    Асинхронно устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения.

    Аргументы:
        param_db (dict): Словарь с параметрами подключения, включающий:
            - host (str): Адрес сервера базы данных;
            - port (int): Порт сервера базы данных;
            - database (str): Имя базы данных;
            - user (str): Имя пользователя для доступа к базе данных;
            - password (str): Пароль пользователя;

    Результат:
        asyncpg.connection: Объект соединения с базой данных.

    Обработка ошибок:
        Exception: В случае ошибки подключения, сообщение об ошибке будет содержаться в исключении.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres'}
        >>> conn = await database_async.connect_db_async(param_db) # получаем объект соединения с базой данных
        >>> await conn.close()
    """
    conn = None
    try:
        conn = await asyncpg.connect(
            host = param_db['host'],
            port = param_db['port'],
            database = param_db['database'],
            user = param_db['user'],
            password = param_db['password'],
        )
        
        # await conn.execute("SELECT NOW()") # тестовый запрос у базы текущего времени, чтобы атрибут server_version стао доступен
        
    except asyncpg.PostgresError as e:
        print(f"function connect_db_async(): Возникла Ошибка при подключении к базе данных: {e}")
    
    return conn

# получение данных из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса
async def get_data_async(param_db, query, arg=None):
    """
    Получает данные из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции connect_db_async().
        query (str): SQL-запрос для извлечения данных.
        arg - параметры передаваемые в запрос

    Результат:
        list: Список словарей, где каждый представляет строку результата запроса.
        Возвращает пустой список в случае ошибки.

    Обработка ошибок:
        В случае ошибок подключения/выполнения запроса, сообщение об ошибке будет в исключении.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres'}
        >>> query = "SELECT id, name FROM State"
        >>> data = await database_async.get_data_async(param_db, query)
        >>> print(f"data = {data}")
        data = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    conn = None
    result = []
    try:
        conn = await connect_db_async(param_db)
        
        if arg:
            data = await conn.fetch(query, *arg)
        else:
            data = await conn.fetch(query)
        
        result = [dict(row) for row in data]
    
    except asyncpg.PostgresError as e: # если возникла ошибка при запросе к базе
        print(f"function get_data_async(): Возникла ошибка при работе с базой данных {e}")
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result

# получение списка всех состояний из таблицы 'State' базы данных
async def get_states_async(param_db):
    """
    Получает список всех состояний из таблицы 'State' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый представляет наименование состояния с ключами 'id' и 'name'.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> states = await database_async.get_states_async(param_db)
        >>> print(f"states = {states}")
        states = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    query = "SELECT id, name FROM State"
    
    try:
        result = await get_data_async(param_db, query)
        
    except asyncpg.PostgresError as e:
        print(f"function get_states_async(): Возникла ошибка при попытке запроса состояний у базы данных {e}")
        result = []
    
    return result

# получение списка всех выводов по состояниям из таблицы 'Consectary' базы данных
async def get_consectarys_async(param_db):
    """
    Получает список всех выводов по состояним из таблицы 'Consectary' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет наменование состояния с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> consectarys = await database_async.get_consectarys_async(param_db)
        >>> print(f"consectary = {consectary}")
        consectary = [{'id': 1, 'name': 'Дисфункция миокарда'}, {'id': 2, 'name': 'Стрессовая реакция'}]
    """
    
    query = "SELECT id, name FROM Consectary"
    
    try:
        result = await get_data_async(param_db, query)
        
    except asyncpg.PostgresError as e:
        print(f"function get_consectarys_async(): При попытке запроса выводов по состояним из базы данных возникла ошибка: {e}")
        result = []
    
    return result

# получение списка наименования всех параметров из таблицы 'Parameter' базы данных
async def get_parameters_async(param_db):
    """
    Получает список наименования всех параметров из таблицы 'Parameter' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет параметр с ключами 'id' и 'name'.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> parameters = await database_async.get_parameters_async(param_db)
        >>> print(f"parameters = {parameters}")
        parameters = [{'id': 1, 'name': 'Креатинин'}, {'id': 3, 'name': 'Мочевина'}]
    """
    query = "SELECT id, name FROM Parameter"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_parameters_async(): Возникла ошибка при попытке запроса наименований параметров у базы данных {e}")
        result = []
    
    return result

# получение списка наименования всех единиц измерения отклонений из таблицы 'TOD' базы данных
async def get_tods_async(param_db):
    """
    Получает список наименования всех единиц измерения параметров из таблицы 'TOD' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет единицу измерения с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> parameters = await database.get_tods_async(param_db)
        >>> print(f"parameters = {parameters}")
        tods = [{'id': 1, 'name': 'мкмоль/л'}, {'id': 3, 'name': 'ммоль/л'}]
    """
    query = "SELECT id, name FROM TOD"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_tods_async(): Возникла ошибка при попытке запроса наименований всех единиц измерения отклонений у базы данных {e}")
        result = []
    
    return result

# получение списка всех разновидностей наименований приоритетов из таблицы 'Priority' в базе данных
async def get_prioritys_async(param_db):
    """
    Получает список всех наименований приоритетов параметров в определении состояний из таблицы 'Priority' в базе данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет приоритет с ключами 'id' и 'name'.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> prioritys = await database.get_prioritys_async(param_db)
        >>> print(f"prioritys = {prioritys}")
        prioritys = [{'id': 1, 'name': 'Основной'}, {'id': 3, 'name': 'Неосновной'}]
    """
    query = "SELECT id, name FROM Priority"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_prioritys_async(): Возникла ошибка при попытке запроса списка всех разновидностей наименований приоритетов из таблицы 'Priority' у базы данных {e}")
        result = []
    
    return result

# получение списка всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных
async def get_weights_async(param_db):
    """
    Получает список всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет значимость с ключами 'id' и 'value'.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> weights = await database.get_weights_async(param_db)
        >>> print(f"weights = {weights}")
        weights = [{'id': 1, 'value': '1'}, {'id': 2, 'value': '2'}, ..., {'id': 5, 'value': '5'}]
    """
    query = "SELECT id, value FROM Weight"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_weights_async(): Возникла ошибка при попытке запроса списка всех значений значимости (весов) отклонений из таблицы 'Weight' у базы данных {e}")
        result = []
    
    return result

# получение списка всех наименований отклонений из таблицы 'Deviation' базы данных
async def get_deviations_async(param_db):
    """
    Получает список всех наименований отклонений из таблицы 'Deviation' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет отклонение с ключами 'id' и 'name'.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> deviations = await database.get_deviations_async(param_db)
        >>> print(f"deviations = {deviations}")
        deviations = [{'id': 1, 'name': 'Повышение уровня креатинина'}, {'id': 4, 'name': 'Повышение уровня мочевой кислоты'}]
    """
    query = "SELECT id, name FROM Deviation"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_deviations_async(): Возникла ошибка при попытке запроса списка всех наименований отклонений из таблицы 'Deviation' у базы данных {e}")
        result = []
    
    return result

# получение справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
async def get_dos_async(param_db):
    """
    Получает справочные данные о зонах норм и отклонения из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый представляет запись из таблицы DOS с данными из связанных таблиц.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> dos = await database.get_dos_async(param_db)
        >>> print(f"dos = {dos}")
        dos = [{'id': 2, 'system_name': 'Иммунная система', 'organ_name': None, 'param_name': 'Ферритин', ... 'weight_name': None}]
    """
    query = """
        SELECT
            DOS.id,
            System.name AS system_name,
            Organ.name AS organ_name,
            Parameter.name AS param_name,
            State.name AS state_name,
            Consectary.name AS consectary_name,
            Rec.name AS rec_name,
            Gender.name AS gen_name,
            DOS.age_min,
            DOS.age_max,
            TOD.name AS tod_name,
            DOS.norm_min,
            DOS.norm_max,
            DOS.mod_dev_min,
            DOS.mod_dev_max,
            DOS.exp_dev_min,
            DOS.exp_dev_max,
            DOS.crit_dev_min,
            DOS.crit_dev_max,
            Deviation.name AS deviation_name,
            pos_dyn.name AS pos_dyn_name,
            neg_dyn.name AS neg_dyn_name,
            Priority.name AS priority_name,
            Weight.value AS weight_name
        FROM
            DOS
        LEFT JOIN System ON DOS.system_id = System.id
        LEFT JOIN Organ ON DOS.organ_id = Organ.id
        LEFT JOIN State ON DOS.state_id = State.id
        LEFT JOIN Consectary ON DOS.consectary_id = Consectary.id
        LEFT JOIN Rec ON DOS.rec_id = Rec.id
        LEFT JOIN Parameter ON DOS.parameter_id = Parameter.id
        LEFT JOIN Gender ON DOS.gender_id = Gender.id
        LEFT JOIN TOD ON DOS.tod_id = TOD.id
        LEFT JOIN Deviation ON DOS.deviation_id = Deviation.id
        LEFT JOIN Dynamics AS pos_dyn ON DOS.pos_dyn_id = pos_dyn.id
        LEFT JOIN Dynamics AS neg_dyn ON DOS.neg_dyn_id = neg_dyn.id
        LEFT JOIN Priority ON DOS.priority_id = Priority.id
        LEFT JOIN Weight ON DOS.weight_id = Weight.id
    """
    
    result = []
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_dos_async(): Возникла ошибка при попытке запроса справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' у базы данных {e}")
    
    return result

# получение списка всех пациентов из таблицы 'Patient' базы данных
async def get_patients_async(param_db):
    """
    Получает список всех пациентов из таблицы 'Patient' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> patients = await database.get_patients_async(param_db)
        >>> print(f"patients = {patients}")
        patients = [{'id': 7, 's_name': 'Терсинских', 'name': 'Светлана', 'surname': 'Анатольевна', ... 'gender': 'женский'}, ]
    """
    query = "SELECT id, s_name, name, surname, date_birth, p_series, p_number, snils, med_polis, medstat_id, gender FROM patient"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_patients_async(): Возникла ошибка при попытке запроса справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' у базы данных {e}")
        result = []
    
    return result

# получение списка всех исследований пациентов из таблицы 'research' базы данных
async def get_researchs_async(param_db):
    """
    Получает список всех исследований пациентов из таблицы 'research' базы данных, объединяя данные из таблиц 'research' и 'patient'.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись об исследовании с данными пациента (ФИО, дата рождения, пол и т.д.).
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> researchs = await database.get_researchs_async(param_db)
        >>> print(f"researchs = {researchs}")
        researchs = [{'id': 189, 'patient_id': 8, 'surname': 'Файзуллин', ..., 'data': 'Ca++:1,2 ммоль/л\r\nLac:3,2 ммоль/л'}, 
        {'id': 191, 'patient_id': 8, 'surname': 'Файзуллин', 'name': 'Ирек', 'middle_name': 'Энварович', ...   }]
    """
    query = """
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_researchs_async(): Возникла ошибка при попытке запроса списка всех исследований пациентов из таблицы 'research' у базы данных {e}")
        result = []
    
    return result

# получение записи конкретного исследования по указанному ID в таблице 'Research' базы данных
async def get_research_by_id_async(param_db, research_id):
    """
    Получает запись конкретного исследования по указанному ID в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().
        research_id (int): ID исследования в поле id таблицы research базы данных, по которому необходимы данные.

    Результат:
        dict: Словарь с данными об исследовании (ФИО пациента, дата рождения, пол и т.д.) или None, если запись не найдена.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> research_id = await database.get_research_by_id_async(param_db, 4)
        >>> print(f"research_id = {research_id}")
        research_id = {'id': 4, 'patient_id': 7, 'surname': 'Терсинских', 'name': 'Светлана', ... 'data': 'Д-димер:8,66 мкг/мл\r\n...Фибриноген:4,8 г/л'}
    """
    query = f"""
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE research.id = {research_id}
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_research_by_id_async(): Возникла ошибка при попытке запроса записи конкретного исследования по указанному ID в таблице 'Research' у базы данных {e}")

    # Возвращаем первую запись (если найдена), иначе None
    return result[0] if result else []

# получение списка записей исследований, по списку ID исследований в таблице 'Research' базы данных
async def get_researchs_by_list_id_async(param_db, researchs_id_list):
    """
    Получает список записей исследований, по списку ID исследований в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().
        researchs_id_list (list): Список ID исследований таблицы research базы данных, по которому необходимы данные.

    Результат:
        list: Список словарей, где каждый словарь представляет запись об исследовании с данными пациента (ФИО, дата рождения, пол и т.д.).
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> researchs_id_list = [4, 5, 6, 7, 8]
        >>> researchs_list = await database.get_researchs_by_list_id_async(param_db, researchs_id_list)
        >>> print(f"researchs_list = {researchs_list}")
    """
    if len(researchs_id_list)<=0:
        print("get_researchs_by_list_id_async(): Список id исследований пуст!")
        return None, []
    
    researchs_id_str = ', '.join([f'${i}' for i in range(1, len(researchs_id_list) + 1)])
    
    query = f"""
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM 
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE 
                patient_id IN ({researchs_id_str})
            """
    
    try:
        result = await get_data_async(param_db, query, researchs_id_list)
    
    except asyncpg.PostgresError as e:
        print(f"function get_researchs_by_list_id_async(): Возникла ошибка при попытке запроса списка записей исследований по списку их ID из таблицы 'Research' у базы данных {e}")

    # Возвращаем первую запись (если найдена), иначе None
    return result[0] if result else []

# получение списка записей исследований в день, определяемому по ID исследования в таблице 'Research' базы данных
async def get_researchs_by_date_from_id_async(param_db, research_id):
    """
    Получает список записей исследований в день, на который указывает исследование с указанным ID в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().
        research_id (int): ID исследования в поле id таблицы research базы данных, по которому необходимы данные.

    Результат:
        dict: Словарь с данными об исследовании (ФИО пациента, дата рождения, пол и т.д.) или None, если запись не найдена.
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}

    Пример:
        >>> research_id = await database.get_researchs_by_date_from_id_async(param_db, 4)
        >>> print(f"research_id = {research_id}")
        research_id = {'id': 4, 'patient_id': 7, 'surname': 'Терсинских', 'name': 'Светлана', ... 'data': 'Д-димер:8,66 мкг/мл\r\n...Фибриноген:4,8 г/л'}
    """
    result = None
    # сформируем запрос для получения id пациента и даты исследования
    query = f"""
            SELECT
                research.date AS research_date,
                research.patient_id,
                patient.date_birth AS date_birth,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE research.id = {research_id}
            """
    try:
        result = await get_data_async(param_db, query)
        
        if not result:
            print("Исследование не найдено.")
            return None, []

        # извлекаем данные из первого запроса
        research_date = result[0]['research_date']
        patient_id = result[0]['patient_id']
        date_birth = result[0]['date_birth']
        surname = result[0]['surname']
        name = result[0]['name']
        middle_name = result[0]['middle_name']
        
        # Второй запрос: получить все исследования данного пациента за указанную дату рождения
        query = f"""
                SELECT
                    research.id,
                    research.patient_id,
                    patient.s_name AS surname,
                    patient.name AS name,
                    patient.surname AS middle_name,
                    patient.gender AS gender,
                    patient.date_birth AS date_birth,
                    research.date,
                    research.data
                FROM 
                    research
                LEFT JOIN patient ON research.patient_id = patient.id
                WHERE 
                    research.patient_id = {patient_id} AND DATE_TRUNC('day', research.date) = DATE_TRUNC('day', '{research_date}'::date)
                """
        result = await get_data_async(param_db, query)
        
    except asyncpg.PostgresError as e:
        print(f"function get_researchs_by_date_from_id_async(): При попытке запроса списка исследований в заданный день по указанному ID-пациента из таблицы 'Research' базы данных возникла ошибка: {e}")
        result = None
    
    # Возвращаем первую запись (если найдена), иначе None
    return result if result else []

# получение списка всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями
async def get_conclusion_async(param_db):
    """
    Получает список всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый представляет запись о результатах интерпретации анализов.
        Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> conclusions = await database.get_conclusion_async(param_db)
        >>> print(f"conclusions = {conclusions}")
        conclusions = [{'id': 153, 'research_id': 4, 'patient_id': 7, ..., 'inter_results': '...', 'conc_text': None},]
    """
    query = """
            SELECT
                conclusion.id,
                conclusion.research_id,
                conclusion.patient_id,
                conclusion.date_create,
                conclusion.emp_id,
                conclusion.date_save,
                conclusion.inter_results,
                conclusion.conc_text
            FROM
                conclusion
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_conclusion_async(): Возникла ошибка при попытке запроса списка всех медицинских заключений из таблицы 'conclusion' у базы данных {e}")
        result = []
    
    return result

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
async def save_conclusion_async(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый interpreter.getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу или False и ошибку.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = await save_conclusion_async(param_db, id_research, id_patient, sort_states_text, state_patient)
        >>> if status: print(f"Запись успешно выполнена") else: print(f"Запись не выполнена. Ошибка: {error}")
    """
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        conn = await connect_db_async(param_db)
        tr = conn.transaction()
        
        await tr.start()
        
        # безопасный параметризированный запрос для предотвращения SQL-инъекций.
        query = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES ($1, $2, $3, $4, $5)
        """
        # inter_results_str = pickle.dumps(inter_results)
        # inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)
        
        await conn.execute(query, (research_id, patient_id, date_create, inter_results, data))
        await tr.commit() # commit выполняется автоматически внутри блока with
        result = True
    
    except asyncpg.PostgresError as e:
        print(f"save_conclusion_async(): Ошибка при сохранении в базу данных: {e}")
        await tr.rollback()
        result = False
        error = e # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result if result else result, error # возвращаем признак успешного выполнения или неуспешного и ошибку

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных с возвратом id записи.
async def save_conclusion_v2_async(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных.
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу или False и ошибку.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, result = await save_conclusion_v2_async(param_db, id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    result = None
    conn = None
    tr = None
    # date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    date_create = datetime.now().replace(second=0, microsecond=0)
    try:
        conn = await connect_db_async(param_db)
        tr = conn.transaction()
        await tr.start()
        query_insert = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES ($1, $2, $3, $4, $5) 
            RETURNING id;
        """
        record_id = await conn.fetchval(query_insert, research_id, patient_id, date_create, inter_results, data)
        await tr.commit() # commit выполняется автоматически внутри блока with
        result = True
    
    except asyncpg.PostgresError as e:
        print(f"save_conclusion_v2_async(): Ошибка при сохранении в базу данных: {e}")
        if tr:
            await tr.rollback()
        result = False
        error = e # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result, record_id if result else error  # Возвращаем признак успеха и ID записи (или результат вставки)
