import asyncpg # для работы с базой данных postresql в асинхронном режиме
import asyncio
import json # для работы с json-объектами
from datetime import datetime
# import pickle # для преобразования объектов python в строки и обратно

# устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения
async def connect_db_async(param_db):
    """
    Устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения. Выполняется асинхронно.

    Аргументы:
        param_db (dict): Словарь с параметрами подключения, включающий:
            - host (str): Адрес сервера базы данных;
            - port (int): Порт сервера базы данных;
            - database (str): Имя базы данных;
            - user (str): Имя пользователя для доступа к базе данных;
            - password (str): Пароль пользователя;

    Результат:
        asyncpg.connection: Объект соединения с базой данных.

    Обработка ошибок:
        Exception: В случае ошибки подключения, сообщение об ошибке будет содержаться в исключении.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres'}
        >>> conn = await database_async.connect_db_async(param_db) # получаем объект соединения с базой данных
        >>> await conn.close()
    """
    conn = None
    try:
        conn = await asyncpg.connect(
            host = param_db['host'],
            port = param_db['port'],
            database = param_db['database'],
            user = param_db['user'],
            password = param_db['password'],
        )
        
        # await conn.execute("SELECT NOW()") # тестовый запрос у базы текущего времени, чтобы атрибут server_version стао доступен
        
    except asyncpg.PostgresError as e:
        print(f"function connect_db_async(): Возникла Ошибка при подключении к базе данных: {e}")
    
    return conn

# получение данных из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса
async def get_data_async(param_db, query):
    """
    Получает данные из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции connect_db_async().
        query (str): SQL-запрос для извлечения данных.

    Результат:
        list: Список словарей, где каждый словарь представляет строку результата запроса. Ключи словаря - это имена столбцов из запроса.
              Возвращает пустой список в случае ошибки.

    Обработка ошибок:
        Exception: В случае ошибок подключения или выполнения запроса, сообщение об ошибке будет содержаться в исключении (если не перехвачено).

    Замечания:
        - Использует функцию connect_db_async для соединения с базой данных.
        - Результат возвращается в виде списка словарей для удобства обработки данных по именам столбцов.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres'}
        >>> query = "SELECT id, name FROM State"
        >>> data = await database_async.get_data_async(param_db, query)
        >>> print(f"data = {data}")
        data = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    conn = None
    result = []
    try:
        conn = await connect_db_async(param_db)
        data = await conn.fetch(query)
        result = [dict(row) for row in data]
    
    except asyncpg.PostgresError as e: # если возникла ошибка при запросе к базе
        print(f"function get_data_async(): Возникла ошибка при работе с базой данных {e}")
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result

# получение списка всех состояний из таблицы 'State' базы данных
async def get_states_async(param_db):
    """
    Получает список всех состояний из таблицы 'State' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет наменование состояния с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого состояния из таблицы State.

    Пример:
        >>> states = await database_async.get_states_async(param_db)
        >>> print(f"states = {states}")
        states = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    query = "SELECT id, name FROM State"
    
    try:
        result = await get_data_async(param_db, query)
        
    except asyncpg.PostgresError as e:
        print(f"function get_states_async(): Возникла ошибка при попытке запроса состояний у базы данных {e}")
        result = []
    
    return result

# получение списка наименования всех параметров из таблицы 'Parameter' базы данных
async def get_parameters_async(param_db):
    """
    Получает список наименования всех параметров из таблицы 'Parameter' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет параметр с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого параметра из таблицы Parameter.

    Пример:
        >>> parameters = await database_async.get_parameters_async(param_db)
        >>> print(f"parameters = {parameters}")
        parameters = [{'id': 1, 'name': 'Креатинин'}, {'id': 3, 'name': 'Мочевина'}]
    """
    query = "SELECT id, name FROM Parameter"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_parameters_async(): Возникла ошибка при попытке запроса наименований параметров у базы данных {e}")
        result = []
    
    return result

# получение списка наименования всех единиц измерения отклонений из таблицы 'TOD' базы данных
async def get_tods_async(param_db):
    """
    Получает список наименования всех единиц измерения параметров из таблицы 'TOD' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет еденицу измерения с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование еденицы измерения параметра из таблицы TOD.

    Пример:
        >>> parameters = await database.get_tods_async(param_db)
        >>> print(f"parameters = {parameters}")
        tods = [{'id': 1, 'name': 'мкмоль/л'}, {'id': 3, 'name': 'ммоль/л'}]
    """
    query = "SELECT id, name FROM TOD"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_tods_async(): Возникла ошибка при попытке запроса наименований всех единиц измерения отклонений у базы данных {e}")
        result = []
    
    return result

# получение списка всех разновидностей наименований приоритетов из таблицы 'Priority' в базе данных
async def get_prioritys_async(param_db):
    """
    Получает список всех разновидностей наименований приоритетов параметров в определении состояний из таблицы 'Priority' в базе данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет приоритет с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого приоритета из таблицы Priority.

    Пример:
        >>> prioritys = await database.get_prioritys_async(param_db)
        >>> print(f"prioritys = {prioritys}")
        prioritys = [{'id': 1, 'name': 'Основной'}, {'id': 3, 'name': 'Неосновной'}]
    """
    query = "SELECT id, name FROM Priority"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_prioritys_async(): Возникла ошибка при попытке запроса списка всех разновидностей наименований приоритетов из таблицы 'Priority' у базы данных {e}")
        result = []
    
    return result

# получение списка всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных
async def get_weights_async(param_db):
    """
    Получает список всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет значимость с ключами 'id' и 'value'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и значение каждого веса из таблицы Weight.

    Пример:
        >>> weights = await database.get_weights_async(param_db)
        >>> print(f"weights = {weights}")
        weights = [{'id': 1, 'value': '1'}, {'id': 2, 'value': '2'}, {'id': 3, 'value': '3'}, {'id': 4, 'value': '4'}, {'id': 5, 'value': '5'}]
    """
    query = "SELECT id, value FROM Weight"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_weights_async(): Возникла ошибка при попытке запроса списка всех значений значимости (весов) отклонений из таблицы 'Weight' у базы данных {e}")
        result = []
    
    return result

# получение списка всех наименований отклонений из таблицы 'Deviation' базы данных
async def get_deviations_async(param_db):
    """
    Получает список всех наименований отклонений из таблицы 'Deviation' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет отклонение с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого отклонения из таблицы Deviation.

    Пример:
        >>> deviations = await database.get_deviations_async(param_db)
        >>> print(f"deviations = {deviations}")
        deviations = [{'id': 1, 'name': 'Повышение уровня креатинина'}, {'id': 4, 'name': 'Повышение уровня мочевой кислоты'}]
    """
    query = "SELECT id, name FROM Deviation"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_deviations_async(): Возникла ошибка при попытке запроса списка всех наименований отклонений из таблицы 'Deviation' у базы данных {e}")
        result = []
    
    return result

# получение справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
async def get_dos_async(param_db):
    """
    Получает справочные данные о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
    Связанные таблицы 'System', 'Organ', 'Parameter', 'State', 'Gender', 'TOD', 'Deviation', 'Dynamics', 'Priority', 'Weight'

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 'system_name', 'organ_name', 'param_name', 'state_name', 'gen_name', 'age_min', 'age_max', 'tod_name', 'norm_min', 'norm_max', 'mod_dev_min', 'mod_dev_max', 'exp_dev_min', 'exp_dev_max', 'crit_dev_min', 'crit_dev_max', 'deviation_name', 'pos_dyn_name', 'neg_dyn_name', 'priority_name', 'weight_name'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения сложного SQL-запроса с множеством JOIN-ов.
        - Запрос извлекает ID, возрастные диапазоны, нормативные значения, отклонения и другую справочную информацию по параметрам и состояниям.
    
    Пример:
        >>> dos = await database.get_dos_async(param_db)
        >>> print(f"dos = {dos}")
        dos = [{'id': 2, 'system_name': 'Иммунная система', 'organ_name': None, 'param_name': 'Ферритин', ... 'weight_name': None}]
    """
    query = """
        SELECT
            DOS.id,
            System.name AS system_name,
            Organ.name AS organ_name,
            Parameter.name AS param_name,
            State.name AS state_name,
            Rec.name AS rec_name,
            Gender.name AS gen_name,
            DOS.age_min,
            DOS.age_max,
            TOD.name AS tod_name,
            DOS.norm_min,
            DOS.norm_max,
            DOS.mod_dev_min,
            DOS.mod_dev_max,
            DOS.exp_dev_min,
            DOS.exp_dev_max,
            DOS.crit_dev_min,
            DOS.crit_dev_max,
            Deviation.name AS deviation_name,
            pos_dyn.name AS pos_dyn_name,
            neg_dyn.name AS neg_dyn_name,
            Priority.name AS priority_name,
            Weight.value AS weight_name
        FROM
            DOS
        LEFT JOIN System ON DOS.system_id = System.id
        LEFT JOIN Organ ON DOS.organ_id = Organ.id
        LEFT JOIN State ON DOS.state_id = State.id
        LEFT JOIN Rec ON DOS.rec_id = Rec.id
        LEFT JOIN Parameter ON DOS.parameter_id = Parameter.id
        LEFT JOIN Gender ON DOS.gender_id = Gender.id
        LEFT JOIN TOD ON DOS.tod_id = TOD.id
        LEFT JOIN Deviation ON DOS.deviation_id = Deviation.id
        LEFT JOIN Dynamics AS pos_dyn ON DOS.pos_dyn_id = pos_dyn.id
        LEFT JOIN Dynamics AS neg_dyn ON DOS.neg_dyn_id = neg_dyn.id
        LEFT JOIN Priority ON DOS.priority_id = Priority.id
        LEFT JOIN Weight ON DOS.weight_id = Weight.id
    """
    
    result = []
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_dos_async(): Возникла ошибка при попытке запроса справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' у базы данных {e}")
    
    return result

# получение списка всех пациентов из таблицы 'Patient' базы данных
async def get_patients_async(param_db):
    """
    Получает список всех пациентов из таблицы 'Patient' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 's_name', 'name', 'surname', 'date_birth', 'p_series', 'p_number', 'snils', 'med_polis', 'medstat_id', 'gender'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.
        - Запрос извлекает ID, ФИО (включая отчество или второе имя), дату рождения, контактные данные, информацию о страховании, медицинский статус и пол пациентов.

    Пример:
        >>> patients = await database.get_patients_async(param_db)
        >>> print(f"patients = {patients}")
        patients = [{'id': 7, 's_name': 'Терсинских', 'name': 'Светлана', 'surname': 'Анатольевна', ... 'gender': 'женский'}, ]
    """
    query = "SELECT id, s_name, name, surname, date_birth, p_series, p_number, snils, med_polis, medstat_id, gender FROM patient"
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_patients_async(): Возникла ошибка при попытке запроса справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' у базы данных {e}")
        result = []
    
    return result

# получение списка всех исследований пациентов из таблицы 'research' базы данных
async def get_researchs_async(param_db):
    """
    Получает списка всех исследований пациентов из таблицы 'research' базы данных, объединяя данные из таблиц 'research' и 'patient'.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись об исследовании с данными пациента (ФИО, дата рождения, пол и т.д.).
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Запрос извлекает ID исследования, идентификатор пациента, ФИО пациента (в формате Фамилия Имя Отчество/Второе имя), пол, дату рождения, дату проведения исследования и данные результататов.
        - Структура возвращаемых данных включают столбцы из обеих таблиц - research и patient.

    Пример:
        >>> researchs = await database.get_researchs_async(param_db)
        >>> print(f"researchs = {researchs}")
        researchs = [{'id': 189, 'patient_id': 8, 'surname': 'Файзуллин', 'name': 'Ирек', 'middle_name': 'Энварович', 'gender': 'мужской', 'date_birth': datetime.date(1962, 12, 8), 'date': datetime.date(2024, 8, 20), 'data': 'Ca++:1,2 ммоль/л\r\nLac:3,2 ммоль/л'}, 
        {'id': 191, 'patient_id': 8, 'surname': 'Файзуллин', 'name': 'Ирек', 'middle_name': 'Энварович', 'gender': 'мужской', 'date_birth': datetime.date(1962, 12, 8), 'date': datetime.date(2024, 8, 20), 'data': 'Амплитуда  АДФ-индуцированной агрегации:33,4 %\r\nПротеин С:96 %\r\nФибриноген:3,4 г/л\r\nАнтитромбин III:96 %\r\nПротромбиновое время:10,4 сек.\r\nПротромбин по Квику:121 %\r\nМНО:0,88  \r\nД-димер:0,23 мкг/мл\r\nАЧТВ:29,8 сек.'}]
    """
    query = """
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_researchs_async(): Возникла ошибка при попытке запроса списка всех исследований пациентов из таблицы 'research' у базы данных {e}")
        result = []
    
    return result

# получение записи конкретного исследования по указанному ID в таблице 'Research' базы данных
async def get_research_by_id_async(param_db, research_id):
    """
    Получает запись конкретного исследования по указанному ID в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().
        research_id (int): ID исследования в поле id таблицы research базы данных, по которому необходимы данные.

    Результат:
        dict: Словарь с данными об исследовании (ФИО пациента, дата рождения, пол и т.д.) или None, если запись не найдена.
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}

    Замечания:
        - Запрос извлекает те же поля, что и в get_researchs, но возвращает только одну запись на основе ID.

    Пример:
        >>> research_id = await database.get_research_by_id_async(param_db, 4)
        >>> print(f"research_id = {research_id}")
        research_id = {'id': 4, 'patient_id': 7, 'surname': 'Терсинских', 'name': 'Светлана', ... 'data': 'Д-димер:8,66 мкг/мл\r\n...Фибриноген:4,8 г/л'}
    """
    query = f"""
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE research.id = {research_id}
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_research_by_id_async(): Возникла ошибка при попытке запроса записи конкретного исследования по указанному ID в таблице 'Research' у базы данных {e}")

    # Возвращаем первую запись (если найдена), иначе None
    return result[0] if result else []

# получение списка всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями
async def get_conclusion_async(param_db):
    """
    Получает список всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().

    Результат:
        list: Список словарей, где каждый словарь представляет запись о заключении с данными идентификаторов записи (id), исследования (research_id), пациента (patient_id), даты создания (date_create), сотруднике (emp_id), результатах анализов (inter_results) и тексте заключения (conc_text).
              Ключи словаря соответствуют названиям столбцов в таблице conclusion в следующем виде:
              {'id', 'research_id', 'patient_id', 'date_create', 'emp_id', 'date_save', 'inter_results', 'conc_text'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data_async для выполнения запроса к базе данных.

    Пример:
        >>> conclusions = await database.get_conclusion_async(param_db)
        >>> print(f"conclusions = {conclusions}")
        conclusions = [{'id': 153, 'research_id': 4, 'patient_id': 7, 'date_create': datetime.datetime(2025, 9, 5, 16, 7, 5), 'emp_id': None, 'date_save': None, 'inter_results': '...', 'conc_text': None},]
    """
    query = """
            SELECT
                conclusion.id,
                conclusion.research_id,
                conclusion.patient_id,
                conclusion.date_create,
                conclusion.emp_id,
                conclusion.date_save,
                conclusion.inter_results,
                conclusion.conc_text
            FROM
                conclusion
            """
    
    try:
        result = await get_data_async(param_db, query)
    
    except asyncpg.PostgresError as e:
        print(f"function get_conclusion_async(): Возникла ошибка при попытке запроса списка всех медицинских заключений из таблицы 'conclusion' у базы данных {e}")
        result = []
    
    return result

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
async def save_conclusion_async(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Замечания:
        - В случае ошибки происходит rollback транзакции, и сообщение об ошибке выводится в лог.
        - При включенном режиме отладки выводятся значения параметров и SQL-запрос для проверки.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = await save_conclusion_async(param_db, id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        conn = await connect_db_async(param_db)
        tr = conn.transaction()
        
        await tr.start()
        
        # безопасный параметризированный запрос для предотвращения SQL-инъекций.
        query = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES ($1, $2, $3, $4, $5)
        """
        # inter_results_str = pickle.dumps(inter_results)
        # inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)
        
        await conn.execute(query, (research_id, patient_id, date_create, inter_results, data))
        await tr.commit() # commit выполняется автоматически внутри блока with
        result = True
    
    except asyncpg.PostgresError as e:
        print(f"save_conclusion_async(): Ошибка при сохранении в базу данных: {e}")
        await tr.rollback()
        result = False
        error = e # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result if result else result, error # возвращаем признак успешного выполнения или неуспешного и ошибку

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных с возвратом id записи.
async def save_conclusion_v2_async(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data_async().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Замечания:
        - В случае ошибки происходит rollback транзакции, и сообщение об ошибке выводится в лог.
        - При включенном режиме отладки выводятся значения параметров и SQL-запрос для проверки.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, result = await save_conclusion_v2_async(param_db, id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    result = None
    conn = None
    tr = None
    # date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    date_create = datetime.now().replace(second=0, microsecond=0)
    try:
        conn = await connect_db_async(param_db)
        tr = conn.transaction()
        await tr.start()
        query_insert = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES ($1, $2, $3, $4, $5) 
            RETURNING id;
        """
        record_id = await conn.fetchval(query_insert, research_id, patient_id, date_create, inter_results, data)
        await tr.commit() # commit выполняется автоматически внутри блока with
        result = True
    
    except asyncpg.PostgresError as e:
        print(f"save_conclusion_v2_async(): Ошибка при сохранении в базу данных: {e}")
        if tr:
            await tr.rollback()
        result = False
        error = e # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if conn:
            await conn.close()
    
    return result, record_id if result else error  # Возвращаем признак успеха и ID записи (или результат вставки)
