import psycopg2 # для работы с базой данных postresql
import json # для работы с json-объектами
from datetime import datetime
# import pickle # для преобразования объектов python в строки и обратно

# устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения
def connect_db(param_db):
    """
    Устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения.

    Аргументы:
        param_db (dict): Словарь с параметрами подключения, включающий:
            - host (str): Адрес сервера базы данных;
            - port (int): Порт сервера базы данных;
            - database (str): Имя базы данных;
            - user (str): Имя пользователя для доступа к базе данных;
            - password (str): Пароль пользователя;
            - client_encoding (str): Кодировка клиентского соединения.

    Результат:
        psycopg2.extensions.connection: Объект соединения с базой данных.

    Обработка ошибок:
        Exception: В случае ошибки подключения, сообщение об ошибке будет содержаться в исключении.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres', 'client_encoding':'utf8'}
        >>> conn = connect_db(param_db) # получаем объект соединения с базой данных
    """
    conn = psycopg2.connect(
        host = param_db['host'],
        port = param_db['port'],
        database = param_db['database'],
        user = param_db['user'],
        password = param_db['password'],
        client_encoding = param_db['client_encoding']
    )
    return conn

# получение данных из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса
def get_data(param_db, query):
    """
    Получает данные из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции connect_db().
        query (str): SQL-запрос для извлечения данных.

    Результат:
        list: Список словарей, где каждый словарь представляет строку результата запроса. Ключи словаря - это имена столбцов из запроса.
              Возвращает пустой список в случае ошибки.

    Обработка ошибок:
        Exception: В случае ошибок подключения или выполнения запроса, сообщение об ошибке будет содержаться в исключении (если не перехвачено).

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres', 'client_encoding':'utf8'}
        >>> query = "SELECT id, name FROM State"
        >>> states = get_data(param_db, query)
    """
    conn = connect_db(param_db)
    cur = conn.cursor()
    
    try:
        cur.execute(query)
        data = cur.fetchall()
        columns = [desc[0] for desc in cur.description]
        result = [dict(zip(columns, row)) for row in data]
    except psycopg2.Error as e: # если возникла ошибка при запросе к базе
        print(f"Ошибка базы данных: {e}")
        result = []  # возвращаем пустой список результатов

    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        cur.close()
        conn.close()
    
    return result

# получение списка всех состояний из таблицы 'State' базы данных
def get_states(param_db):
    """
    Получает список всех состояний из таблицы 'State' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет наменование состояния с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> states = database.get_states(param_db)
    """
    query = "SELECT id, name FROM State"
    
    return get_data(param_db, query)

# получение списка наименования всех параметров из таблицы 'Parameter' базы данных
def get_parameters(param_db):
    """
    Получает список наименования всех параметров из таблицы 'Parameter' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет параметр с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> parameters = database.get_parameters(param_db)
    """
    query = "SELECT id, name FROM Parameter"
    
    return get_data(param_db, query)

# получение списка наименования всех единиц измерения отклонений из таблицы 'TOD' базы данных
def get_tods(param_db):
    """
    Получает список наименования всех единиц измерения параметров из таблицы 'TOD' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет еденицу измерения с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> tods = database.get_tods(param_db)
    """
    query = "SELECT id, name FROM TOD"
    
    return get_data(param_db, query)

# получение списка всех разновидностей наименований приоритетов из таблицы 'Priority' в базе данных
def get_prioritys(param_db):
    """
    Получает список всех разновидностей наименований приоритетов параметров в определении состояний из таблицы 'Priority' в базе данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет приоритет с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> prioritys = database.get_prioritys(param_db)
    """
    query = "SELECT id, name FROM Priority"
    
    return get_data(param_db, query)

# получение списка всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных
def get_weights(param_db):
    """
    Получает список всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет значимость с ключами 'id' и 'value'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> weights = database.get_weights(param_db)
    """
    query = "SELECT id, value FROM Weight"
    
    return get_data(param_db, query)

# получение списка всех наименований отклонений из таблицы 'Deviation' базы данных
def get_deviations(param_db):
    """
    Получает список всех наименований отклонений из таблицы 'Deviation' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет отклонение с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> deviations = database.get_deviations(param_db)
    """
    query = "SELECT id, name FROM Deviation"
    
    return get_data(param_db, query)

# получение справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
def get_dos(param_db):
    """
    Получает справочные данные о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
    Связанные таблицы 'System', 'Organ', 'Parameter', 'State', 'Gender', 'TOD', 'Deviation', 'Dynamics', 'Priority', 'Weight'

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет запись из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 'system_name', 'organ_name', 'param_name', 'state_name', 'gen_name', 'age_min', 'age_max', 'tod_name', 'norm_min', 'norm_max', 'mod_dev_min', 'mod_dev_max', 'exp_dev_min', 'exp_dev_max', 'crit_dev_min', 'crit_dev_max', 'deviation_name', 'pos_dyn_name', 'neg_dyn_name', 'priority_name', 'weight_name'}
              Возвращает пустой список, если не удается получить данные.
    
    Пример:
        >>> dos = database.get_dos(param_db)
    """
    query = """
        SELECT
            DOS.id,
            System.name AS system_name,
            Organ.name AS organ_name,
            Parameter.name AS param_name,
            State.name AS state_name,
            Rec.name AS rec_name,
            Gender.name AS gen_name,
            DOS.age_min,
            DOS.age_max,
            TOD.name AS tod_name,
            DOS.norm_min,
            DOS.norm_max,
            DOS.mod_dev_min,
            DOS.mod_dev_max,
            DOS.exp_dev_min,
            DOS.exp_dev_max,
            DOS.crit_dev_min,
            DOS.crit_dev_max,
            Deviation.name AS deviation_name,
            pos_dyn.name AS pos_dyn_name,
            neg_dyn.name AS neg_dyn_name,
            Priority.name AS priority_name,
            Weight.value AS weight_name
        FROM
            DOS
        LEFT JOIN System ON DOS.system_id = System.id
        LEFT JOIN Organ ON DOS.organ_id = Organ.id
        LEFT JOIN State ON DOS.state_id = State.id
        LEFT JOIN Rec ON DOS.rec_id = Rec.id
        LEFT JOIN Parameter ON DOS.parameter_id = Parameter.id
        LEFT JOIN Gender ON DOS.gender_id = Gender.id
        LEFT JOIN TOD ON DOS.tod_id = TOD.id
        LEFT JOIN Deviation ON DOS.deviation_id = Deviation.id
        LEFT JOIN Dynamics AS pos_dyn ON DOS.pos_dyn_id = pos_dyn.id
        LEFT JOIN Dynamics AS neg_dyn ON DOS.neg_dyn_id = neg_dyn.id
        LEFT JOIN Priority ON DOS.priority_id = Priority.id
        LEFT JOIN Weight ON DOS.weight_id = Weight.id
    """
    
    return get_data(param_db, query)

# получение списка всех пациентов из таблицы 'Patient' базы данных
def get_patients(param_db):
    """
    Получает список всех пациентов из таблицы 'Patient' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 's_name', 'name', 'surname', 'date_birth', 'p_series', 'p_number', 'snils', 'med_polis', 'medstat_id', 'gender'}
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> patients = database.get_patients(param_db)
    """
    query = "SELECT id, s_name, name, surname, date_birth, p_series, p_number, snils, med_polis, medstat_id, gender FROM patient"
    
    return get_data(param_db, query)

# получение списка всех исследований пациентов из таблицы 'research' базы данных
def get_researchs(param_db):
    """
    Получает списка всех исследований пациентов из таблицы 'research' базы данных, объединяя данные из таблиц 'research' и 'patient'.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет запись об исследовании с данными пациента (ФИО, дата рождения, пол и т.д.).
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> researchs = database.get_researchs(param_db)
    """
    query = """
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            """
    
    return get_data(param_db, query)

# получение записи конкретного исследования по указанному ID в таблице 'Research' базы данных
def get_research_by_id(param_db, research_id):
    """
    Получает запись конкретного исследования по указанному ID в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): ID исследования в поле id таблицы research базы данных, по которому необходимы данные.

    Результат:
        dict: Словарь с данными об исследовании (ФИО пациента, дата рождения, пол и т.д.) или None, если запись не найдена.
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}

    Пример:
        >>> research_id = database.get_research_by_id(param_db, 4)
    """
    query = f"""
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE research.id = {research_id}
            """

    result = get_data(param_db, query)

    # Возвращаем первую запись (если найдена), иначе None
    return result[0] if result else None

# получение списка всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями
def get_conclusion(param_db):
    """
    Получает список всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().

    Результат:
        list: Список словарей, где каждый словарь представляет запись о заключении с данными идентификаторов записи (id), исследования (research_id), пациента (patient_id), даты создания (date_create), сотруднике (emp_id), результатах анализов (inter_results) и тексте заключения (conc_text).
              Ключи словаря соответствуют названиям столбцов в таблице conclusion в следующем виде:
              {'id', 'research_id', 'patient_id', 'date_create', 'emp_id', 'date_save', 'inter_results', 'conc_text'}
              Возвращает пустой список, если не удается получить данные.

    Пример:
        >>> conclusions = database.get_conclusion(param_db)
    """
    query = """
            SELECT
                conclusion.id,
                conclusion.research_id,
                conclusion.patient_id,
                conclusion.date_create,
                conclusion.emp_id,
                conclusion.date_save,
                conclusion.inter_results,
                conclusion.conc_text
            FROM
                conclusion
            """
    
    return get_data(param_db, query)

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
def save_conclusion(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = save_conclusion(param_db, id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    conn = connect_db(param_db)
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        # безопасный параметризированный запрос для предотвращения SQL-инъекций.
        query = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES (%s, %s, %s, %s, %s)
        """
        # inter_results_str = pickle.dumps(inter_results)
        inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)
        
        with conn.cursor() as cur:  # Используем with statement для автоматического управления курсором
            cur.execute(query, (research_id, patient_id, date_create, inter_results, data))
            # cur.execute(query, (research_id, patient_id, date_create, inter_results_json, data))
            # cur.execute(query, (research_id, patient_id, date_create, inter_results_json, str(data)))
            # cur.execute(query, (research_id, patient_id, date_create, str(inter_results), str(data)))
            conn.commit() # commit выполняется автоматически внутри блока with
        
    except psycopg2.Error as e:
        print(f"save_conclusion(): Ошибка при сохранении в базу данных: {e}")
        conn.rollback()
        return False, str(e) # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    return True  # возвращаем признак успешного выполнения

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных с возвратом id записи.
def save_conclusion_v2(param_db, research_id, patient_id, inter_results, data):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = save_conclusion(id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        conn = connect_db(param_db)
        # Безопасный параметризированный запрос для вставки данных
        query_insert = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES (%s, %s, %s, %s, %s) RETURNING id;
        """
        # inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)

        # Выполнение вставки и получение ID последней записи (может быть ненадежным в параллельной среде)
        with conn.cursor() as cur:
            cur.execute(query_insert, (research_id, patient_id, date_create, inter_results, data))
            conn.commit()
            result = cur.fetchone()[0]  # Получаем ID из результата

        # Поиск записи по research_id, patient_id и date_create (может вернуть несколько записей, если не уникально)
        query_select = """
            SELECT id FROM Conclusion 
            WHERE research_id = %s AND patient_id = %s AND date_create = %s;
        """
        with conn.cursor() as cur:
            cur.execute(query_select, (research_id, patient_id, date_create))
            found_record = cur.fetchone()  # Возвращает одну запись или None

            if found_record:
                record_id = found_record[0]
            else:
                record_id = None
                print("save_conclusion_v2(): Запись не найдена по заданным критериям.")

    except psycopg2.Error as e:
        print(f"save_conclusion_v2(): Ошибка при сохранении или поиске в базе данных: {e}")
        conn.rollback()
        return False, None  # Возвращаем признак неуспешного выполнения и None для ID

    finally:
        if conn:
            conn.close()

    return True, record_id if found_record else result  # Возвращаем признак успеха и ID записи (или результат вставки)