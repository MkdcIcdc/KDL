import psycopg2 # для работы с базой данных postresql
import json # для работы с json-объектами
from datetime import datetime
# import pickle # для преобразования объектов python в строки и обратно

# устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения
def connect_db(param_db, debug=False):
    """
    Устанавливает соединение с базой данных PostgreSQL используя заданные параметры для подключения.

    Аргументы:
        param_db (dict): Словарь с параметрами подключения, включающий:
            - host (str): Адрес сервера базы данных;
            - port (int): Порт сервера базы данных;
            - database (str): Имя базы данных;
            - user (str): Имя пользователя для доступа к базе данных;
            - password (str): Пароль пользователя;
            - client_encoding (str): Кодировка клиентского соединения.
        debug (bool, optional): Режим отладки. Если True, выводит информацию о начале и конце выполнения функции. По умолчанию False.

    Результат:
        psycopg2.extensions.connection: Объект соединения с базой данных.

    Обработка ошибок:
        Exception: В случае ошибки подключения, сообщение об ошибке будет содержаться в исключении.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres', 'client_encoding':'utf8'}
        >>> conn = connect_db(param_db) # получаем объект соединения с базой данных
        >>> cur = conn.cursor()
        >>> cur.close()
        >>> conn.close()
    """
    if debug:
        print("function connect_db(): Begin")
        print("param_db = {param_db}")
    
    conn = psycopg2.connect(
        host = param_db['host'],
        port = param_db['port'],
        database = param_db['database'],
        user = param_db['user'],
        password = param_db['password'],
        client_encoding = param_db['client_encoding']
    )
    if debug: print("function connect_db(): End")
    return conn

# получение данных из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса
def get_data(param_db, query, debug=False):
    """
    Получает данные из таблиц базы данных PostgreSQL на основе предоставленного SQL-запроса.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции connect_db().
        query (str): SQL-запрос для извлечения данных.
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет строку результата запроса. Ключи словаря - это имена столбцов из запроса.
              Возвращает пустой список в случае ошибки.

    Обработка ошибок:
        Exception: В случае ошибок подключения или выполнения запроса, сообщение об ошибке будет содержаться в исключении (если не перехвачено).

    Замечания:
        - Использует функцию connect_db для соединения с базой данных.
        - Результат возвращается в виде списка словарей для удобства обработки данных по именам столбцов.

    Пример:
        >>> param_db = {'host':'172.16.1.12', 'port':5432, 'database':'postgres', 'user':'postgres', 'password':'postgres', 'client_encoding':'utf8'}
        >>> query = "SELECT id, name FROM State"
        >>> states = get_data(param_db, query)
        states = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    if debug:
        print("function get_data(): Begin")
        print("param_db = {param_db}")
        print("Выполняю подключение к базе")
    
    conn = connect_db(param_db)
    
    if debug: print("Получаю объект курсора базы")
    cur = conn.cursor()
    
    if debug: print("Выполняю запрос к базе")
    try:
        cur.execute(query)

        if debug: print("Получаю все строки результата запроса к базе")
        data = cur.fetchall()

        columns = [desc[0] for desc in cur.description]
        
        if debug: print(f"columns = {columns}")
        if debug: print(f"data = {data}")
        
        result = [dict(zip(columns, row)) for row in data]
        if debug: print(f"result = {result}")
    except psycopg2.Error as e: # если возникла ошибка при запросе к базе
        print(f"Ошибка базы данных: {e}")
        result = []  # возвращаем пустой список результатов

    finally: # Всегда выполняем закрытие соединения, даже если произошла ошибка
        if debug: print("Закрываю курсор базы")
        cur.close()
        if debug: print("Закрываю соединение с базой")
        conn.close()
    
    if debug:
        print("function get_data(): End")
    return result

# получение списка всех состояний из таблицы 'State' базы данных
def get_states(param_db, debug=False):
    """
    Получает список всех состояний из таблицы 'State' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет наменование состояния с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого состояния из таблицы State.

    Пример:
        >>> states = database.get_states(param_db)
        >>> print(f"type states = {type(states)}")
        >>> print(f"states = {states}")
        type states = <class 'list'>
        states = [{'id': 1, 'name': 'Азотемия'}, {'id': 10, 'name': 'Нарушение клубочковой фильтрации почек'}]
    """
    if debug:
        print("function get_states(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, name FROM State"
    
    if debug: print("function get_states(): End")
    return get_data(param_db, query)

# получение списка наименования всех параметров из таблицы 'Parameter' базы данных
def get_parameters(param_db, debug=False):
    """
    Получает список наименования всех параметров из таблицы 'Parameter' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет параметр с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого параметра из таблицы Parameter.

    Пример:
        >>> parameters = database.get_parameters(param_db)
        >>> print(f"type parameters = {type(parameters)}")
        >>> print(f"parameters = {parameters}")
        type parameters = <class 'list'>
        parameters = [{'id': 1, 'name': 'Креатинин'}, {'id': 3, 'name': 'Мочевина'}]
    """
    if debug:
        print("function get_parameters(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, name FROM Parameter"
    
    if debug: print("function get_parameters(): End")
    return get_data(param_db, query)

# получение списка наименования всех единиц измерения отклонений из таблицы 'TOD' базы данных
def get_tods(param_db, debug=False):
    """
    Получает список наименования всех единиц измерения параметров из таблицы 'TOD' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет еденицу измерения с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование еденицы измерения параметра из таблицы TOD.

    Пример:
        >>> parameters = database.get_parameters(param_db)
        >>> print(f"type parameters = {type(parameters)}")
        >>> print(f"parameters = {parameters}")
        type tods = <class 'list'>
        tods = [{'id': 1, 'name': 'мкмоль/л'}, {'id': 3, 'name': 'ммоль/л'}]
    """
    if debug:
        print("function get_tods(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, name FROM TOD"
    
    if debug: print("function get_tods(): End")
    return get_data(param_db, query)

# получение списка всех разновидностей наименований приоритетов из таблицы 'Priority' в базе данных
def get_prioritys(param_db, debug=False):
    """
    Получает список всех разновидностей наименований приоритетов параметров в определении состояний из таблицы 'Priority' в базе данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет приоритет с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого приоритета из таблицы Priority.

    Пример:
        >>> prioritys = database.get_prioritys(param_db)
        >>> print(f"type prioritys = {type(prioritys)}")
        >>> print(f"prioritys = {prioritys}")
        type prioritys = <class 'list'>
        prioritys = [{'id': 1, 'name': 'Основной'}, {'id': 3, 'name': 'Неосновной'}]
    """
    if debug:
        print("function get_prioritys(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, name FROM Priority"
    
    if debug: print("function get_prioritys(): End")
    return get_data(param_db, query)

# получение списка всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных
def get_weights(param_db, debug=False):
    """
    Получает список всех значений значимости (весов) отклонений из таблицы 'Weight' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет значимость с ключами 'id' и 'value'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и значение каждого веса из таблицы Weight.

    Пример:
        >>> weights = database.get_weights(param_db)
        >>> print(f"type weights = {type(weights)}")
        >>> print(f"weights = {weights}")
        type weights = <class 'list'>
        weights = [{'id': 1, 'value': '1'}, {'id': 2, 'value': '2'}, {'id': 3, 'value': '3'}, {'id': 4, 'value': '4'}, {'id': 5, 'value': '5'}]
    """
    if debug:
        print("function get_weights(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, value FROM Weight"
    
    if debug: print("function get_weights(): End")
    return get_data(param_db, query)

# получение списка всех наименований отклонений из таблицы 'Deviation' базы данных
def get_deviations(param_db, debug=False):
    """
    Получает список всех наименований отклонений из таблицы 'Deviation' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет отклонение с ключами 'id' и 'name'.
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID и наименование каждого отклонения из таблицы Deviation.

    Пример:
        >>> deviations = database.get_deviations(param_db)
        >>> print(f"type deviations = {type(deviations)}")
        >>> print(f"deviations = {deviations}")
        type deviations = <class 'list'>
        deviations = [{'id': 1, 'name': 'Повышение уровня креатинина'}, {'id': 4, 'name': 'Повышение уровня мочевой кислоты'}]
    """
    if debug:
        print("function get_deviations(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, name FROM Deviation"
    
    if debug: print("function get_deviations(): End")
    return get_data(param_db, query)

# получение справочных данных о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
def get_dos(param_db, debug=False):
    """
    Получает справочные данные о зонах норм и зонах отклонения от нормы из таблицы 'DOS' базы данных вместе с информацией из связанных таблиц.
    Связанные таблицы 'System', 'Organ', 'Parameter', 'State', 'Gender', 'TOD', 'Deviation', 'Dynamics', 'Priority', 'Weight'

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет запись из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 'system_name', 'organ_name', 'param_name', 'state_name', 'gen_name', 'age_min', 'age_max', 'tod_name', 'norm_min', 'norm_max', 'mod_dev_min', 'mod_dev_max', 'exp_dev_min', 'exp_dev_max', 'crit_dev_min', 'crit_dev_max', 'deviation_name', 'pos_dyn_name', 'neg_dyn_name', 'priority_name', 'weight_name'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения сложного SQL-запроса с множеством JOIN-ов.
        - Запрос извлекает ID, возрастные диапазоны, нормативные значения, отклонения и другую справочную информацию по параметрам и состояниям.
    
    Пример:
        >>> dos = database.get_dos(param_db)
        >>> print(f"type dos = {type(dos)}")
        >>> print(f"dos = {dos}")
        type dos = <class 'list'>
        dos = [
        {'id': 2, 'system_name': 'Иммунная система', 'organ_name': None, 'param_name': 'Ферритин', 'state_name': 'Воспалительный ответ', 'gen_name': 'Муж', 'age_min': None, 'age_max': None, 'tod_name': 'нг/мл', 'norm_min': '30', 'norm_max': '400', 'mod_dev_min': '400,1', 'mod_dev_max': '600', 'exp_dev_min': '600,1', 'exp_dev_max': '1000', 'crit_dev_min': '1000', 'crit_dev_max': None, 'deviation_name': 'Повышение уровня ферритина', 'pos_dyn_name': 'снижение', 'neg_dyn_name': 'повышение', 'priority_name': 'Неосновной', 'weight_name': None}, 
        {'id': 3, 'system_name': 'Иммунная система', 'organ_name': None, 'param_name': 'Ферритин', 'state_name': 'Воспалительный ответ', 'gen_name': 'Жен', 'age_min': None, 'age_max': None, 'tod_name': 'нг/мл', 'norm_min': '13', 'norm_max': '150', 'mod_dev_min': '150,1', 'mod_dev_max': '250', 'exp_dev_min': '250,1', 'exp_dev_max': '400', 'crit_dev_min': '400', 'crit_dev_max': None, 'deviation_name': 'Повышение уровня ферритина', 'pos_dyn_name': 'снижение', 'neg_dyn_name': 'повышение', 'priority_name': 'Неосновной', 'weight_name': None}, 
        {'id': 4, 'system_name': 'Иммунная система', 'organ_name': None, 'param_name': 'Лейкоциты', 'state_name': 'Воспалительный ответ', 'gen_name': None, 'age_min': None, 'age_max': None, 'tod_name': '10 в 9ст/л', 'norm_min': '4,0', 'norm_max': '9,0', 'mod_dev_min': '9,1', 'mod_dev_max': '14,99', 'exp_dev_min': '15,0', 'exp_dev_max': '19,9', 'crit_dev_min': '20', 'crit_dev_max': None, 'deviation_name': 'Повышение уровня лейкоцитов в крови', 'pos_dyn_name': 'снижение', 'neg_dyn_name': 'повышение', 'priority_name': 'Неосновной', 'weight_name': None}
        ]
    """
    if debug:
        print("function get_dos(): Begin")
        print("param_db = {param_db}")
        print("Формирую запрос к таблице dos")
    
    query = """
        SELECT 
            DOS.id, 
            System.name AS system_name, 
            Organ.name AS organ_name, 
            Parameter.name AS param_name, 
            State.name AS state_name, 
            Gender.name AS gen_name,
            DOS.age_min, 
            DOS.age_max, 
            TOD.name AS tod_name, 
            DOS.norm_min, 
            DOS.norm_max, 
            DOS.mod_dev_min, 
            DOS.mod_dev_max, 
            DOS.exp_dev_min, 
            DOS.exp_dev_max, 
            DOS.crit_dev_min, 
            DOS.crit_dev_max, 
            Deviation.name AS deviation_name, 
            pos_dyn.name AS pos_dyn_name, 
            neg_dyn.name AS neg_dyn_name, 
            Priority.name AS priority_name, 
            Weight.value AS weight_name
        FROM 
            DOS
        LEFT JOIN System ON DOS.system_id = System.id
        LEFT JOIN Organ ON DOS.organ_id = Organ.id
        LEFT JOIN State ON DOS.state_id = State.id
        LEFT JOIN Parameter ON DOS.parameter_id = Parameter.id
        LEFT JOIN Gender ON DOS.gender_id = Gender.id
        LEFT JOIN TOD ON DOS.tod_id = TOD.id
        LEFT JOIN Deviation ON DOS.deviation_id = Deviation.id
        LEFT JOIN Dynamics AS pos_dyn ON DOS.pos_dyn_id = pos_dyn.id
        LEFT JOIN Dynamics AS neg_dyn ON DOS.neg_dyn_id = neg_dyn.id
        LEFT JOIN Priority ON DOS.priority_id = Priority.id
        LEFT JOIN Weight ON DOS.weight_id = Weight.id
    """
    
    if debug: print("function get_dos(): End")
    return get_data(param_db, query, debug=False)

# получение списка всех пациентов из таблицы 'Patient' базы данных
def get_patients(param_db, debug=False):
    """
    Получает список всех пациентов из таблицы 'Patient' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
              Ключи словаря соответствуют именам столбцов в запросе в следующем виде:
              {'id', 's_name', 'name', 'surname', 'date_birth', 'p_series', 'p_number', 'snils', 'med_polis', 'medstat_id', 'gender'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.
        - Запрос извлекает ID, ФИО (включая отчество или второе имя), дату рождения, контактные данные, информацию о страховании, медицинский статус и пол пациентов.

    Пример:
        >>> patients = database.get_patients(param_db)
        >>> print(f"type patients = {type(patients)}")
        >>> print(f"patients = {patients}")
        type patients = <class 'list'>
        patients = [{'id': 7, 's_name': 'Терсинских', 'name': 'Светлана', 'surname': 'Анатольевна', 'date_birth': datetime.date(1943, 4, 8), 'p_series': '9204', 'p_number': '230345', 'snils': '086-585-093 15', 'med_polis': '1675650891000055', 'medstat_id': '240118257', 'gender': 'женский'}, 
        {'id': 8, 's_name': 'Файзуллин', 'name': 'Ирек', 'surname': 'Энварович', 'date_birth': datetime.date(1962, 12, 8), 'p_series': '9208', 'p_number': '572446', 'snils': '029-546-834 86', 'med_polis': '164773084100374', 'medstat_id': '04120206', 'gender': 'мужской'}]
    """
    if debug:
        print("function get_patients(): Begin")
        print("param_db = {param_db}")
    
    query = "SELECT id, s_name, name, surname, date_birth, p_series, p_number, snils, med_polis, medstat_id, gender FROM patient"
    
    if debug: print("function get_patients(): End")
    return get_data(param_db, query)

# получение списка всех исследований пациентов из таблицы 'research' базы данных
def get_researchs(param_db, debug=False):
    """
    Получает списка всех исследований пациентов из таблицы 'research' базы данных, объединяя данные из таблиц 'research' и 'patient'.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет запись об исследовании с данными пациента (ФИО, дата рождения, пол и т.д.).
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Запрос извлекает ID исследования, идентификатор пациента, ФИО пациента (в формате Фамилия Имя Отчество/Второе имя), пол, дату рождения, дату проведения исследования и данные результататов.
        - Структура возвращаемых данных включают столбцы из обеих таблиц - research и patient.

    Пример:
        >>> researchs = database.get_researchs(param_db)
        >>> print(f"type researchs = {type(researchs)}")
        >>> print(f"researchs = {researchs}")
        type researchs = <class 'list'>
        researchs = [{'id': 189, 'patient_id': 8, 'surname': 'Файзуллин', 'name': 'Ирек', 'middle_name': 'Энварович', 'gender': 'мужской', 'date_birth': datetime.date(1962, 12, 8), 'date': datetime.date(2024, 8, 20), 'data': 'Ca++:1,2 ммоль/л\r\nLac:3,2 ммоль/л'}, 
        {'id': 191, 'patient_id': 8, 'surname': 'Файзуллин', 'name': 'Ирек', 'middle_name': 'Энварович', 'gender': 'мужской', 'date_birth': datetime.date(1962, 12, 8), 'date': datetime.date(2024, 8, 20), 'data': 'Амплитуда  АДФ-индуцированной агрегации:33,4 %\r\nПротеин С:96 %\r\nФибриноген:3,4 г/л\r\nАнтитромбин III:96 %\r\nПротромбиновое время:10,4 сек.\r\nПротромбин по Квику:121 %\r\nМНО:0,88  \r\nД-димер:0,23 мкг/мл\r\nАЧТВ:29,8 сек.'}]
    """
    if debug:
        print("function get_researchs(): Begin")
        print("param_db = {param_db}")
    
    query = """
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            """
    
    if debug: print("function get_researchs(): End")
    return get_data(param_db, query)

# получение записи конкретного исследования по указанному ID в таблице 'Research' базы данных
def get_research_by_id(param_db, research_id, debug=False):
    """
    Получает запись конкретного исследования по указанному ID в таблице 'research' базы данных.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): ID исследования в поле id таблицы research базы данных, по которому необходимы данные.
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        dict: Словарь с данными об исследовании (ФИО пациента, дата рождения, пол и т.д.) или None, если запись не найдена.
              Ключи словаря соответствуют названиям столбцов в запросе в следующем виде:
              {'id', 'patient_id', 'surname', 'name', 'middle_name', 'gender', 'date_birth', 'date', 'data'}

    Замечания:
        - Запрос извлекает те же поля, что и в get_researchs, но возвращает только одну запись на основе ID.

    Пример:
        >>> research_id = database.get_research_by_id(param_db, 4)
        >>> print(f"type research_id = {type(research_id)}")
        >>> print(f"research_id = {research_id}")
        type research_id = <class 'dict'>
        research_id = {'id': 4, 'patient_id': 7, 'surname': 'Терсинских', 'name': 'Светлана', 'middle_name': 'Анатольевна', 'gender': 'женский', 'date_birth': datetime.date(1943, 4, 8), 'date': datetime.date(2024, 1, 22), 'data': 'Д-димер:8,66 мкг/мл\r\nАЧТВ:32,6 сек.\r\nПротромбиновое время:14,3 сек.\r\nПротромбин по Квику:74,4 %\r\nМНО:1,17  \r\nФибриноген:4,8 г/л'}
    """
    if debug:
        print("function get_research_by_id(): Begin")
        print(f"research_id = {research_id}")

    query = f"""
            SELECT
                research.id,
                research.patient_id,
                patient.s_name AS surname,
                patient.name AS name,
                patient.surname AS middle_name,
                patient.gender AS gender,
                patient.date_birth AS date_birth,
                research.date,
                research.data
            FROM
                research
            LEFT JOIN patient ON research.patient_id = patient.id
            WHERE research.id = {research_id}
            """

    if debug: print("function get_research_by_id(): End")
    result = get_data(param_db, query)

    # Возвращаем первую запись (если найдена), иначе None
    return result[0] if result else None

# получение списка всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями
def get_conclusion(param_db, debug=False):
    """
    Получает список всех медицинских заключений из таблицы 'conclusion', связанных с пациентами и исследованиями.

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        list: Список словарей, где каждый словарь представляет запись о заключении с данными идентификаторов записи (id), исследования (research_id), пациента (patient_id), даты создания (date_create), сотруднике (emp_id), результатах анализов (inter_results) и тексте заключения (conc_text).
              Ключи словаря соответствуют названиям столбцов в таблице conclusion в следующем виде:
              {'id', 'research_id', 'patient_id', 'date_create', 'emp_id', 'date_save', 'inter_results', 'conc_text'}
              Возвращает пустой список, если не удается получить данные.

    Замечания:
        - Использует функцию get_data для выполнения запроса к базе данных.

    Пример:
        >>> conclusions = database.get_conclusion(param_db)
        >>> print(f"type conclusions = {type(conclusions)}")
        >>> print(f"conclusions = {conclusions}")
        print(f"conclusions = {conclusions}")
        conclusions = [{'id': 153, 'research_id': 4, 'patient_id': 7, 'date_create': datetime.datetime(2025, 9, 5, 16, 7, 5), 'emp_id': None, 'date_save': None, 'inter_results': '"[{\'Свертывающая система крови\': {None: {\'Гипокоагуляция:1.17\': [\'Повышение уровня МНО:2\', \'Удлинение протромбинового времени:2\']}}}, {\'Свертывающая система крови\': {None: {\'Активация свертывающей и фибринолитической  системы:34.64\': [\'Повышение уровня Д-димера:4\']}}}, {\'Иммунная система\': {None: {\'Воспалительный ответ:1.66\': [\'Повышение уровня фибриногена:2\']}}}]"', 'conc_text': None}, 
        {'id': 154, 'research_id': 4, 'patient_id': 7, 'date_create': datetime.datetime(2025, 9, 5, 16, 7, 22), 'emp_id': None, 'date_save': None, 'inter_results': '"[{\'Свертывающая система крови\': {None: {\'Гипокоагуляция:1.17\': [\'Повышение уровня МНО:2\', \'Удлинение протромбинового времени:2\']}}}, {\'Свертывающая система крови\': {None: {\'Активация свертывающей и фибринолитической  системы:34.64\': [\'Повышение уровня Д-димера:4\']}}}, {\'Иммунная система\': {None: {\'Воспалительный ответ:1.66\': [\'Повышение уровня фибриногена:2\']}}}]"', 'conc_text': None}]
    """
    if debug:
        print("function get_conclusion(): Begin")
        print("param_db = {param_db}")
    
    query = """
            SELECT
                conclusion.id,
                conclusion.research_id,
                conclusion.patient_id,
                conclusion.date_create,
                conclusion.emp_id,
                conclusion.date_save,
                conclusion.inter_results,
                conclusion.conc_text
            FROM
                conclusion
            """
    
    if debug: print("function get_conclusion(): End")
    return get_data(param_db, query)

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
def save_conclusion(param_db, research_id, patient_id, inter_results, data, debug=False):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().
        debug (bool, optional): Режим отладки. Если True, выводит дополнительную информацию о параметрах и SQL-запросе. По умолчанию False.

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Замечания:
        - В случае ошибки происходит rollback транзакции, и сообщение об ошибке выводится в лог.
        - При включенном режиме отладки выводятся значения параметров и SQL-запрос для проверки.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = save_conclusion(id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    if debug:
        print(f"save_conclusion(): Begin")
        print(f"param_db = {param_db}")
        print(f"research_id = {research_id}, patient_id = {patient_id}")
        print(f"inter_results = {inter_results}")
        print(f"data = {data}")
    
    conn = connect_db(param_db)
    # cur = conn.cursor()
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        # безопасный параметризированный запрос для предотвращения SQL-инъекций.
        query = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES (%s, %s, %s, %s, %s)
        """
        # inter_results_str = pickle.dumps(inter_results)
        # if debug: print(f"inter_results_str = {inter_results_str}")
        inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)
        if debug: print(f"inter_results_json = {inter_results_json}")
        
        with conn.cursor() as cur:  # Используем with statement для автоматического управления курсором
            cur.execute(query, (research_id, patient_id, date_create, inter_results, data))
            # cur.execute(query, (research_id, patient_id, date_create, inter_results_json, data))
            # cur.execute(query, (research_id, patient_id, date_create, inter_results_json, str(data)))
            # cur.execute(query, (research_id, patient_id, date_create, str(inter_results), str(data)))
            conn.commit() # commit выполняется автоматически внутри блока with
            if debug: print("Результат успешно сохранен в таблицу Conclusion")
        
    except psycopg2.Error as e:
        print(f"Ошибка при сохранении в базу данных: {e}")
        conn.rollback()
        if debug: print(f"save_conclusion(): End")
        return False, str(e) # возвращаем признак неуспешного выполнения с сообщением об ошибке
    
    if debug: print(f"save_conclusion(): End")
    return True  # возвращаем признак успешного выполнения

# сохранение данных интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных с возвратом id записи.
def save_conclusion_v2(param_db, research_id, patient_id, inter_results, data, debug=False):
    """
    Сохраняет данные интерпретации лабораторных анализов в таблицу 'Conclusion' базы данных.
    Выполняет запись в следующие поля таблицы 'Conclusion' следующих данных:
        research_id - идентификатор исследования
        patient_id - идентификатор пациента
        date_create - дата и время выполнения записи в базу
        inter_results - строка данных интерпретации лабораторных данных
        raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState()

    Аргументы:
        param_db (dict): Словарь параметров подключения к базе данных, с ключами host, port, database, user, password и client_encoding.
                         Должен соответствовать ожиданиям функции get_data().
        research_id (int): Идентификатор исследования, связанный с заключением.
        patient_id (int): Идентификатор пациента, которому относится заключение.
        inter_results (str): Строка результатов интерпретации.
        data (dict): Объект данных интерпретации лабораторных анализов, возвращённый функцией interpreter.getState().
        debug (bool, optional): Режим отладки. Если True, выводит дополнительную информацию о параметрах и SQL-запросе. По умолчанию False.

    Результат:
        Возвращает True в случае успешного выполнения записи в базу.
        Возвращает False и ошибку в случае неуспешного выполнения записи в базу.

    Замечания:
        - В случае ошибки происходит rollback транзакции, и сообщение об ошибке выводится в лог.
        - При включенном режиме отладки выводятся значения параметров и SQL-запрос для проверки.

    Пример:
        >>> id_research = state_patient['id_research']
        >>> id_patient = state_patient['id_patient']
        >>> sort_states_text = state_patient['sort_states_text']
        >>> status, error = save_conclusion(id_research, id_patient, sort_states_text, state_patient)
        >>> if status:
        >>>     print(f"Запись успешно выполнена")
        >>> else:
        >>>     print(f"Запись не выполнена. Ошибка: {error}")
    """
    if debug:
        print(f"save_conclusion(): Begin")
        print(f"param_db = {param_db}")
        print(f"research_id = {research_id}, patient_id = {patient_id}")
        print(f"inter_results = {inter_results}")
        print(f"data = {data}")

    conn = connect_db(param_db)
    date_create = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    try:
        # Безопасный параметризированный запрос для вставки данных
        query_insert = """
            INSERT INTO Conclusion (research_id, patient_id, date_create, inter_results, raw_data) 
            VALUES (%s, %s, %s, %s, %s) RETURNING id;
        """
        inter_results_json = json.dumps(inter_results, indent=2, ensure_ascii=False, default=str)

        # Выполнение вставки и получение ID последней записи (может быть ненадежным в параллельной среде)
        with conn.cursor() as cur:
            cur.execute(query_insert, (research_id, patient_id, date_create, inter_results, data))
            conn.commit()
            result = cur.fetchone()[0]  # Получаем ID из результата

            if debug:
                print("Результат успешно сохранен в таблицу c")
                print(f"ID новой записи: {result}")

        # Поиск записи по research_id, patient_id и date_create (может вернуть несколько записей, если не уникально)
        query_select = """
            SELECT id FROM Conclusion 
            WHERE research_id = %s AND patient_id = %s AND date_create = %s;
        """
        with conn.cursor() as cur:
            cur.execute(query_select, (research_id, patient_id, date_create))
            found_record = cur.fetchone()  # Возвращает одну запись или None

            if found_record:
                record_id = found_record[0]
                if debug:
                    print(f"Полученная запись found_record: {found_record}")
                    print(f"Запись найдена с ID: {record_id}")
            else:
                record_id = None
                if debug: print("Запись не найдена по заданным критериям.")

    except psycopg2.Error as e:
        print(f"Ошибка при сохранении или поиске в базе данных: {e}")
        conn.rollback()
        if debug: print(f"save_conclusion(): End")
        return False, None  # Возвращаем признак неуспешного выполнения и None для ID

    finally:
        if conn:
            conn.close()

    if debug: print(f"save_conclusion(): End")
    return True, record_id if found_record else result  # Возвращаем признак успеха и ID записи (или результат вставки)