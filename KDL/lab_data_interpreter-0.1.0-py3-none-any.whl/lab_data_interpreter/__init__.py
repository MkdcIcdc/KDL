# lab_data_interpreter/__init__.py

"""
Библиотека lab_data_interpreter — интерпретация лабораторных данных.
Доступные модули:
- interpreter: основная логика анализа данных
- utils: вспомогательные функции
- database: работа с БД
- database_async: асинхронная работа с БД
"""

# импортируем из interpreter.py
from .interpreter import (
    DictAttr,
    Parameter,
    Parameters,
    getState,
    getState_by_reseach_id_and_save_to_base_v1,
    getState_by_reseach_id_and_save_to_base_v2,
    getState_by_reseach_id_and_save_to_base_async_v2,
    getStates_by_reseachs_in_day_and_save_to_base,
    getStates_by_reseachs_in_day_and_save_to_base_async,
    sortedParamsStateText,
    sortedParamsStateText_v2,
    getListSortedStates,
    sortedStatesText,
    sortedStatesText_v2,
    buildResearchParams,
    getResearchID_PatientID,
    mergeResearchs_to_ResearchCommon,
)

# импортируем из utils.py
from .utils import (
    translit,
    clean_identifier,
    toFloat,
    getMin,
    getMax,
    is_iterable,
    getDirectFromBounds_v1,
    getDirectInList_v1,
    parse_date,
    getAge,
)

# импортируем из database.py
from .database import (
    connect_db,
    get_data,
    get_states,
    get_consectarys,
    get_parameters,
    get_tods,
    get_prioritys,
    get_weights,
    get_deviations,
    get_dos,
    get_patients,
    get_researchs,
    get_research_by_id,
    get_researchs_by_date_from_id,
    get_conclusion,
    save_conclusion,
    save_conclusion_v2,
)

# импортируем из database_async.py
from .database_async import (
    connect_db_async,
    get_data_async,
    get_states_async,
    get_consectarys_async,
    get_parameters_async,
    get_tods_async,
    get_prioritys_async,
    get_weights_async,
    get_deviations_async,
    get_dos_async,
    get_patients_async,
    get_researchs_async,
    get_research_by_id_async,
    get_researchs_by_date_from_id_async,
    get_conclusion_async,
    save_conclusion_async,
    save_conclusion_v2_async,
)

# определяем, что экспортируется при `import *`
__all__ = [
    # из interpreter
    "DictAttr",
    "Parameter",
    "Parameters",
    "getState",
    "getState_by_reseach_id_and_save_to_base_v1",
    "getState_by_reseach_id_and_save_to_base_v2",
    "getState_by_reseach_id_and_save_to_base_async_v2",
    "getStates_by_reseachs_in_day_and_save_to_base",
    "getStates_by_reseachs_in_day_and_save_to_base_async",
    "sortedParamsStateText",
    "sortedParamsStateText_v2",
    "getListSortedStates",
    "sortedStatesText",
    "sortedStatesText_v2",
    "buildResearchParams",
    "getResearchID_PatientID",
    "mergeResearchs_to_ResearchCommon",

    # из utils
    "translit",
    "clean_identifier",
    "toFloat",
    "getMin",
    "getMax",
    "is_iterable",
    "getDirectFromBounds_v1",
    "getDirectInList_v1",
    "parse_date",
    "getAge",

    # из database
    "connect_db",
    "get_data",
    "get_states",
    "get_consectarys",
    "get_parameters",
    "get_tods",
    "get_prioritys",
    "get_weights",
    "get_deviations",
    "get_dos",
    "get_patients",
    "get_researchs",
    "get_research_by_id",
    "get_researchs_by_date_from_id",
    "get_conclusion",
    "save_conclusion",
    "save_conclusion_v2",

    # из database_async
    "connect_db_async",
    "get_data_async",
    "get_states_async",
    "get_consectarys_async",
    "get_parameters_async",
    "get_tods_async",
    "get_prioritys_async",
    "get_weights_async",
    "get_deviations_async",
    "get_dos_async",
    "get_patients_async",
    "get_researchs_async",
    "get_research_by_id_async",
    "get_researchs_by_date_from_id_async",
    "get_conclusion_async",
    "save_conclusion_async",
    "save_conclusion_v2_async",
]

# Опционально: версия
__version__ = "0.1.0"
