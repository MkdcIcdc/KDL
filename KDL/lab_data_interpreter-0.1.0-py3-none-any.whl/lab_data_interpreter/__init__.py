# lab_data_interpreter/__init__.py

"""
Библиотека lab_data_interpreter — интерпретация лабораторных данных.
Доступные модули:
- interpreter: основная логика анализа данных
- utils: вспомогательные функции
- database: работа с БД
"""

# импортируем из interpreter.py
from .interpreter import (
    DictAttr,
    Parameter,
    Parameters,
    getState,
    getState_by_reseach_id_and_save_to_base,
    sortedParamsStateText,
    sortedParamsStateText_v2,
    getListSortedStates,
    sortedStatesText,
    sortedStatesText_v2,
    buildResearchParams,
)

# импортируем из utils.py
from .utils import (
    translit,
    clean_identifier,
    toFloat,
    getMin,
    getMax,
    is_iterable,
    getDirectFromBounds_v1,
    parse_date,
    getAge,
)

# импортируем из database.py
from .database import (
    connect_db,
    get_data,
    get_states,
    get_parameters,
    get_tods,
    get_prioritys,
    get_weights,
    get_deviations,
    get_dos,
    get_patients,
    get_researchs,
    get_research_by_id,
    get_conclusion,
    save_conclusion,
)

# определяем, что экспортируется при `import *`
__all__ = [
    # из interpreter
    "DictAttr",
    "Parameter",
    "Parameters",
    "getState",
    "getState_by_reseach_id_and_save_to_base",
    "sortedParamsStateText",
    "sortedParamsStateText_v2",
    "getListSortedStates",
    "sortedStatesText",
    "sortedStatesText_v2",
    "buildResearchParams",

    # из utils
    "translit",
    "clean_identifier",
    "toFloat",
    "getMin",
    "getMax",
    "is_iterable",
    "getDirectFromBounds_v1",
    "parse_date",
    "getAge",

    # из database
    "connect_db",
    "get_data",
    "get_states",
    "get_parameters",
    "get_tods",
    "get_prioritys",
    "get_weights",
    "get_deviations",
    "get_dos",
    "get_patients",
    "get_researchs",
    "get_research_by_id",
    "get_conclusion",
    "save_conclusion",
]

# Опционально: версия
__version__ = "0.1.0"
