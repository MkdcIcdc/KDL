import json # для работы с json-объектами
from math import * # нужны inf литерал бесконечности и парочка других функций типа math.round
from intervals import FloatInterval # для определения числовых интервалов
from fuzzywuzzy import fuzz, process
import lab_data_interpreter.database as database
import lab_data_interpreter.database_async as database_async
import asyncio
from lab_data_interpreter.utils import *

# from types import SimpleNamespace # используется в iter_params()
# from typing import Union, List, Dict, Literal, Optional # для описания типов аргументов функций и выходного значения



# создаёт словарь, к ключам которого можно обращаться как к свойствам объекта (через точку)
class DictAttr(dict):
    """
    Словарь, который позволяет обращаться к ключам как к атрибутам.
    
    Пример:
        >>> param = DictAttr(id_research='1', id_patient='7', name='Креатинин', value=153, gender='М', age=46)
        >>> print(f"{param.name}"
        Креатинин
    """
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as e:
            raise AttributeError(item) from e

    def __setattr__(self, key, value):
        self[key] = value

# класс, описывает отдельный параметр из справочника с 3-мя градациями фаз его отклонения от нормы и остальными характеристиками с которыми связан параметр
class Parameter:
    """
    Класс описывает параметр из справочника с зонами нормы и отклонения и остальными характеристиками.
    
    Аргументы конструктора:
        data (dict): Словарь, представляющий запись по параметру из таблицы DOS.
        В случае ошибки структуры и типов в dos вызывается исключение и возвращается код ошибки.
    
    Основные атрибуты класса:
        name(), system(), organ(), state(), priority(), weight(), 
        deviation(),tod(), gender(), recomendation(), 
        age(), norm(), mod_dev(), exp_dev(), crit_dev()
    
    Основные методы класса:
        print_prop(self, objName, extend): Вывод в лог информацию о параметрах.
    
    Пример:
        >>> dos = database.get_dos(param_db)
        >>> param = Parameter(dos[0])
    """
    def __init__(self, data):
        """
        Инициализирует объект Parameter.

        Аргументы:
            data (dict): Словарь, представляющий запись по параметру из таблицы DOS.
            В случае ошибки структуры и типов в dos вызывается исключение и возвращается код ошибки.

        Исключения:
            TypeError: Если `dos` не является списком словарей.
            KeyError: Если в словарях отсутствует необходимый ключ.
            ValueError: Если значения аргументов недопустимы.
        """
        # проверим что в списке есть хотя бы один словарь для анализа на наличие в нём необходимых ключей
        # if isinstance(data, list):
        #     if not any(isinstance(item, dict) for item in data):
        #         # print(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
        #         raise TypeError(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
        
        # проверим что в списке есть хотя бы один словарь для анализа на наличие в нём необходимых ключей
        if not isinstance(data, dict):
            raise TypeError(f"Переданный тип аргумент data, должен быть словарём! Переданный тип data = {type(data)}")
        
        # проверяем наличие обязательных ключей у входного словаря data, без наличия которых создать объект словаря параметров невозможно
        requared_keys = ['param_name', 'state_name']
        for key in requared_keys:
            if key in data:
                if data[key] is None:
                    # print(f"В переданном словаре не задано значение ключа {key}")
                    raise ValueError(f"В переданном словаре не задано значение ключа {key}")
                
                setattr(self, key, data[key])
                
            else:
                # print(f"Отсутствует обязательный ключ {key} в переданном словаре!")
                raise KeyError(f"Отсутствует обязательный ключ {key} в переданном словаре!")
        
        # последовательно проверяем наличие необязательных ключей у входного словаря data, без которых создать объект словаря параметров возможно
        # в случае отсутствия ключа, в объекте создаём его с пустым значением None
        
        # данные по ключам norm_min, norm_max, mod_dev_min, mod_dev_max необходимо проанализировать на тип заданных значений
        # и направление отсчёта зон отклонений от зоны нормы
        norm = [toFloat(data.get('norm_min', None)), toFloat(data.get('norm_max', None))]
        if all(norm) and norm[0]>norm[1]:
            norm[0], norm[1] = norm[1], norm[0]
        
        mod_dev = [toFloat(data.get('mod_dev_min', None)), toFloat(data.get('mod_dev_max', None))]
        if all(mod_dev) and mod_dev[0]>mod_dev[1]:
            mod_dev[0], mod_dev[1] = mod_dev[1], mod_dev[0]
        
        exp_dev = [toFloat(data.get('exp_dev_min', None)), toFloat(data.get('exp_dev_max', None))]
        if all(exp_dev) and exp_dev[0]>exp_dev[1]:
            exp_dev[0], exp_dev[1] = exp_dev[1], exp_dev[0]
        
        crit_dev = [toFloat(data.get('crit_dev_min', None)), toFloat(data.get('crit_dev_max', None))]
        if all(crit_dev) and crit_dev[0]>crit_dev[1]:
            crit_dev[0], crit_dev[1] = crit_dev[1], crit_dev[0]
        
        sequence = [norm[0], norm[1], mod_dev[0], mod_dev[1], exp_dev[0], exp_dev[1], crit_dev[0], crit_dev[1]]
        direct = getDirectInList_v1(sequence)
        
        qualitParam = False # признак качественных значений параметров зон
        
        # если тенденция изменения значений от зоны нормы к зоне критичности на повышение
        if direct>0:
            # 1. обработаем данные границ норм учитывая границы зон отклонения
            norm_min = norm[0] # getMin(norm)
            if norm_min==None:
                norm_min = -inf
            
            norm_max = norm[1] # getMax(norm)
            if norm_max==None:
                val = getMin(sequence[2:])
                norm_max = inf if val==None else val
            
            # 2. обработаем данные границ умеренного отклонения учитывая границы зоны нормы и зон отклонения
            mod_dev_min = mod_dev[0] # getMin(mod_dev)
            if mod_dev_min==None:
                mod_dev_min = norm_max
            
            mod_dev_max = mod_dev[1] # getMax(mod_dev)
            if mod_dev_max==None:
                val = getMin(sequence[4:])
                mod_dev_max = inf if val==None else val
            
            # 3. обработаем данные границ выраженного отклонения учитывая границы зоны умеренного и критического отклонений
            exp_dev_min = exp_dev[0] # getMin(exp_dev)
            if exp_dev_min==None:
                exp_dev_min = mod_dev_max
            
            exp_dev_max = exp_dev[1] # getMax(exp_dev)
            if exp_dev_max==None:
                val = getMin(sequence[6:])
                exp_dev_max = inf if val==None else val
            
            # 4. обработаем данные границ критического отклонения учитывая границы зоны выраженного отклонения
            crit_dev_min = crit_dev[0] # getMin(crit_dev)
            if crit_dev_min==None:
                crit_dev_min = exp_dev_max
            
            val = crit_dev[1] # getMax(crit_dev)
            crit_dev_max = inf if val==None else val
            
            # 5. перепроверим границы диапазонов, они должны примыкать друг к другу
            if norm_min==norm_max and (norm_min not in (-inf, inf)) and (norm_max not in (-inf, inf)):
                norm_max = getMin([mod_dev_min, mod_dev_max])
                if norm_min==norm_max:
                    norm_min = -inf
            
            if mod_dev_min==mod_dev_max and (mod_dev_min not in (-inf, inf)) and (mod_dev_max not in (-inf, inf)):
                mod_dev_max = getMin([exp_dev_min, exp_dev_max])
            
            if exp_dev_min==exp_dev_max and (exp_dev_min not in (-inf, inf)) and (exp_dev_max not in (-inf, inf)):
                exp_dev_max = getMin([crit_dev_min, crit_dev_max])
            
            if crit_dev_min==crit_dev_max and (crit_dev_min not in (-inf, inf)) and (crit_dev_max not in (-inf, inf)):
                crit_dev_max = inf
        
        # если тенденция изменения значений от зоны нормы к зоне критичности на понижение
        elif direct<0:
            # 1. обработаем данные границ норм учитывая границы зон отклонения
            norm_max = norm[1] # getMax(norm)
            if norm_max==None:
                norm_max = inf
            
            norm_min = norm[0] # getMin(norm)
            if norm_min==None:
                val = getMax(sequence[2:])
                norm_min = -inf if val==None else val
            
            # 2. обработаем данные границ умеренного отклонения учитывая границы зоны нормы и зон отклонения
            mod_dev_max = mod_dev[1] # getMax(mod_dev)
            if mod_dev_max==None:
                mod_dev_max = norm_min
            
            mod_dev_min = mod_dev[0] # getMin(mod_dev)
            if mod_dev_min==None:
                val = getMax(sequence[4:])
                mod_dev_min = -inf if val==None else val
            
            # 3. обработаем данные границ выраженного отклонения учитывая границы зоны умеренного и критического отклонений
            exp_dev_max = exp_dev[1] # getMax(exp_dev)
            if exp_dev_max==None:
                exp_dev_max = mod_dev_min
            
            exp_dev_min = exp_dev[0] # getMin(exp_dev)
            if exp_dev_min==None:
                val = getMax(sequence[6:])
                exp_dev_min = -inf if val==None else val
            
            # 4. обработаем данные границ критического отклонения учитывая границы зоны выраженного отклонения
            crit_dev_max = crit_dev[1] # getMax(crit_dev)
            if crit_dev_max==None:
                crit_dev_max = exp_dev_min
            
            val = crit_dev[0] # getMin(crit_dev)
            crit_dev_min = -inf if val==None else val
            
            # 5. перепроверим границы диапазонов, они должны примыкать друг к другу
            if norm_min==norm_max and (norm_min not in (-inf, inf)) and (norm_max not in (-inf, inf)):
                norm_max = inf
            
            if mod_dev_min==mod_dev_max and (mod_dev_min not in (-inf, inf)) and (mod_dev_max not in (-inf, inf)):
                mod_dev_max = getMin([norm_min, norm_max])
            
            if exp_dev_min==exp_dev_max and (exp_dev_min not in (-inf, inf)) and (exp_dev_max not in (-inf, inf)):
                exp_dev_max = getMin([mod_dev_min, mod_dev_max])
            
            if crit_dev_min==crit_dev_max and (crit_dev_min not in (-inf, inf)) and (crit_dev_max not in (-inf, inf)):
                crit_dev_max = getMin([exp_dev_min, exp_dev_max])
                if crit_dev_min==crit_dev_max:
                    crit_dev_min = -inf
        
        # если тенденция изменения значений от зоны нормы к зоне критичности не определена
        else:
            norm_min = toFloat(data.get('norm_min', None))
            norm_max = toFloat(data.get('norm_max', None))
            mod_dev_min = toFloat(data.get('mod_dev_min', None))
            mod_dev_max = toFloat(data.get('mod_dev_max', None))
            exp_dev_min = toFloat(data.get('exp_dev_min', None))
            exp_dev_max = toFloat(data.get('exp_dev_max', None))
            crit_dev_min = toFloat(data.get('crit_dev_min', None))
            crit_dev_max = toFloat(data.get('crit_dev_max', None))
            
            # обработка качественного значения типа 'положительно'/'отрицательно'. 'положительно' соотносим с inf, 'отрицательно' с -inf
            
            # if norm_min==inf and norm_max!=inf: norm_min = -inf  # задана верхняя граница, нижняя неограничена
            # elif norm_min!=None and norm_max==None: norm_max = inf # задана нижняя граница, верхняя неограничена
            
            # если зона нормы обозначены бесконечностью, то остальные зоны должны быть бесконечностью с противоположным знаком
            bad_data = False
            if norm_min==inf or norm_max==inf:
                if mod_dev_min==None and mod_dev_max==None and exp_dev_min==None and exp_dev_max==None and crit_dev_min==None and crit_dev_max==None:
                    mod_dev_min = -inf
                    mod_dev_max = -inf
                    exp_dev_min = -inf
                    exp_dev_max = -inf
                    crit_dev_min = -inf
                    crit_dev_max = -inf
                    qualitParam = True
                else:
                    bad_data = True
            elif norm_min==-inf or norm_max==-inf:
                if mod_dev_min==None and mod_dev_max==None and exp_dev_min==None and exp_dev_max==None and crit_dev_min==None and crit_dev_max==None:
                    mod_dev_min = inf
                    mod_dev_max = inf
                    exp_dev_min = inf
                    exp_dev_max = inf
                    crit_dev_min = inf
                    crit_dev_max = inf
                    qualitParam = True
                else:
                    bad_data = True
            else:
                bad_data = True
            
            # если данные неопределённые
            if bad_data:
                msg = (f"У параметра {data['param_name']} направление отклонения зон от зоны нормы НЕОПРЕДЕЛЕНО!"
                      f"\nПараметры заданных зон: норма = {[data.get('norm_min', None), data.get('norm_max', None)]}, умеренное отклонение = {(data.get('mod_dev_min', None), data.get('mod_dev_max', None))}, выраженное отклонение = {(data.get('exp_dev_min', None), data.get('exp_dev_max', None))}, критическое отклонение = {(data.get('crit_dev_min', None), data.get('crit_dev_max', None))}"
                      f"\nЗадача корректного сопоставления измеренных данных с зонами отклонения невозможна!")
                
                print(msg)
                raise ValueError(msg)
        
        # если всё в порядке можем устанавливать зоны в качестве свойств-атрибутов параметра
        setattr(self, 'norm_min', norm_min) # ключ norm_min
        setattr(self, 'norm_max', norm_max) # ключ norm_max
        
        # один из ключей norm_min или norm_max должен иметь значение. Иначе ошибка, так как создать словарь без заданного параметра невозможно
        if self.norm_min is None and self.norm_max is None:
            print(f"В переданном словаре не задано ориентировочное значение нормы!")
            raise ValueError(f"В переданном словаре не задано ориентировочное значение нормы!")
        
        setattr(self, 'mod_dev_min', mod_dev_min) # ключ mod_dev_min
        setattr(self, 'mod_dev_max', mod_dev_max) # ключ mod_dev_max
        
        setattr(self, 'exp_dev_min', exp_dev_min) # ключ exp_dev_min
        setattr(self, 'exp_dev_max', exp_dev_max) # ключ exp_dev_max
        
        setattr(self, 'crit_dev_min', crit_dev_min) # ключ crit_dev_min
        setattr(self, 'crit_dev_max', crit_dev_max) # ключ crit_dev_max
        
        # ключ system_name
        if 'system_name' in data:
            setattr(self, 'system_name', data['system_name'])
        else:
            setattr(self, 'system_name', None)
            print(f"Отсутствует ключ 'system_name' в переданном словаре!")
        
        # ключ organ_name
        if 'organ_name' in data:
            setattr(self, 'organ_name', data['organ_name'])
        else:
            setattr(self, 'organ_name', None)
            print(f"Отсутствует ключ 'organ_name' в переданном словаре!")
        
        # ключ consectary_name
        if 'consectary_name' in data:
            setattr(self, 'consectary_name', data['consectary_name'])
        else:
            setattr(self, 'consectary_name', None)
            print(f"Отсутствует ключ 'consectary_name' в переданном словаре!")
        
        # ключ gen_name
        if 'gen_name' in data:
            setattr(self, 'gen_name', data['gen_name'])
        else:
            setattr(self, 'gen_name', None)
            print(f"Отсутствует ключ 'gen_name' в переданном словаре!")
        
        # ключ age_min
        if 'age_min' in data:
            setattr(self, 'age_min', data['age_min'])
        else:
            setattr(self, 'age_min', None)
            print(f"Отсутствует ключ 'age_min' в переданном словаре!")
        
        # ключ age_max
        if 'age_max' in data:
            setattr(self, 'age_max', data['age_max'])
        else:
            setattr(self, 'age_max', None)
            print(f"Отсутствует ключ 'age_max' в переданном словаре!")
        
        # ключ tod_name
        if 'tod_name' in data:
            setattr(self, 'tod_name', data['tod_name'])
        else:
            setattr(self, 'tod_name', None)
            print(f"Отсутствует ключ 'tod_name' в переданном словаре!")
        
        # ключ deviation_name
        if 'deviation_name' in data:
            setattr(self, 'deviation_name', data['deviation_name'])
        else:
            setattr(self, 'deviation_name', None)
            print(f"Отсутствует ключ 'deviation_name' в переданном словаре!")
        
        # ключ pos_dyn_name
        if 'pos_dyn_name' in data:
            setattr(self, 'pos_dyn_name', data['pos_dyn_name'])
        else:
            setattr(self, 'pos_dyn_name', None)
            print(f"Отсутствует ключ 'pos_dyn_name' в переданном словаре!")
        
        # ключ neg_dyn_name
        if 'neg_dyn_name' in data:
            setattr(self, 'neg_dyn_name', data['neg_dyn_name'])
        else:
            setattr(self, 'neg_dyn_name', None)
            print(f"Отсутствует ключ 'neg_dyn_name' в переданном словаре!")
        
        # ключ priority_name
        if 'priority_name' in data:
            setattr(self, 'priority_name', data['priority_name'])
        else:
            setattr(self, 'priority_name', None)
            print(f"Отсутствует ключ 'priority_name' в переданном словаре!")
        
        # ключ weight_name
        if 'weight_name' in data:
            setattr(self, 'weight_name', toFloat(data['weight_name']))
        else:
            setattr(self, 'weight_name', None)
            print(f"Отсутствует ключ 'weight_name' в переданном словаре!")
        
        # ключ rec_name
        if 'rec_name' in data:
            setattr(self, 'rec_name', data['rec_name'])
        else:
            setattr(self, 'rec_name', None)
            print(f"Отсутствует ключ 'rec_name' в переданном словаре!")

    @property
    def name(self):
        return self.param_name

    @property
    def system(self):
        return self.system_name

    @property
    def organ(self):
        return self.organ_name

    @property
    def state(self):
        return self.state_name

    @property
    def consectary(self):
        return self.consectary_name

    @property
    def priority(self):
        return self.priority_name

    @property
    def weight(self):
        return self.weight_name

    @property
    def deviation(self):
        return self.deviation_name

    @property
    def tod(self):
        return self.tod_name

    @property
    def gender(self):
        return self.gen_name

    @property
    def recomendation(self):
        return self.rec_name

    @property
    def age(self):
        return type('Age', (object,), {'min': self.age_min, 'max': self.age_max})()

    @property
    def norm(self):
        return type('Norm', (object,), {'min': self.norm_min, 'max': self.norm_max})()

    @property
    def norm(self):
        return type('Norm', (object,), {'min': self.norm_min, 'max': self.norm_max})()

    @property
    def mod_dev(self):
        return type('ModDev', (object,), {'min': self.mod_dev_min, 'max': self.mod_dev_max})()

    @property
    def exp_dev(self):
        return type('ExpDev', (object,), {'min': self.exp_dev_min, 'max': self.exp_dev_max})()

    @property
    def crit_dev(self):
        return type('CritDev', (object,), {'min': self.crit_dev_min, 'max': self.crit_dev_max})()

    # вывести в лог данные объекта типа Parameter
    def print_prop(self, objName = "", extend = False):
        """
        Выводит в лог информацию о параметрах.

        Аргументы:
            objName (str, optional): Строка имени объекта, параметры которого необходимо вывести в лог
            extend (bool, optional): Если True, выводит подробную информацию о каждом параметре

        Результат:
            Вывод данных в лог

        Пример:
            >>> dos_param_0 = interpreter.Parameter(dos[0])
            >>> dos_param_0.print_prop(objName = 'dos_param_0')
        """
        if extend:
            for key, value in self.__dict__.items():
                print(f"{objName}.{key}:{value}")
        else:
            print(f"{objName}.name = {self.name}")
            print(f"{objName}.state = {self.state}")
            print(f"{objName}.organ = {self.organ}")
            print(f"{objName}.system = {self.system}")

# класс описывает все параметры из справочника параметров dos, базы данных kdl
class Parameters:
    """
    Класс представляет собой контейнер для объектов Parameter.
    Консруктор в качестве аргумента принимает список словарей, возвращаемые database.get_dos().
    
    Аргументы конструктора:
        dos (list(dict)): Список словарей, где каждый словарь представляет запись из таблицы DOS.
        В случае ошибки структуры и типов в dos вызывается исключение и возвращается код ошибки.

    Атрибуты класса:
        <param_name>_<id>: Объект Parameter, представляющий параметр с именем <param_name> и идентификатором <id>.

    Методы класса:
        print_prop(extend=False): Выводит в лог информацию о параметрах.

    Пример:
        >>> dos = database.get_dos(param_db)
        >>> params_template = Parameters(dos)
    """
    # инициализирует объект Parameters
    def __init__(self, dos):
        """
        Инициализирует объект Parameters.

        Аргументы:
            dos (list(dict)): Список словарей, представляющих параметры из таблицы DOS.

        Исключения:
            TypeError: Если `dos` не является списком словарей.
            KeyError: Если в словарях отсутствует необходимый ключ.
            ValueError: Если значения аргументов недопустимы.

        Замечания:
            - Каждый элемент списка `dos` должен быть словарём.
            - Каждый словарь должен содержать все необходимые ключи для создания объекта Parameter.
              Подробный список ключей можно найти в документации к функции database.get_dos().
        """
        if not isinstance(dos, list):
            print(f"Переданный аргумент dos, для создания объекта - словаря параметров, должен быть списком словарей!")
            raise TypeError(f"Переданный аргумент dos, для создания объекта - словаря параметров, должен быть списком словарей!")
        
        GENDER_MAP = { "Male" : "M", "M" : "M", "Мужчина" : "М", "Муж" : "М", "М" : "М", "Female" : "F", "F" : "F", "Женщина" : "Ж", "Жен" : "Ж", "Ж" : "Ж", }
        
        paramsNotLoaded = list()
        
        for item in dos:
            # создаём объект Parameter
            try:
                param_obj = Parameter(item)
            except TypeError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка типа при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise TypeError(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
                continue
            except KeyError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка ключа при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise KeyError(f"Отсутствует обязательный ключ в переданном словаре!")
                continue
            except ValueError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка значения при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise ValueError(f"Ошибка при создании объекта словаря параметров!")
                continue
            
            dos_id = item.get('id')
            
            # берём имя параметра и делаем его валидным идентификатором
            param_name_raw = item.get('param_name', '')
            name = param_name_raw
            # print(f"param_name_raw = {param_name_raw}")
            
            gen = GENDER_MAP.get(str(item.get('gen_name') or '').strip().lower(), '')
            
            age_min = item.get('age_min', '')
            age_max = item.get('age_max', '')
            
            attr_name = clean_identifier(param_name_raw)
            # if gen!= '':
            #     attr_name = attr_name + "_" + gen
            # if age_min is not None:
            #     attr_name = attr_name + "_" + str(age_min)
            # if age_max is not None:
            #     attr_name = attr_name + "_" + str(age_max)
            
            attr_name = attr_name + "_" + str(dos_id)
            # attr_name = str(dos_id) + "_" + attr_name # или так, хз как лучше
            
            # связываем атрибут с объектом класса Parameter
            setattr(self, attr_name, param_obj)
            setattr(self, 'paramsNotLoaded', paramsNotLoaded)

    # возвращает строковое представление объекта Parameters
    def __repr__(self):
        """
        Возвращает строковое представление объекта Parameters.
        """
        # attrs = ', '.join(f'{k}={v.param_name}' for k, v in self.__dict__.items())
        # return f'<Parameters {attrs}>'
        
        # attrs = ', '.join(
        #    f'{k}={v.param_name if hasattr(v, "param_name") else repr(v)}'
        #    for k, v in self.__dict__.items()
        
        attrs = ', '.join(
            f'{k}={getattr(v, "param_name", repr(v))}'
           for k, v in self.__dict__.items()
        )
        
        return f'<Parameters {attrs}>'

    # вывести в лог данные объекта типа Parameters
    def print_prop(self, extend = False):
        """
        Выводит в лог информацию о параметрах.

        Аргументы:
            extend (bool, optional): Подробная информация о каждом параметре, включая его атрибуты.

        Результат:
            Вывод данных в лог

        Пример:
            >>> params_template = Parameters(dos)       # Получит объект параметров.
            >>> params_template.print_prop()            # Выведет список имен параметров
            >>> params_template.print_prop(extend=True) # Выведет подробную информацию о каждом параметре
        """
        count = 0
        for attr_name, attr_value in self.__dict__.items():
            
            if not attr_name.startswith("__"):
                count += 1
                type_info = f", type = {type(attr_value).__name__}" if extend else ""
                print(f"{count} attr_name = {attr_name}{type_info}")
                if extend:
                    if isinstance(attr_value, Parameter):
                        attr_value.print_prop(attr_name, extend)
                    else:
                        print(f"{attr_name} = {attr_value}")

# вспомогательная функция используемая в функции getState
def iter_params(param_obj):
    """
    Генератор пар (ключ, значение) из любого объекта, который может быть представлен как dict или DictAttr.
    """
    # словарь или объект с методом items()
    if hasattr(param_obj, "items"):
        try:
            for k, v in param_obj.items():
                yield k, v
            return
        except TypeError:
            pass   # items() не итерируемый
    
    # атрибуты через __dict__ / vars()
    if hasattr(param_obj, "__dict__"):
        try:
            for k, v in param_obj.__dict__.items():
                yield k, v
            return
        except Exception:
            pass
    
    # параметр сам по себе итерируемый (например список кортежей)
    if hasattr(param_obj, "__iter__"):
        try:
            for k, v in param_obj: # предполагается (key, value) пары
                yield k, v
            return
        except Exception:
            pass
    
    raise TypeError(f"Не удалось распознать объект {param_obj!r} как набор параметров")

# функция определения вероятности состояния по данным измеренных параметров на основании соспоставления их со справочником параметров
def getState(params_dic, params):
    """
    Определить состояния, их вероятности сопоставляя данные params со справочными данными params_dic.

    Аргументы:
        params_dic (Parameters): Объект справочника параметров
        params (DictAttr): Справочник анализируемых параметров.

    Результат:
        Возвращает словарь с атрибутами, по каждому из которых хранится словарь состояния.

    Замечания:
        - Параметры состояний сортируются по выраженности и отклонению от нормы.
          Результат записывается в поля 'sort_params' и 'sort_params_text'.
        - Состояний НЕ отсортированны по значению критичности.
          Для сортировки использовать sortedStatesText().
          Для пересортировки параметров в состояниях использовать sortedParamsStateText().

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> state_patient = interpreter.getState(params_template, patientParamsList[3])
    """
    # определим с какой структурой данных словаря мы работаем. Это либо словарь, список словарей, либо словарь словарей
    paramsCheck = iter(params)
    firstKey = next(paramsCheck)
    
    if type(firstKey) is not DictAttr:
        firstVal = params[firstKey]
        if type(params[firstKey]) is not DictAttr:
            params_iter = [params]
        else:
            params_iter = params
    else:
        firstVal = None
        params_iter = params
    
    states = DictAttr()
    
    # перебираем параметры в измеренных параметрах
    for itemKey in params_iter:
        if type(itemKey) is DictAttr:
            item = itemKey
        else:
            item = params_iter[itemKey]
        
        id_research = item.get('research_id', None)
        id_patient = item.get('patient_id', None)
        item_val = toFloat(item.value)
        
        if item_val is not None:
            # перебираем параметры в справочнике
            for keyD, valD in iter_params(params_dic):
                if keyD=='paramsNotLoaded':
                    continue
                scoreMatch = fuzz.ratio(item.name.lower(), valD.name.lower())
                if scoreMatch>94:
                    if valD.gender==None or valD.gender.find(item.gender)>=0 or item.gender.find(valD.gender)>=0:
                        checkRangeAge = FloatInterval.closed(valD.age.min, valD.age.max)
                        if item.age in checkRangeAge:
                            # определяем среднее у нормы (по сути ядро нечёткого множества терма норма)
                            arrayValsNorm = list(filter(lambda x: x is not None, [toFloat(valD.norm.min), toFloat(valD.norm.max)]))
                            countValsNorm = len(arrayValsNorm)
                            if countValsNorm>0:
                                avgNorm = sum(arrayValsNorm)/countValsNorm # корректное вычисление среднего
                            else:
                                avgNorm = None
                                continue # переходим к следующему параметру
                            checkRangeNorm = FloatInterval.closed(toFloat(valD.norm.min), toFloat(valD.norm.max))
                            
                            # определяем среднее у умеренного отклонения (по сути ядро нечёткого множества терма умеренное отклонение)
                            arrayValsModDev = list(filter(lambda x: x is not None, [toFloat(valD.mod_dev.min), toFloat(valD.mod_dev.max)]))
                            countValsModDev = len(arrayValsModDev)
                            if countValsModDev>0:
                                avgModDev = sum(arrayValsModDev)/countValsModDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    # checkRangeModDev = FloatInterval.closed(toFloat(valD.mod_dev.min, 1), toFloat(valD.mod_dev.max, 1))
                                    checkRangeModDev = FloatInterval.closed(toFloat(getMin([valD.mod_dev.min, checkRangeNorm.upper]), 1), toFloat(valD.mod_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeModDev = FloatInterval.closed(toFloat(valD.mod_dev.min, -1), toFloat(getMax([valD.mod_dev.max, checkRangeNorm.lower]), -1))
                            else:
                                avgModDev = None
                                print(f"В справочнике отсутствуют опорные данные по умеренному отклонению параметра {valD.name}!")
                                continue # переходим к следующему параметру
                            
                            # определяем среднее у выраженного отклонения (по сути ядро нечёткого множества терма выраженное отклонение)
                            arrayValsExpDev = list(filter(lambda x: x is not None, [toFloat(valD.exp_dev.min), toFloat(valD.exp_dev.max)]))
                            countValsExpDev = len(arrayValsExpDev)
                            if countValsExpDev>0:
                                avgExpDev = sum(arrayValsExpDev)/countValsExpDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    checkRangeExpDev = FloatInterval.closed(toFloat(getMin([valD.exp_dev.min, checkRangeModDev.upper]), 1), toFloat(valD.exp_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeExpDev = FloatInterval.closed(toFloat(valD.exp_dev.min, -1), toFloat(getMax([valD.exp_dev.max, checkRangeModDev.lower]), -1))
                            elif avgNorm<avgModDev:
                                avgExpDev = float('inf')
                                checkRangeExpDev = FloatInterval.closed(checkRangeModDev.upper, float('inf'))
                            else:
                                avgExpDev = -float('inf')
                                checkRangeExpDev = FloatInterval.closed(-float('inf'), checkRangeModDev.lower)
                            
                            # определяем среднее у критического отклонения (по сути ядро нечёткого множества терма выраженное отклонение)
                            arrayValsCritDev = list(filter(lambda x: x is not None, [toFloat(valD.crit_dev.min), toFloat(valD.crit_dev.max)]))
                            countValsCritDev = len(arrayValsCritDev)
                            if countValsCritDev>0:
                                avgCritDev = sum(arrayValsCritDev)/countValsCritDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    checkRangeCritDev = FloatInterval.closed(toFloat(getMin([valD.crit_dev.min, checkRangeExpDev.upper]), 1), toFloat(valD.crit_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeCritDev = FloatInterval.closed(toFloat(valD.crit_dev.min, -1), toFloat(getMax([valD.crit_dev.max, checkRangeExpDev.lower]), -1))
                            elif avgNorm<avgModDev:
                                avgCritDev = float('inf')
                                checkRangeCritDev = FloatInterval.closed(checkRangeExpDev.upper, float('inf'))
                            else:
                                avgCritDev = -float('inf')
                                checkRangeCritDev = FloatInterval.closed(-float('inf'), checkRangeExpDev.lower)
                            
                            priority = 0.5 if valD.priority.lower().find('неоснов')>=0 else 1
                            weight = 1 if valD.weight is None else toFloat(valD.weight)
                            
                            # вхождение в checkRangeNorm не проверяем
                            
                            item_val = toFloat(item.value)
                            devZone = 0 # зона в которую отклонился параметр
                            # начинаем проверку с вхождения в критический диапазон значений (это необходимо для качественных параметров, типа положительно/отрицательно)
                            if item_val in checkRangeCritDev:
                                devZone = 4 # зона критического отклонения
                                
                            elif item_val in checkRangeExpDev:
                                devZone = 3 # зона выраженного отклонения
                                
                            elif item_val in checkRangeModDev:
                                devZone = 2 # зона умеренного отклонения
                                
                            if devZone>1:
                                stateName = clean_identifier(valD.state)
                                
                                if stateName in states:
                                    # обрабатываем качественный параметр типа, отрицательно/положительно
                                    if not math.isinf(avgNorm) or not math.isinf(item_val):
                                        dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val
                                        states[stateName].probality = weight * dev_value
                                    else:
                                        if avgNorm==float(-inf) or item_val==float(-inf):
                                            dev_value = '-nan'
                                        else:
                                            dev_value = 'nan'
                                        states[stateName].probality = item_val
                                else:
                                    states.setdefault(stateName, DictAttr())
                                    states[stateName].setdefault('research_id', id_research)
                                    states[stateName].setdefault('patient_id', id_patient)
                                    states[stateName].setdefault('name', valD.state)
                                    states[stateName].setdefault('probality', 0.)
                                    states[stateName].setdefault('params_main', DictAttr())
                                    states[stateName].setdefault('params_adv', DictAttr())
                                    
                                    # обрабатываем качественный параметр типа, отрицательно/положительно
                                    if not math.isinf(avgNorm) or not math.isinf(item_val):
                                        dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val
                                        states[stateName].probality = weight * dev_value
                                    else:
                                        if avgNorm==float(-inf) or item_val==float(-inf):
                                            dev_value = '-nan'
                                        else:
                                            dev_value = 'nan'
                                        states[stateName].probality = item_val
                                    
                                
                                # добавляем информацию о параметре использованном для определении состояния
                                # если параметр для состояния основной (обязательный)
                                if priority>=1:
                                    states[stateName].params_main[keyD] = DictAttr()
                                    # states[stateName].params_main[valD.name] = DictAttr()
                                    states[stateName].params_main[keyD]['system'] = valD.system
                                    states[stateName].params_main[keyD]['organ'] = valD.organ
                                    states[stateName].params_main[keyD]['name'] = item.name
                                    states[stateName].params_main[keyD]['consectary'] = valD.consectary
                                    states[stateName].params_main[keyD]['value'] = item.value
                                    states[stateName].params_main[keyD]['gender'] = item.gender
                                    states[stateName].params_main[keyD]['age'] = item.age
                                    states[stateName].params_main[keyD]['dev_zone'] = devZone
                                    states[stateName].params_main[keyD]['dev_value'] = dev_value
                                    states[stateName].params_main[keyD]['dynamic'] = valD.deviation
                                    states[stateName].params_main[keyD]['tod_name'] = valD.tod_name
                                    states[stateName].params_main[keyD]['rec_name'] = valD.rec_name
                                else:
                                    states[stateName].params_adv[keyD] = DictAttr()
                                    # states[stateName].params_adv[valD.name] = DictAttr()
                                    states[stateName].params_adv[keyD]['system'] = valD.system
                                    states[stateName].params_adv[keyD]['organ'] = valD.organ
                                    states[stateName].params_adv[keyD]['name'] = item.name
                                    states[stateName].params_adv[keyD]['consectary'] = valD.consectary
                                    states[stateName].params_adv[keyD]['value'] = item.value
                                    states[stateName].params_adv[keyD]['gender'] = item.gender
                                    states[stateName].params_adv[keyD]['age'] = item.age
                                    states[stateName].params_adv[keyD]['dev_zone'] = devZone
                                    states[stateName].params_adv[keyD]['dev_value'] = dev_value
                                    states[stateName].params_adv[keyD]['dynamic'] = valD.deviation
                                    states[stateName].params_adv[keyD]['tod_name'] = valD.tod_name
                                    states[stateName].params_adv[keyD]['rec_name'] = valD.rec_name
                                
                                # для формирования текста результата интерпретации по параметру
                                system_str = str(valD.system)
                                organ_str = str(valD.organ)
                                state_str = str(valD.state)
                                
                                # формируем текст результата
                                text_dict = dict()
                                text_dict[system_str] = dict()
                                text_dict[system_str][organ_str] = dict() # получаем справочник в виде {система{орган{состояние{}}}}
                                
                                # формируем отсортированный по dev_zone отклонения
                                dev_str_list = list()
                                # parmainadv_str_list = list()
                                if 'params_main' in states[stateName].keys() and 'params_adv' in states[stateName].keys():
                                    params_mainadv_values = list(states[stateName]['params_main'].values()) + list(states[stateName]['params_adv'].values())
                                    params_mainadv_sort = sorted(params_mainadv_values, key=lambda x: x['dev_zone'], reverse=True)
                                    
                                    # копируем строки описания наименования отклонений с отсортированного списка параметров
                                    for ipar in params_mainadv_sort:
                                        dev_str_list.append(ipar.dynamic)
                                
                                text_dict[system_str][organ_str][state_str] = dev_str_list # получаем справочник в виде {система{орган{состояние{[отсортированный_список_наименований_отклонений]}}}}
                                states[stateName]['sort_params_text'] = str(text_dict)
                                
    return states



# функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
def getState_by_reseach_id_and_save_to_base_v1(param_db, research_id, addValue=True, to_json=False):
    """
    Определить состояния, их вероятности по данным заданного исследования. 

    Аргументы:
        param_db (dict): Параметры подключения к базе данных.
        research_id (int): ID исследования с данными анализируемых параметров.
        addValue (bool, optional): Добавлять значение вероятности состояния и зоны в которую отклонился параметр.
        to_json (bool, optional): Формировать результат как json-строку. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния с данными по нему.
        Сохраняет результат в таблицу 'Conclusion' базы данных.

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_by_reseach_id = interpreter.getState_by_reseach_id_and_save_to_base_v1(param_db, 4, addValue=True)
    """
    dos = database.get_dos(param_db)
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    params_patient = database.get_research_by_id(param_db, research_id)
    # params_patient_dict = buildResearchParams(params_patient)
    params_patient_dict = buildResearchParams(params_patient)
    
    # определяем состояния и их вероятности
    # state_by_reseach_id = getState(params_template, params_patient_dict)
    state_by_reseach_id = getState(params_template, params_patient_dict)
    
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item])
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json)
    # sortStates = sortedStatesText_v2(state_patient)
    
    if not to_json:
        result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(sortStates), str(state_by_reseach_id))
    else:
        sortStatesText_json = json.dumps(sortStates, indent=None, ensure_ascii=False, default=str)
        result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStatesText_json, str(state_by_reseach_id))
    
    return state_by_reseach_id, record_id



# функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
def getState_by_reseach_id_and_save_to_base_v2(param_db, research_id, addValue=True, to_json=False):
    """
    Определить состояния, их вероятности у исследования с заданным идентификатором.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных.
        research_id (int): ID исследования с данными анализируемых параметров.
        addValue (bool, optional): Добавлять значение вероятности состояния и зоны в которую отклонился параметр.
        to_json (bool, optional): Формировать результат как json-строку. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния с данными по нему.
        Сохраняет результат в таблицу 'Conclusion' базы данных.

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_by_reseach_id, record_id = interpreter.getState_by_reseach_id_and_save_to_base(param_db, 4, True)
    """
    dos = database.get_dos(param_db) # считаем данные справочник с базы данных
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    # 1. считываем с базы по id запись исследования по измеренным анализам пациента
    params_patient = database.get_research_by_id(param_db, research_id)
    # params_patient_dict = buildResearchParams(params_patient)
    params_patient_dict = buildResearchParams(params_patient)
    
    # 2. определяем состояния и их вероятности
    # state_by_reseach_id = getState(params_template, params_patient_dict)
    state_by_reseach_id = getState(params_template, params_patient_dict)
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    
    # 4. сформируем отсортированный список состояний для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item])
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json)
    
    # 5. сформируем строку списка состояний для текста вывода в протоколе
    list_state_name = list() # список состояний
    sortedStates = getListSortedStates(state_by_reseach_id) # получим отсортированный список состояний
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        if 'name' in state:
            list_state_name.append(state['name'])
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_state_name) # сформируем строку списка состояний перечисленных через запятую
    
    # 6. сформируем строку рекомендаций для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient)
    
    if not to_json:
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(inter_result), str(state_by_reseach_id))
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            print(f"function getState_by_reseach_id_and_save_to_base():  End")
            return None, e
        
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStates_json, str(state_by_reseach_id))
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            print(f"function getState_by_reseach_id_and_save_to_base():  End")
            return None, e
    
    return state_by_reseach_id, record_id

# асинхронная функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
async def getState_by_reseach_id_and_save_to_base_async_v2(param_db, research_id, addValue=True, to_json=False):
    """
    Определить состояния, их вероятности по заданному исследовании. Асинхронная версия функции.
    Вызов через await (требует работающий event loop), или через asyncio.run.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных.
        research_id (int): ID исследования с данными анализируемых параметров.
        addValue (bool, optional): Добавлять значение вероятности состояния и зоны в которую отклонился параметр.
        to_json (bool, optional): Формировать результат как json-строку. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния с данными по нему.
        Сохраняет результат в таблицу 'Conclusion' базы данных.

    Пример:
        >>> from lab_data_interpreter.interpreter import getState_by_reseach_id_and_save_to_base_async
        >>> import asyncio
        >>> state_by_reseach_id, record_id = await getState_by_reseach_id_and_save_to_base_async(param_db, 4, True)
        или 
        >>> state_by_reseach_id, record_id = asyncio.run(getState_by_reseach_id_and_save_to_base_async(param_db, 4, True))
    """
    # считаем данные справочник с базы данных
    try:
        dos = await database_async.get_dos_async(param_db)
    except Exception as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): При запросе справочных данных параметров из таблицы 'DOS' у базы данных возникла ошибка: {e}")
        return None, e
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): При создании объекта словаря параметров возникала ошибка: {e}")
    
    # 1. считываем с базы по id запись исследования по измеренным анализам пациента
    try:
        params_patient = await database_async.get_research_by_id_async(param_db, research_id)
    except Exception as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): Возникла ошибка при попытке запроса по id запись по измеренным анализам пациента из таблицы 'Research' у базы данных {e}")
        return None, e
    
    # params_patient_dict = buildResearchParams(params_patient)
    params_patient_dict = buildResearchParams(params_patient)
    
    # 2. определяем состояния и их вероятности
    # state_by_reseach_id = getState(params_template, params_patient_dict)
    state_by_reseach_id = getState(params_template, params_patient_dict)
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    
    # 4. сформируем отсортированный список состояний для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item])
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json)
    
    # 5. сформируем строку списка состояний для текста вывода в протоколе
    list_state_name = list() # список состояний
    sortedStates = getListSortedStates(state_by_reseach_id) # получим отсортированный список состояний
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        if 'name' in state:
            if state['name'] not in list_state_name:
                list_state_name.append(state['name'])
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_state_name) # сформируем строку списка состояний перечисленных через запятую
    
    # 6. сформируем строку рекомендаций для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient)
    
    if not to_json:
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, str(inter_result), str(state_by_reseach_id))
            
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            print(f"function getState_by_reseach_id_and_save_to_base_async():  End")
            return None, e
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, sortStates_json, str(state_by_reseach_id))
            
        except Exception as e:
            print(f"function get_states(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            print(f"getState_by_reseach_id_and_save_to_base_async(): End")
            return None, e
        
    return state_by_reseach_id, record_id



# функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
def getStates_by_reseachs_in_day_and_save_to_base(param_db, research_main_id, addValue=True, to_json=False):
    """
    Определить состояния и их вероятности по данным измеренных параметров исследования по его идентификатору, на основании соспоставления их со справочником параметров, 
    отсортировать состояния по степени их значимости и сохранить результаты в таблицу 'Conclusion' базы данных.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        research_id (int): ID исследования с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему.
        Возвращает идентификатор записи в таблице Conclusion базы данных: int

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_by_reseach_id, record_id = interpreter.getStates_by_reseachs_in_day_and_save_to_base(param_db, 4, addValue=True)
    """
    dos = database.get_dos(param_db) # считаем данные справочник с базы данных
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
    except (TypeError, KeyError, ValueError) as e:
        print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    # 1. считываем с базы все исследования в день, определяемый по id записи исследования 
    researchs_in_day = database.get_researchs_by_date_from_id(param_db, research_main_id)
    research_common_in_day = mergeResearchs_to_ResearchCommon(researchs_in_day, research_main_id) # объединим все записи исследований за день в одну общую запись исследования
    
    # 2. определяем состояния и их вероятности
    i = 0
    while i<len(research_common_in_day):
        if i>0:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения. research_common_in_day должен содержать один элемент.len(research_common_in_day) = {len(research_common_in_day)}")
            break
        states_patient_in_day = getState(params_template, research_common_in_day[i])
        i += 1
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    # id_research, id_patient = next( ((v.get('research_main_id', None), v.get('patient_id', None)) for v in states_patient_in_day.values()), (None, None) )
    id_research, id_patient = getResearchID_PatientID(states_patient_in_day)
    
    # 4. сформируем отсортированный список состояний 'conclusion' для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии. Объект states_patient_in_day[item] модифицируется
    if len(states_patient_in_day)>0:
        for item in states_patient_in_day:
            sortParam = sortedParamsStateText(states_patient_in_day[item], addValue, to_json)
            # sortParam_v2 = sortedParamsStateText_v2(states_patient_in_day[item])
    
    # сортируем по тяжести состояния. Объект states_patient_in_day модифицируется
    sortStates = sortedStatesText(states_patient_in_day, addValue, to_json)
    # sortStates_v2 = sortedStatesText(states_patient_in_day, addValue, to_json)
    
    # 5. сформируем строку списка выводов 'recap' для текста вывода в протоколе
    list_consectarys_name = list() # список выводов
    sortedStates = getListSortedStates(states_patient_in_day) # получим отсортированный список состояний
    
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        if 'params_main' in state:
            for item in state['params_main'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_main словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main в словаре состояния полученного от getState()!")
        
        if 'params_adv' in state:
            for item in state['params_adv'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_adv словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_consectarys_name) # сформируем строку списка выводов перечисленных через запятую
    
    # 6. сформируем строку рекомендаций 'recomend' для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в конец списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient)
    
    if not to_json:
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(inter_result), str(states_patient_in_day))
        except Exception as e:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            return None, e
        
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStates_json, str(states_patient_in_day))
        except Exception as e:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            return None, e
    
    return states_patient_in_day, record_id

# асинхронная функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
async def getStates_by_reseachs_in_day_and_save_to_base_async(param_db, research_main_id, addValue=True, to_json=False):
    """
    Определить состояния и их вероятности по данным измеренных параметров исследования по его идентификатору, на основании соспоставления их со справочником параметров, 
    отсортировать состояния по степени их значимости и сохранить результаты в таблицу 'Conclusion' базы данных.
    Функция асинхронная. Вызов через await (требует работающий event loop), или через asyncio.run(через запуск event loop и передачи ему корутины для исполнения).

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        research_id (int): ID исследования с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему.
        Возвращает идентификатор записи в таблице Conclusion базы данных: int

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json, asyncio
        >>> state_by_reseach_id, record_id = await interpreter.getState_by_reseach_id_and_save_to_base_async(param_db, 4, addValue=True, to_json=False)
    """
    # считаем данные справочник с базы данных
    try:
        dos = await database_async.get_dos_async(param_db)
    except Exception as e:
        print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): При запросе справочных данных параметров из таблицы 'DOS' у базы данных возникла ошибка: {e}")
        return None, e
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
    except (TypeError, KeyError, ValueError) as e:
        print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): При создании объекта словаря параметров возникала ошибка: {e}")
    
    # 1. считываем с базы по id запись исследования по измеренным анализам пациента
    try:
        params_patient = await database_async.get_research_by_id_async(param_db, research_main_id)
    except Exception as e:
        print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Возникла ошибка при попытке запроса по id запись по измеренным анализам пациента из таблицы 'Research' у базы данных {e}")
        return None, e
    
    # params_patient_dict = buildResearchParams(params_patient)
    params_patient_dict = buildResearchParams(params_patient)
    
    # 2. определяем состояния и их вероятности
    states_patient_in_day = getState(params_template, params_patient_dict)
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_main_id', None), v.get('patient_id', None)) for v in states_patient_in_day.values()), (None, None) )
    id_research, id_patient = getResearchID_PatientID(states_patient_in_day)
    
    # 4. сформируем отсортированный список состояний 'conclusion' для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии. Объект states_patient_in_day модифицируется
    if len(states_patient_in_day)>0:
        for item in states_patient_in_day:
            # sortParam = sortedParamsStateText(states_patient_in_day[item], addValue, to_json)
            sortParam = sortedParamsStateText(states_patient_in_day[item], addValue, to_json)
            # sortParam_v2 = sortedParamsStateText_v2(states_patient_in_day[item])
    
    # сортируем по тяжести состояния. Объект states_patient_in_day модифицируется
    sortStates = sortedStatesText(states_patient_in_day, addValue, to_json)
    # sortStates_v2 = sortedStatesText_v2(states_patient_in_day)
    
    # 5. сформируем строку списка выводов 'recap' для текста вывода в протоколе
    list_consectarys_name = list() # список выводов
    sortedStates = getListSortedStates(states_patient_in_day) # получим отсортированный список состояний
    
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        if 'params_main' in state:
            for item in state['params_main'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_main словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main в словаре состояния полученного от getState()!")
        
        if 'params_adv' in state:
            for item in state['params_adv'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_adv словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_consectarys_name) # сформируем строку списка выводов перечисленных через запятую
    
    # 6. сформируем строку рекомендаций 'recomend' для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    if not to_json:
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, str(inter_result), str(states_patient_in_day))
            
        except Exception as e:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            return None, e
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, sortStates_json, str(states_patient_in_day))
            
        except Exception as e:
            print(f"getStates_by_reseachs_in_day_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            return None, e
        
    
    return states_patient_in_day, record_id



# функция определения состояний по списку исследований
def getStates_by_reseachs_list_and_save_to_base(param_db, researchs_id_list, addValue=True, to_json=False):
    """
    Определить состояния и их вероятности по данным из списка исследований, заданных списком их идентификаторов.
    Состояния определяються посредством соспоставления измеренных параметров со справочником параметров.
    Состояния сортируются по степени их значимости и сохраняются как результатат в таблицу 'Conclusion' в базе данных.
    
    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        researchs_id_list (int): Список ID исследований с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено 
                                         числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. 
                                  По умолчанию False - результат формируется как строка.
    
    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему.
        Возвращает идентификатор записи в таблице Conclusion базы данных: int
    
    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> researchs_id_list = [4,5,6,7]
        >>> states_patient_by_list, record_id = interpreter.getStates_by_reseachs_list_and_save_to_base(param_db, researchs_id_list, addValue=True, to_json=False)
    """
    dos = database.get_dos(param_db) # считаем данные справочник с базы данных
    
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
    except (TypeError, KeyError, ValueError) as e:
        print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    # 1. считываем с базы список исследований по списку id исследований
    researchs_list = database.get_researchs_by_list_id(param_db, researchs_id_list)
    research_common = mergeResearchs_to_ResearchCommon(researchs_list, researchs_id_list[len(researchs_id_list)-1]) # объединим все записи исследований за день в одну общую запись исследования
    
    # 2. определяем состояния и их вероятности
    i = 0
    while i<len(research_common):
        if i>0:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения. research_common должен содержать один элемент.len(research_common) = {len(research_common)}")
            break
        states_patient = getState(params_template, research_common[i])
        i += 1
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    # id_research, id_patient = next( ((v.get('research_main_id', None), v.get('patient_id', None)) for v in states_patient.values()), (None, None) )
    id_research, id_patient = getResearchID_PatientID(states_patient)
    
    # 4. сформируем отсортированный список состояний 'conclusion' для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии. Объект states_patient[item] модифицируется
    if len(states_patient)>0:
        for item in states_patient:
            sortParam = sortedParamsStateText(states_patient[item], addValue, to_json)
            # sortParam_v2 = sortedParamsStateText_v2(states_patient[item])
    
    # сортируем по тяжести состояния. Объект states_patient модифицируется
    sortStates = sortedStatesText(states_patient, addValue, to_json)
    # sortStates_v2 = sortedStatesText(states_patient, addValue, to_json)
    
    # 5. сформируем строку списка выводов 'recap' для текста вывода в протоколе
    list_consectarys_name = list() # список выводов
    sortedStates = getListSortedStates(states_patient) # получим отсортированный список состояний
    
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        if 'params_main' in state:
            for item in state['params_main'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_main словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main в словаре состояния полученного от getState()!")
        
        if 'params_adv' in state:
            for item in state['params_adv'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_adv словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_consectarys_name) # сформируем строку списка выводов перечисленных через запятую
    
    # 6. сформируем строку рекомендаций 'recomend' для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в конец списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient)
    
    if not to_json:
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(inter_result), str(states_patient))
        except Exception as e:
            print(f"getStates_by_reseachs_list_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            return None, e
        
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStates_json, str(states_patient))
        except Exception as e:
            print(f"getStates_by_reseachs_list_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            return None, e
    
    return states_patient, record_id

# асинхронная функция определения состояний по списку исследований
async def getStates_by_reseachs_list_and_save_to_base_async(param_db, researchs_id_list, addValue=True, to_json=False):
    """
    Определить состояния и их вероятности по данным из списка исследований, заданных списком их идентификаторов.
    Состояния определяються посредством соспоставления измеренных параметров со справочником параметров.
    Состояния сортируются по степени их значимости и сохраняются как результатат в таблицу 'Conclusion' в базе данных.
    Функция асинхронная. Вызов через await (требует работающий event loop), или через asyncio.run(через запуск event loop и передачи ему корутины для исполнения).

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        researchs_id_list (int): Список ID исследований с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему.
        Возвращает идентификатор записи в таблице Conclusion базы данных: int

    Пример:
    """
    # 1. считаем данные справочник с базы данных
    try:
        dos = await database_async.get_dos_async(param_db)
    except Exception as e:
        print(f"getStates_by_reseachs_list_and_save_to_base_async(): При запросе справочных данных параметров из таблицы 'DOS' у базы данных возникла ошибка: {e}")
        return None, e
    
    # 2. создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos)
    except (TypeError, KeyError, ValueError) as e:
        print(f"getStates_by_reseachs_list_and_save_to_base_async(): При создании объекта словаря параметров возникала ошибка: {e}")
    
    # 3. считываем с базы список исследований, по списку их id
    try:
        researchs_list = await database_async.get_researchs_by_list_id_async(param_db, researchs_id_list)
    except Exception as e:
        print(f"getStates_by_reseachs_list_and_save_to_base_async(): Возникла ошибка при попытке запроса списка записей по списку их id из таблицы 'Research' базы данных {e}")
        return None, e
    
    research_common = mergeResearchs_to_ResearchCommon(researchs_list, researchs_id_list[len(researchs_id_list)-1]) # объединим все записи списка исследований в одну общую запись исследования
    
    # 3. считываем с базы все исследования в день, определяемый по id записи исследования 
    # researchs_list = database_async.get_researchs_by_list_id(param_db, researchs_id_list)
    research_common = mergeResearchs_to_ResearchCommon(researchs_list, researchs_id_list[len(researchs_id_list)-1]) # объединим все записи исследований за день в одну общую запись исследования
    
    # 4. определяем состояния и их вероятности
    i = 0
    while i<len(research_common):
        if i>0:
            print(f"getStates_by_reseachs_list_and_save_to_base(): Ошибка в логике исполнения. research_common должен содержать один элемент.len(research_common) = {len(research_common)}")
            break
        states_patient = getState(params_template, research_common[i])
        i += 1
    
    # 5. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_main_id', None), v.get('patient_id', None)) for v in states_patient.values()), (None, None) )
    id_research, id_patient = getResearchID_PatientID(states_patient)
    
    # 6. сформируем отсортированный список состояний 'conclusion' для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии. Объект states_patient модифицируется
    if len(states_patient)>0:
        for item in states_patient:
            # sortParam = sortedParamsStateText(states_patient[item], addValue, to_json)
            sortParam = sortedParamsStateText(states_patient[item], addValue, to_json)
            # sortParam_v2 = sortedParamsStateText_v2(states_patient[item])
    
    # сортируем по тяжести состояния. Объект states_patient модифицируется
    sortStates = sortedStatesText(states_patient, addValue, to_json)
    # sortStates_v2 = sortedStatesText_v2(states_patient)
    
    # 7. сформируем строку списка выводов 'recap' для текста вывода в протоколе
    list_consectarys_name = list() # список выводов
    sortedStates = getListSortedStates(states_patient) # получим отсортированный список состояний
    
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        if 'params_main' in state:
            for item in state['params_main'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_main словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main в словаре состояния полученного от getState()!")
        
        if 'params_adv' in state:
            for item in state['params_adv'].values():
                if 'consectary' in item:
                    if item['consectary'] not in list_consectarys_name:
                        if item['consectary']:
                            list_consectarys_name.append(item['consectary'])
                else:
                    print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ consectary в словаре params_adv словаря состояния полученного от getState()!")
        else:
            print(f"getStates_by_reseachs_in_day_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        
        i += 1
    recap_str = 'Выявлены лабораторные признаки: \n' + ', '.join(list_consectarys_name) # сформируем строку списка выводов перечисленных через запятую
    
    # 8. сформируем строку рекомендаций 'recomend' для текста рекомендаций в протоколе
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        state = sortedStates[i]
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 9. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    if not to_json:
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, str(inter_result), str(states_patient))
            
        except Exception as e:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            return None, e
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, sortStates_json, str(states_patient))
            
        except Exception as e:
            print(f"getStates_by_reseachs_list_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            return None, e
        
    
    return states_patient, record_id



# функции для определения критичности состояния
# отсортировать в тексте интерпретации объекта списка состояний, возвращённой функцией getState(), основные и неосновные параметры отклонений по выраженности и отклонению от нормы
def sortedParamsStateText(state, addParamValue=True, to_json=False):
    """
    Сортирует параметры по выраженности и отклонению от нормы в объекте состояний:
     - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.
    
    Аргументы:
        state (DictAttr): Объект состояния с данными основных и неосновных параметров.
        addParamValue (bool, optional): Добавлять значение зоны отклонения параметра в результат.
        to_json (bool, optional): Формировать результат как json-строка.
    
    Результат:
        Возвращает объект состояния с отсортированными параметрами
        В переданном объекте state изменяются/добавляются поля:
         - 'sort_params' объект состояния с отсортированными параметрами
         - 'sort_params_text' строковое преставление 'sort_params'
         - 'params_main_sort' - список отсортированных основных параметров
         - 'params_adv_sort' - список отсортированных неосновных параметров
         - 'params_mainadv_sort' - список отсортированных основных и неосновных параметров
    
    Пример:
        >>> result = sortedParamsStateText(state, True)
        >>> print(result)
        >>> print(state.sort_params_text)
    """
    # для формирования текста результата интерпретации по параметру
    system_str = '' # система
    organ_str = '' # органы
    state_str = state.name # состояние
    
    if len(state.params_main)>0:
        for k,v in state.params_main.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    else:
        for k,v in state.params_adv.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    
    # формируем текст результата
    sort_params_dict = dict()
    sort_params_dict[system_str] = dict()
    sort_params_dict[system_str][organ_str] = dict()
    
    # формируем отсортированный по dev_zone отклонения
    dev_str_list = list()
    # parmainadv_str_list = list()
    if 'params_main' in state.keys() and 'params_adv' in state.keys():
        params_main_sort = sorted(list(state['params_main'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_adv_sort = sorted(list(state['params_adv'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_mainadv_sort = params_main_sort + params_adv_sort
        
        # копируем строки описания наименования отклонений с отсортированного списка параметров
        for ipar in params_mainadv_sort:
            if addParamValue:
                # dev_str_list.append( ''.join([str(ipar.dynamic), ' (', str(ipar.value), ' ', str(ipar.tod_name), '):', str(ipar.dev_zone)]) )
                str_tod_name = '' if ipar.get('tod_name') is None else str(ipar.get('tod_name', ''))
                str_tod_name = (' ' + str_tod_name) if str_tod_name!='' else str_tod_name
                dev_str_list.append( ''.join([str(ipar.get('dynamic', '')), ' (', str(ipar.get('value', '')), str_tod_name, '):', str(ipar.get('dev_zone', ''))]) )
            else:
                # dev_str_list.append(ipar.dynamic)
                dev_str_list.append(ipar.get('dynamic', ''))
            # dev_str_list.append(ipar[''])
    
    sort_params_dict[system_str][organ_str][state_str] = dev_str_list # получаем словарь в виде {система{орган{состояние{[отсортированный_список_наименований_отклонений]}}}}
    state['params_main_sort'] = params_main_sort
    state['params_adv_sort'] = params_adv_sort
    state['params_mainadv_sort'] = params_mainadv_sort
    state['sort_params'] = sort_params_dict
    if not to_json:
        state['sort_params_text'] = str(sort_params_dict)
    else:
        state['sort_params_text'] = json.dumps(sort_params_dict, indent=None, ensure_ascii=False, default=str)
    
    return sort_params_dict

# отсортировать в тексте интерпретации объекта списка состояний, возвращённой функцией getState(), основные и неосновные параметры отклонений по выраженности и отклонению от нормы
def sortedParamsStateText_v2(state):
    """
    Сортирует параметры по выраженности и отклонению от нормы в объекте состояний.
     - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.
   
    Аргументы:
        state (DictAttr): Объект состояния с данными основных и неосновных параметров.
    
    Результат:
        В переданном объекте state изменяются/добавляются поля:
         - 'sort_params_v2' объект состояния с отсортированными параметрами
         - 'sort_params_text_v2' строковое преставление 'sort_params_v2'
    
    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> if len(state_patient)>0:
        >>>     for item in state_patient:
        >>>         sortParamStr = interpreter.sortedParamsStateText_v2(state_patient[item])
        >>>     sortStatesTest = interpreter.sortedStatesText_v2(state_patient)
    """
    # для формирования текста результата интерпретации по параметру
    system_str = '' # система
    organ_str = '' # органы
    state_str = state.name # состояние
    
    if len(state.params_main)>0:
        for k,v in state.params_main.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    else:
        for k,v in state.params_adv.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    
    # формируем текст результата
    sort_params_dict = dict()
    sort_params_dict[system_str] = dict()
    sort_params_dict[system_str][organ_str] = dict()
    
    # формируем отсортированный по dev_zone отклонения
    if 'params_main' in state.keys() and 'params_adv' in state.keys():
        params_main_sort = sorted(list(state['params_main'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_adv_sort = sorted(list(state['params_adv'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_mainadv_sort = params_main_sort + params_adv_sort
    
    # сформируем отсортированные параметры в другом формате данных
    # перебирём отсортированные основные параметры
    params_main_list = list()
    i = 0
    while i<len(params_main_sort):
        param_sys = params_main_sort[i].get('system', None)
        param_org = params_main_sort[i].get('organ', None)
        param_name = params_main_sort[i].get('name', None)
        param_value = params_main_sort[i].get('value', None)
        param_dev_value = params_main_sort[i].get('dev_value', None)
        param_dev_zone = params_main_sort[i].get('dev_zone', None)
        param_dynamic = params_main_sort[i].get('dynamic', None)
        param_data = {'name':param_name, 'value':param_value, 'dev_zone':param_dev_zone, 'dev_value':param_dev_value, 'dynamic':param_dynamic }
        params_main_list.append(param_data)
        
        i += 1
    
    # перебирём отсортированные неосновные параметры
    params_adv_list = list()
    i = 0
    while i<len(params_adv_sort):
        param_sys = params_adv_sort[i].get('system', None)
        param_org = params_adv_sort[i].get('organ', None)
        param_name = params_adv_sort[i].get('name', None)
        param_value = params_adv_sort[i].get('value', None)
        param_dev_value = params_adv_sort[i].get('dev_value', None)
        param_dev_zone = params_adv_sort[i].get('dev_zone', None)
        param_dynamic = params_adv_sort[i].get('dynamic', None)
        param_data = {'name':param_name, 'value':param_value, 'dev_zone':param_dev_zone, 'dev_value':param_dev_value, 'dynamic':param_dynamic }
        params_adv_list.append(param_data)
        
        i += 1
    
    states_list = list()
    state_dic = {'name':state['name'], 'probality':state['probality'], 'params_main':params_main_list, 'params_adv':params_adv_list}
    states_list.append(state_dic)
    
    organ_list = list()
    organ_dic = {'name':organ_str, 'state':states_list}
    organ_list.append(organ_dic)
    
    system_list = list()
    system_dic = {'name':system_str, 'organ':organ_list}
    system_list.append(system_dic)
    
    sort_params_v2 = {'system':system_list}
    
    state['sort_params_v2'] = sort_params_v2
    state['sort_params_text_v2'] = str(sort_params_v2)
    # state['sort_params_text_v2'] = json.dumps(sort_params_v2, indent=None, ensure_ascii=False, default=str)
    
    return sort_params_v2

# получить список отсортированных элементов словаря в порядке наиболее критичных по вероятности, так и по значениям отклонения основных и неосновных параметров от нормы
def getListSortedStates(states):
    """
    Сортирует элементы-состояния словаря 'states'.
    
    Аргументы:
        states (DictAttr): Объект с данными состояний.
    
    Результат:
        Возвращает список элементов list(DictAttr) словаря 'states', отсортированный по следующим критериям:
        - probality (по убыванию)
        - params_main.dev_zone и params_main.dev_value 
        (если params_main содержит данные, то сначала dev_zone, потом dev_value)
        - params_adv.dev_zone и params_adv.dev_value 
        (если params_adv содержит данные, то сначала dev_zone, потом dev_value)
    
    Пример:
        >>> states_patient = interpreter.getState(params_template, patientParams)
        >>> sorted_states_list = getListSortedStates(states_patient)
    """
    # подфункция получения значений ключей, по который выполняется сортировка
    def sorting_key(state):
        probality = state.get('probality', None)
        params_main = state.get('params_main')
        params_adv = state.get('params_adv')
        
        # сформируем кортеж для сортировки по нескольким критериям. Отсутствующие значения обозначим -inf
        dev_zone_main = float('-inf')
        dev_value_main = float('-inf')
        if params_main:
            for item in params_main.values():
                value = item.get("dev_zone", float('-inf'))
                if value>dev_zone_main:
                    dev_zone_main = value
                value = item.get("dev_value", float('-inf'))
                if value>dev_value_main:
                    dev_value_main = value
        
        dev_zone_adv = float('inf')
        dev_value_adv = float('inf')
        if params_adv:
            for item in params_main.values():
                value = item.get("dev_zone", float('-inf'))
                if value>dev_zone_adv:
                    dev_zone_adv = value
                value = item.get("dev_value", float('-inf'))
                if value>dev_value_adv:
                    dev_value_adv = value
        
        return (dev_zone_main, dev_value_main, probality, dev_zone_adv, dev_value_adv) # сортировка выполняется сначала по dev_zone_main, потом dev_value_main и т.д.
    
    filtered_states = (state for state in states.values() if isinstance(state, dict) and 'probality' in state)
    sorted_states = sorted(filtered_states, key=sorting_key, reverse=True)
    
    return sorted_states

# в объекте словаря состояний, возвращённой функцией getState(), сформировать строку отсортированных состояний по их степени тяжести
def sortedStatesText(states, addStateValue=True, to_json=False):
    """
    Сортирует состояния по тяжести в объекте состояний:
     - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.

    Аргументы:
        states (DictAttr): Объект с данными состояний.
        addStateValue (bool): Добавлять значение степени тяжести к наименованию состояния.
        to_json (bool, optional): Формировать как json-строку. По умолчанию формируется как строка.

    Результат:
        В переданном объекте states изменяются/добавляются поля:
         - 'sort_states' объект списка отсортированных состояний с отсортированными параметрами
         - 'sort_params_text' содержащее строковое представление sort_states

    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> sortStatesTest = interpreter.sortedStatesText(state_patient, True)
        >>> print(sortStatesTest)
        >>> print(state_patient.sortStatesTest)
    """
    # для формирования текста результата интерпретации по параметру
    system_str = None # система
    organ_str = None # органы
    state_str = None # состояние
    params_str = None # отсортированный список параметров
    
    sort_states_list = list()
    
    sortedStates = getListSortedStates(states) # получим список состояний отсортированных по тяжести
    sortedStatesTest_json = json.dumps(sortedStates, indent=2, ensure_ascii=False, default=str)
    
    for item in sortedStates:
        if addStateValue:
            state_str = ':'.join([str(item.name), str(round(toFloat(item.probality), 2))])
        else:
            state_str = item.name
        
        if 'params_main' in item and item.params_main and len(item.params_main):
            system_str, organ_str = next(((v.get('system', None), v.get('organ', None)) for v in item.params_main.values()), (None,None))
        
        elif 'params_adv' in item and item.params_adv and len(item.params_adv):
            system_str, organ_str = next(((v.get('system', None), v.get('organ', None)) for v in item.params_adv.values()), (None,None))
        
        sort_params = item.get('sort_params_text', None)
        
        sort_params_dict = dict()
        sort_params_list = list()
        if type(eval(sort_params))==dict:
            sort_params_dict = eval(sort_params)
            valList = None
            if len(sort_params_dict)>0:
                valList = next( v3 for v3 in next( v2 for v2 in next( v1 for v1 in sort_params_dict.values() ).values() ).values() )
            if type(valList)==list:
                sort_params_list = valList
        
        sort_params_dict = {system_str:{organ_str:{state_str:sort_params_list}}}
        
        sort_states_list.append(sort_params_dict)
    
    states['sort_states'] = sort_states_list
    if not to_json:
        states['sort_states_text'] = str(sort_states_list)
    else:
        states['sort_states_text'] = json.dumps(sort_states_list, indent=None, ensure_ascii=False, default=str)
    
    return sort_states_list

# в объекте словаря состояний, возвращённой функцией getState(), сформировать строку отсортированных состояний по их степени тяжести
def sortedStatesText_v2(states):
    """
    Сортирует состояния по тяжести в объекте словаря состояний:
     - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.

    Аргументы:
        states (DictAttr): Объект c данными состояний.
        addStateValue (bool): Добавлять значение степени тяжести к наименованию состояния.

    Результат:
        В переданном объекте states изменяются/добавляются поля:
         - 'sort_states_v2' объект списка отсортированных состояний с отсортированными параметрами
         - 'sort_states_text_v2' строковое представление sort_states_v2

    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> sortStatesTest2 = interpreter.sortedStatesText_v2(state_patient)
        >>> print(state_patient.sortStatesTest2)
    """
    # для формирования текста результата интерпретации по параметру
    system_str = None # система
    organ_str = None # органы
    state_str = None # состояние
    params_str = None # отсортированный список параметров
    
    sort_states_list = list()
    states_json = json.dumps(states, indent=2, ensure_ascii=False, default=str)
        
    sortedStates = getListSortedStates(states) # получим список состояний отсортированных по тяжести
    sortedStatesTest_json = json.dumps(sortedStates, indent=2, ensure_ascii=False, default=str)
    
    # перебираем отсортированные состояния для формирования строки отчёта
    for item in sortedStates:
        sort_params = item.get('sort_params_text_v2', None)
        
        sort_params_dict = dict()
        
        # sort_params_list = list()
        
        if type(eval(sort_params))==dict:
            sort_params_dict = eval(sort_params)
            
        
        sort_states_list.extend(sort_params_dict.get('system', None))
    
    sort_states_dict = {'system':sort_states_list }
    
    states['sort_states_v2'] = sort_states_dict
    states['sort_states_text_v2'] = str(sort_states_dict)
    
    return sort_states_dict





# вспомогательные функции обработки данных объекта состояния
# функция разбивает текст с измеренными параметрами анализов на отдельные наименования анализова и их значения
# учитывается два разделителя ';' и ' ' в значениях параметров
def parsParamsText(strDatRsch:str, sepLine:str):
    """
    Разбивает текст с параметрами на отдельные наименования и их значения.

    Аргументы:
        strDatRsch (str): Строка наименования параметров и их значений.
        sepLine (str): Строка разделителя параметров друг от друга.

    Результат:
    Возвращает словарь с атрибутами в качестве параметров.

    Пример:
        >>> paramsDict = interpreter.parsParamsText(strDatRschList[i], '\r\n')
    """
    params = DictAttr()
    for line in strDatRsch.split(sepLine):
        sep = [':']
        temp = split_by_separators(line, sep, 1)
        
        if len(temp)>0:
            sep = [';',' ']
            temp1 = split_by_separators(temp[1], sep)
            
            iVal, Val = find_number_with_index(temp1)
        
        nameParam = clean_identifier(temp[0])
        
        params.setdefault(nameParam, DictAttr())
        params[nameParam].setdefault('name', temp[0])
        if iVal is not None:
            params[nameParam].setdefault('value', toFloat(temp1[iVal]))
        else:
            params[nameParam].setdefault('value', None)
    
    return params

# извлекает из 'data' словаря с данными иследования данные, и формирует словарь с атрибутами из данных параметров
def buildResearchParams(data_research:dict):
    """
    Извлекает данные параметров из словаря данных иследования, формируя словарь с атрибутами.

    Аргументы:
        data_research (dict): Словарь данных исследования из таблицы 'research' базы данных.

    Результат:
        Возвращает список словарей с атрибутами представляющих запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
                  Структура возвращаемого словаря с атрибутами:
                  { str: {'name': str, 'value': float, 'research_id': int, 'patient_id': int, 'date': datetime, 'gender': str, 'age': int}, }
        Возвращает None, если не удается получить данные.

    Пример:
        # считываем с базы список исследований
        researchs = database.get_researchs(param_db)
        patientParamsList = list()
        # извлечём из списка иследований лабораторные данные
        i = 0
        while i<len(researchs):
            patientParamsList.append(interpreter.buildResearchParams(researchs[i]))
            i += 1
    """
    result = None
    if 'data' in data_research:
        patientParams = DictAttr()
        patientParams = parsParamsText(data_research.get('data'), '\r\n')
        
        # идентификатор исследования
        id_research = data_research.get('id', None)
        id_patient = data_research.get('patient_id', None)
        date = data_research.get('date', None)
        
        # пол пациента
        if 'gender' in data_research:
            gender = data_research.get('gender', None)
        
        # определим возраст пациента по дате его рождения и
        if 'date_birth' in data_research:
            
            age = None
            date_birth = data_research.get('date_birth')
            # дате исследования
            if 'date' in data_research:
                date_research = data_research.get('date')
                age = getAge(date_birth, date_research)
            
            # или текущей дате
            else:
                date_now = datetime.now()
                age = getAge(data_research.get('date_birth'))
        
        for item in patientParams:
            patientParams[item].setdefault('research_id', id_research)
            patientParams[item].setdefault('patient_id', id_patient)
            patientParams[item].setdefault('date', date)
            patientParams[item].setdefault('gender', gender)
            patientParams[item].setdefault('age', age)
            
        
        result = patientParams
    else:
        print(f"Неверный формат данных исследования пациента!")
    
    return result

# получить идентификаторы исследования и пациента из объекта состояния
def getResearchID_PatientID(state):
    """
    Возвращает идентификаторы исследования и пациента из объекта состояния возвращённого getState().
    
    Аргументы:
        state (DictAttr): Объект состояния c данными основных и неосновных параметров.
    
    Результат:
        Возвращает идентификаторы исследования и пациента или None для обоих
         
    Пример:
        >>> id_research, id_patient = getResearchID_PatientID(state_patient)
        >>> print(f"id_research, id_patient = {id_research, id_patient}")
        id_research, id_patient = 8, 4
    """
    # определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state.values()), (None, None) )
    return id_research, id_patient

# объединить несколько записей исследований в одну общую запись исследования
def mergeResearchs_to_ResearchCommon(researchs_list, research_main_id):
    """
    Объединяет несколько записей исследований в одну общую запись исследования.
    
    Аргументы:
        data_research (dict): Словарь данных исследования пациента из таблицы 'research' базы данных.
    
    Результат:
        Возвращает список с одним элементов, который является записью суммирующей все исследования в переданном списке researchs_list
         
    Пример:
        >>> research_common_list = mergeResearchs_to_ResearchCommon(patientParamsListInDay, research_id)
        >>> print(f"research_common_list = {research_common_list}")
    """
    # извлечём данные исследований в список
    i = 0
    researchs_data_dict = DictAttr()
    print(f"mergeResearchs_to_ResearchCommon(): researchs_list = {json.dumps(researchs_list, indent=2, ensure_ascii=False, default=str)}")
    while i<len(researchs_list):
        researchs_data_dict.update(buildResearchParams(researchs_list[i]))
        i += 1
    
    # заменим у всех исследований id-исследований
    for item in researchs_data_dict.values():
        item['research_id'] = research_main_id
    
    # объединим список исследований с данными в одно общее исследование
    research_common_list = list()
    research_common_list.append(researchs_data_dict)
    
    return research_common_list
