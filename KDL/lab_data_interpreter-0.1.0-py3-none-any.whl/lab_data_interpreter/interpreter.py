import json # для работы с json-объектами
from math import * # нужны inf литерал бесконечности и парочка других функций типа math.round
from intervals import FloatInterval # для определения числовых интервалов
from fuzzywuzzy import fuzz, process
import lab_data_interpreter.database as database
import lab_data_interpreter.database_async as database_async
import asyncio
from lab_data_interpreter.utils import *

# from types import SimpleNamespace # используется в iter_params()
# from typing import Union, List, Dict, Literal, Optional # для описания типов аргументов функций и выходного значения



# создаёт словарь, к ключам которого можно обращаться как к свойствам объекта (через точку)
class DictAttr(dict):
    """
    Словарь, который позволяет обращаться к ключам как к атрибутам.
    
    Пример:
        >>> param = DictAttr(id_research='1', id_patient='7', name='Креатинин', value=153, gender='М', age=46)
        >>> print(f"{param.name}"
        Креатинин
    """
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as e:
            raise AttributeError(item) from e

    def __setattr__(self, key, value):
        self[key] = value

# класс, описывает отдельный параметр из справочника с 3-мя градациями фаз его отклонения от нормы и остальными характеристиками с которыми связан параметр
class Parameter:
    """
    Класс Parameter, описывает отдельный параметр из справочника с 3-мя зонами отклонения от нормы и остальными характеристиками.
    
    Аргументы конструктора:
        data (dict): Словарь, представляющий запись по параметру из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
                     Ключи словаря соответствуют именам столбцов в запросе к базе данных:
                     {'id', 'system_name', 'organ_name', 'param_name', 'state_name', 'gen_name', 'age_min', 'age_max', 'tod_name', 'norm_min', 'norm_max', 'mod_dev_min', 'mod_dev_max', 'exp_dev_min', 'exp_dev_max', 'crit_dev_min', 'crit_dev_max', 'deviation_name', 'pos_dyn_name', 'neg_dyn_name', 'priority_name', 'weight_name'}
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.
        В случае ошибки структуры и типов в dos в конструкторе вызывается исключение и возвращается код ошибки.

    Методы класса:
        name(): Возвращает наименование параметра
        system(): Возвращает наименование системы
        organ(): Возвращает наименование органа
        state(): Возвращает наименование состояния
        priority(): Возвращает наименование приоритета
        weight(): Возвращает значение веса
        deviation(): Возвращает наименование отклонения
        tod(): Возвращает наименование типа отклонения
        gender(): Возвращает наименование пола
        recomendation(): Возвращает строку рекомендации
        age(): Возвращает словарь диапазона возраста
        norm(): Возвращает словарь диапазона нормы
        mod_dev(): Возвращает словарь диапазона умеренного отклонения
        exp_dev(): Возвращает словарь диапазона выраженного отклонения
        crit_dev(): Возвращает словарь диапазона критического отклонения
        print_prop(self, objName = "", extend = False): Выводит в лог информацию о параметрах.
                         objName: имя объекта, данные которого выводятся
                         extend: True вывод значений параметра, False

    Замечания:
        - Использует класс Parameter для создания объектов описания каждого параметра.
        - Русскоязычное наименование каждого параметра из списка словарей dos преобразуется путём транслитерации и фильтрации лишних символов в имя, удовлетворяющее соглашению об именовании переменных.
        - Полученное имя используется в качестве атрибута объекта Parameters, значению которого присваивается результат конструктора объекта Parameter, принимающий в качестве аргумента словарь из списка dos.

    Пример:
        >>> # считываем с базы справочник параметров
        >>> dos = database.get_dos(param_db)
        >>> # получаем из первой записи справочника объект словаря
        >>> param = Parameter(dos[0])
        >>> param.print_prop()
        dos_param_0.name = Ферритин
        dos_param_0.state = Воспалительный ответ
        dos_param_0.rec_name = None
        dos_param_0.organ = None
        dos_param_0.system = Иммунная система
        dos_param_0.priority = Неосновной
        dos_param_0.weight = None
        dos_param_0.gender = Муж
        dos_param_0.age.min = None
        dos_param_0.age.max = None
        dos_param_0.norm.min = 30.0
        dos_param_0.norm.max = 400.0
        dos_param_0.mod_dev.min = 400.1
        dos_param_0.mod_dev.max = 600.0
        dos_param_0.exp_dev.min = 600.1
        dos_param_0.exp_dev.max = 1000.0
        dos_param_0.crit_dev.min = 1000.0
        dos_param_0.crit_dev.max = 1000.0
        dos_param_0.deviation = Повышение уровня ферритина
        dos_param_0.tod_name = "нг/мл"
        dos_param_0.print_prop() = None
    """
    def __init__(self, data, debug=False):
        """
        Инициализирует объект Parameter.

        Аргументы:
            data (dict): Словарь, представляющий запись по параметру из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
                         Ключи словаря соответствуют именам столбцов в запросе к базе данных:
                         {'id', 'system_name', 'organ_name', 'param_name', 'state_name', 'gen_name', 'age_min', 'age_max', 'tod_name', 'norm_min', 'norm_max', 'mod_dev_min', 'mod_dev_max', 'exp_dev_min', 'exp_dev_max', 'crit_dev_min', 'crit_dev_max', 'deviation_name', 'pos_dyn_name', 'neg_dyn_name', 'priority_name', 'weight_name'}
            debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.
            В случае ошибки структуры и типов в dos в конструкторе вызывается исключение и возвращается код ошибки.

        Исключения:
            TypeError: Если `dos` не является списком словарей.
            KeyError: Если в словарях отсутствует необходимый ключ.
            ValueError: Если значения аргументов недопустимы.
        """
        # проверим что в списке есть хотя бы один словарь для анализа на наличие в нём необходимых ключей
        # if isinstance(data, list):
        #     if not any(isinstance(item, dict) for item in data):
        #         # print(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
        #         raise TypeError(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
        
        # проверим что в списке есть хотя бы один словарь для анализа на наличие в нём необходимых ключей
        if not isinstance(data, dict):
            raise TypeError(f"Переданный тип аргумент data, должен быть словарём! Переданный тип data = {type(data)}")
        
        # проверяем наличие обязательных ключей у входного словаря data, без наличия которых создать объект словаря параметров невозможно
        requared_keys = ['param_name', 'state_name']
        for key in requared_keys:
            if key in data:
                if debug: print(f"key = {key}, data[{key}] = {data[key]}, type(data[{key}]) = {type(data[key])}")
                
                if data[key] is None:
                    # print(f"В переданном словаре не задано значение ключа {key}")
                    raise ValueError(f"В переданном словаре не задано значение ключа {key}")
                
                setattr(self, key, data[key])
                
            else:
                # print(f"Отсутствует обязательный ключ {key} в переданном словаре!")
                raise KeyError(f"Отсутствует обязательный ключ {key} в переданном словаре!")
        
        if debug:
            print(f"необработанные данные:\nnorm_min = {data.get('norm_min', None)}, norm_max = {data.get('norm_max', None)}; mod_dev_min = {data.get('mod_dev_min', None)}, mod_dev_max = {data.get('mod_dev_max', None)}; exp_dev_min = {data.get('exp_dev_min', None)}, exp_dev_max = {data.get('exp_dev_max', None)}; crit_dev_min = {data.get('crit_dev_min', None)}, crit_dev_max = {data.get('crit_dev_max', None)}")
        
        # последовательно проверяем наличие необязательных ключей у входного словаря data, без которых создать объект словаря параметров возможно
        # в случае отсутствия ключа, в объекте создаём его с пустым значением None
        
        # данные по ключам norm_min, norm_max, mod_dev_min, mod_dev_max необходимо проанализировать на тип заданных значений
        # и направление отсчёта зон отклонений от зоны нормы
        norm = [toFloat(data.get('norm_min', None)), toFloat(data.get('norm_max', None))]
        if all(norm) and norm[0]>norm[1]:
            norm[0], norm[1] = norm[1], norm[0]
        if debug: print(f"norm = {norm}")
        
        mod_dev = [toFloat(data.get('mod_dev_min', None)), toFloat(data.get('mod_dev_max', None))]
        if all(mod_dev) and mod_dev[0]>mod_dev[1]:
            mod_dev[0], mod_dev[1] = mod_dev[1], mod_dev[0]
        if debug: print(f"mod_dev = {mod_dev}")
        
        exp_dev = [toFloat(data.get('exp_dev_min', None)), toFloat(data.get('exp_dev_max', None))]
        if all(exp_dev) and exp_dev[0]>exp_dev[1]:
            exp_dev[0], exp_dev[1] = exp_dev[1], exp_dev[0]
        if debug: print(f"exp_dev = {exp_dev}")
        
        crit_dev = [toFloat(data.get('crit_dev_min', None)), toFloat(data.get('crit_dev_max', None))]
        if all(crit_dev) and crit_dev[0]>crit_dev[1]:
            crit_dev[0], crit_dev[1] = crit_dev[1], crit_dev[0]
        if debug: print(f"crit_dev = {crit_dev}")
        
        sequence = [norm[0], norm[1], mod_dev[0], mod_dev[1], exp_dev[0], exp_dev[1], crit_dev[0], crit_dev[1]]
        if debug:
            print(f"sequence = {sequence}")
        direct = getDirectInList_v1(sequence)
        if debug:
            print(f"direct = {direct}")
        
        qualitParam = False # признак качественных значений параметров зон
        
        # если тенденция изменения значений от зоны нормы к зоне критичности на повышение
        if direct>0:
            # 1. обработаем данные границ норм учитывая границы зон отклонения
            norm_min = norm[0] # getMin(norm)
            if norm_min==None:
                norm_min = -inf
            
            norm_max = norm[1] # getMax(norm)
            if norm_max==None:
                val = getMin(sequence[2:])
                norm_max = inf if val==None else val
            
            if debug:
                print(f"norm_min = {norm_min}")
                print(f"norm_max = {norm_max}")
            
            # 2. обработаем данные границ умеренного отклонения учитывая границы зоны нормы и зон отклонения
            mod_dev_min = mod_dev[0] # getMin(mod_dev)
            if mod_dev_min==None:
                mod_dev_min = norm_max
            
            mod_dev_max = mod_dev[1] # getMax(mod_dev)
            if mod_dev_max==None:
                val = getMin(sequence[4:])
                mod_dev_max = inf if val==None else val
            
            if debug:
                print(f"mod_dev_min = {mod_dev_min}")
                print(f"mod_dev_max = {mod_dev_max}")
            
            # 3. обработаем данные границ выраженного отклонения учитывая границы зоны умеренного и критического отклонений
            exp_dev_min = exp_dev[0] # getMin(exp_dev)
            if exp_dev_min==None:
                exp_dev_min = mod_dev_max
            
            exp_dev_max = exp_dev[1] # getMax(exp_dev)
            if exp_dev_max==None:
                val = getMin(sequence[6:])
                exp_dev_max = inf if val==None else val
            
            if debug:
                print(f"exp_dev_min = {exp_dev_min}")
                print(f"exp_dev_max = {exp_dev_max}")
            
            # 4. обработаем данные границ критического отклонения учитывая границы зоны выраженного отклонения
            crit_dev_min = crit_dev[0] # getMin(crit_dev)
            if crit_dev_min==None:
                crit_dev_min = exp_dev_max
            
            val = crit_dev[1] # getMax(crit_dev)
            crit_dev_max = inf if val==None else val
            
            # 5. перепроверим границы диапазонов, они должны примыкать друг к другу
            if norm_min==norm_max and (norm_min not in (-inf, inf)) and (norm_max not in (-inf, inf)):
                norm_max = getMin([mod_dev_min, mod_dev_max])
                if norm_min==norm_max:
                    norm_min = -inf
            
            if mod_dev_min==mod_dev_max and (mod_dev_min not in (-inf, inf)) and (mod_dev_max not in (-inf, inf)):
                mod_dev_max = getMin([exp_dev_min, exp_dev_max])
            
            if exp_dev_min==exp_dev_max and (exp_dev_min not in (-inf, inf)) and (exp_dev_max not in (-inf, inf)):
                exp_dev_max = getMin([crit_dev_min, crit_dev_max])
            
            if crit_dev_min==crit_dev_max and (crit_dev_min not in (-inf, inf)) and (crit_dev_max not in (-inf, inf)):
                crit_dev_max = inf
            
            if debug:
                print(f"crit_dev_min = {crit_dev_min}")
                print(f"crit_dev_max = {crit_dev_max}")
        
        # если тенденция изменения значений от зоны нормы к зоне критичности на понижение
        elif direct<0:
            # 1. обработаем данные границ норм учитывая границы зон отклонения
            norm_max = norm[1] # getMax(norm)
            if norm_max==None:
                norm_max = inf
            
            norm_min = norm[0] # getMin(norm)
            if norm_min==None:
                val = getMax(sequence[2:])
                norm_min = -inf if val==None else val
            
            if debug:
                print(f"norm_min = {norm_min}")
                print(f"norm_max = {norm_max}")
            
            # 2. обработаем данные границ умеренного отклонения учитывая границы зоны нормы и зон отклонения
            mod_dev_max = mod_dev[1] # getMax(mod_dev)
            if mod_dev_max==None:
                mod_dev_max = norm_min
            
            mod_dev_min = mod_dev[0] # getMin(mod_dev)
            if mod_dev_min==None:
                val = getMax(sequence[4:])
                mod_dev_min = -inf if val==None else val
            
            if debug:
                print(f"mod_dev_min = {mod_dev_min}")
                print(f"mod_dev_max = {mod_dev_max}")
            
            # 3. обработаем данные границ выраженного отклонения учитывая границы зоны умеренного и критического отклонений
            exp_dev_max = exp_dev[1] # getMax(exp_dev)
            if exp_dev_max==None:
                exp_dev_max = mod_dev_min
            
            exp_dev_min = exp_dev[0] # getMin(exp_dev)
            if exp_dev_min==None:
                val = getMax(sequence[6:])
                exp_dev_min = -inf if val==None else val
            
            if debug:
                print(f"exp_dev_min = {exp_dev_min}")
                print(f"exp_dev_max = {exp_dev_max}")
            
            # 4. обработаем данные границ критического отклонения учитывая границы зоны выраженного отклонения
            crit_dev_max = crit_dev[1] # getMax(crit_dev)
            if crit_dev_max==None:
                crit_dev_max = exp_dev_min
            
            val = crit_dev[0] # getMin(crit_dev)
            crit_dev_min = -inf if val==None else val
            
            if debug:
                print(f"crit_dev_min = {crit_dev_min}")
                print(f"crit_dev_max = {crit_dev_max}")
            
            # 5. перепроверим границы диапазонов, они должны примыкать друг к другу
            if norm_min==norm_max and (norm_min not in (-inf, inf)) and (norm_max not in (-inf, inf)):
                norm_max = inf
            
            if mod_dev_min==mod_dev_max and (mod_dev_min not in (-inf, inf)) and (mod_dev_max not in (-inf, inf)):
                mod_dev_max = getMin([norm_min, norm_max])
            
            if exp_dev_min==exp_dev_max and (exp_dev_min not in (-inf, inf)) and (exp_dev_max not in (-inf, inf)):
                exp_dev_max = getMin([mod_dev_min, mod_dev_max])
            
            if crit_dev_min==crit_dev_max and (crit_dev_min not in (-inf, inf)) and (crit_dev_max not in (-inf, inf)):
                crit_dev_max = getMin([exp_dev_min, exp_dev_max])
                if crit_dev_min==crit_dev_max:
                    crit_dev_min = -inf
        
        # если тенденция изменения значений от зоны нормы к зоне критичности не определена
        else:
            norm_min = toFloat(data.get('norm_min', None))
            norm_max = toFloat(data.get('norm_max', None))
            mod_dev_min = toFloat(data.get('mod_dev_min', None))
            mod_dev_max = toFloat(data.get('mod_dev_max', None))
            exp_dev_min = toFloat(data.get('exp_dev_min', None))
            exp_dev_max = toFloat(data.get('exp_dev_max', None))
            crit_dev_min = toFloat(data.get('crit_dev_min', None))
            crit_dev_max = toFloat(data.get('crit_dev_max', None))
            
            # обработка качественного значения типа 'положительно'/'отрицательно'. 'положительно' соотносим с inf, 'отрицательно' с -inf
            if debug: print(f"Проверка задания зоны в виде качественного параметра положительно/отрицательно")
            
            # if norm_min==inf and norm_max!=inf: norm_min = -inf  # задана верхняя граница, нижняя неограничена
            # elif norm_min!=None and norm_max==None: norm_max = inf # задана нижняя граница, верхняя неограничена
            
            # если зона нормы обозначены бесконечностью, то остальные зоны должны быть бесконечностью с противоположным знаком
            bad_data = False
            if norm_min==inf or norm_max==inf:
                if mod_dev_min==None and mod_dev_max==None and exp_dev_min==None and exp_dev_max==None and crit_dev_min==None and crit_dev_max==None:
                    mod_dev_min = -inf
                    mod_dev_max = -inf
                    exp_dev_min = -inf
                    exp_dev_max = -inf
                    crit_dev_min = -inf
                    crit_dev_max = -inf
                    qualitParam = True
                else:
                    bad_data = True
            elif norm_min==-inf or norm_max==-inf:
                if mod_dev_min==None and mod_dev_max==None and exp_dev_min==None and exp_dev_max==None and crit_dev_min==None and crit_dev_max==None:
                    mod_dev_min = inf
                    mod_dev_max = inf
                    exp_dev_min = inf
                    exp_dev_max = inf
                    crit_dev_min = inf
                    crit_dev_max = inf
                    qualitParam = True
                else:
                    bad_data = True
            else:
                bad_data = True
            
            # если данные неопределённые
            if bad_data:
                msg = (f"У параметра {data['param_name']} направление отклонения зон от зоны нормы НЕОПРЕДЕЛЕНО!"
                      f"\nПараметры заданных зон: норма = {[data.get('norm_min', None), data.get('norm_max', None)]}, умеренное отклонение = {(data.get('mod_dev_min', None), data.get('mod_dev_max', None))}, выраженное отклонение = {(data.get('exp_dev_min', None), data.get('exp_dev_max', None))}, критическое отклонение = {(data.get('crit_dev_min', None), data.get('crit_dev_max', None))}"
                      f"\nЗадача корректного сопоставления измеренных данных с зонами отклонения невозможна!")
                
                print(msg)
                raise ValueError(msg)
            
        
        if debug:
            print(f"обработанные данные\nnorm_min = {norm_min}, norm_max = {norm_max}; mod_dev_min = {mod_dev_min}, mod_dev_max = {mod_dev_max}; exp_dev_min = {exp_dev_min}, exp_dev_max = {exp_dev_max}; crit_dev_min = {crit_dev_min}, crit_dev_max = {crit_dev_max}")
            print(f"qualitParam = {qualitParam}")
        
        '''# определим направление отклонения границ зон от зоны нормы
        direct = getDirectFromBounds(intervals, norm_key='norm')
        if debug:
            print(f"intervals = {intervals}")
            print(f"direct = {direct}")
        
        # определение направления отклонения зон отклонения от зоны нормы
        if debug: print(f"Определение направления отклонения зон отклонения от зоны нормы")
        intervalNorm = FloatInterval.closed(min(norm_min, norm_max), max(norm_min, norm_max))
        intervalDevMod = FloatInterval.closed(mod_dev_min, mod_dev_max)
        intervalDevExp = FloatInterval.closed(exp_dev_min, exp_dev_max)
        intervalDevCrit = FloatInterval.closed(crit_dev_min, crit_dev_max)
        intervals = {'norm':intervalNorm, 'devmod':intervalDevMod, 'devexp':intervalDevExp, 'devcrit':intervalDevCrit}
        direct = getDirectFromBounds_v1(intervals, norm_key='norm')
        
        if debug:
            print(f"intervals = {intervals}")
            print(f"direct = {direct}")
        
        if debug:
            print(f"intervalNorm = {intervalNorm}, intervalDevMod = {intervalDevMod}, intervalDevExp = {intervalDevExp}, intervalDevCrit = {intervalDevCrit}")
        '''
        
        ''' # если значение границ зоны нормы заданы количественно
        if not qualitParam:
            # если отклонение в сторону увеличения значения границ зон от зоны нормы
            if debug: print(f"Проверяем корректность отклонения зон от нормы в сторону повышения значения границ зон")
            if direct=='right':
                # значения None заменяем на inf, чтобы была возможность соотносить зоны друг относительно друга
                if mod_dev_min==None: mod_dev_min = float('inf')
                if mod_dev_max==None: mod_dev_max = float('inf')
                if exp_dev_min==None: exp_dev_min = float('inf')
                if exp_dev_max==None: exp_dev_max = float('inf')
                if crit_dev_min==None: crit_dev_min = float('inf')
                if crit_dev_max==None: crit_dev_max = float('inf')
                
                # последовательно проходим по границам зон отклонения и соотносим взаимное положение границ
                if norm_min and norm_max and mod_dev_min and norm_min>mod_dev_min:
                    mod_dev_min = norm_max
                
                if mod_dev_min and mod_dev_max and exp_dev_min and mod_dev_min>exp_dev_min:
                    exp_dev_min = mod_dev_max
                
                if exp_dev_min and exp_dev_max and crit_dev_min and exp_dev_min>crit_dev_min:
                    crit_dev_min = exp_dev_max
                
                if crit_dev_min and crit_dev_max and crit_dev_min>crit_dev_max:
                    crit_dev_max = float('inf')
            
            # если отклонение в сторону уменьшения значения границ зон от зоны нормы
            if debug: print(f"Проверяем корректность отклонения зон от нормы в сторону уменьшения значения границ зон")
            if direct=='left':
                # значения None заменяем на inf, чтобы была возможность соотносить зоны друг относительно друга
                if mod_dev_min==None: mod_dev_min = float('-inf')
                if mod_dev_max==None: mod_dev_max = float('-inf')
                if exp_dev_min==None: exp_dev_min = float('-inf')
                if exp_dev_max==None: exp_dev_max = float('-inf')
                if crit_dev_min==None: crit_dev_min = float('-inf')
                if crit_dev_max==None: crit_dev_max = float('-inf')
                
                # последовательно проходим по границам зон отклонения и соотносим взаимное положение границ
                if norm_min and norm_max and mod_dev_max and norm_max<mod_dev_max:
                    mod_dev_max = norm_min
                
                if mod_dev_min and mod_dev_max and exp_dev_min and mod_dev_max<exp_dev_max:
                    exp_dev_max = mod_dev_min
                
                if exp_dev_min and exp_dev_max and crit_dev_min and exp_dev_max<crit_dev_max:
                    crit_dev_max = exp_dev_min
                
                if crit_dev_min and crit_dev_max and crit_dev_min>crit_dev_max:
                    crit_dev_min = float('-inf')
            
            # если направление отклонения не определено
            if debug: print(f"Неправление неопределено. Выполняем дополнительные проверки")
            if direct=='both':
                msg = (f"У параметра {data['param_name']} направление отклонения зон от зоны нормы НЕОПРЕДЕЛЕНО!"
                      f"\nПараметры заданных зон: норма = {intervalNorm}, умеренное отклонение = {intervalDevMod}, выраженное отклонение = {intervalDevExp}, критическое отклонение = {intervalDevCrit}"
                      f"\nЗадача корректного сопоставления измеренных данных с зонами отклонения невозможна!")
                
                print(msg)
                raise ValueError(msg)
                
        '''
        
        if debug:
            print(f"Доп обработанные данные\nnorm_min = {norm_min}, norm_max = {norm_max}; mod_dev_min = {mod_dev_min}, mod_dev_max = {mod_dev_max}; exp_dev_min = {exp_dev_min}, exp_dev_max = {exp_dev_max}; crit_dev_min = {crit_dev_min}, crit_dev_max = {crit_dev_max}")
        
        # если всё в порядке можем устанавливать зоны в качестве свойств-атрибутов параметра
        setattr(self, 'norm_min', norm_min) # ключ norm_min
        setattr(self, 'norm_max', norm_max) # ключ norm_max
        
        # один из ключей norm_min или norm_max должен иметь значение. Иначе ошибка, так как создать словарь без заданного параметра невозможно
        if self.norm_min is None and self.norm_max is None:
            print(f"В переданном словаре не задано ориентировочное значение нормы!")
            raise ValueError(f"В переданном словаре не задано ориентировочное значение нормы!")
        
        setattr(self, 'mod_dev_min', mod_dev_min) # ключ mod_dev_min
        setattr(self, 'mod_dev_max', mod_dev_max) # ключ mod_dev_max
        
        setattr(self, 'exp_dev_min', exp_dev_min) # ключ exp_dev_min
        setattr(self, 'exp_dev_max', exp_dev_max) # ключ exp_dev_max
        
        setattr(self, 'crit_dev_min', crit_dev_min) # ключ crit_dev_min
        setattr(self, 'crit_dev_max', crit_dev_max) # ключ crit_dev_max
        
        # ключ system_name
        if 'system_name' in data:
            setattr(self, 'system_name', data['system_name'])
        else:
            setattr(self, 'system_name', None)
            print(f"Отсутствует ключ 'system_name' в переданном словаре!")
        
        # ключ organ_name
        if 'organ_name' in data:
            setattr(self, 'organ_name', data['organ_name'])
        else:
            setattr(self, 'organ_name', None)
            print(f"Отсутствует ключ 'organ_name' в переданном словаре!")
        
        # ключ gen_name
        if 'gen_name' in data:
            setattr(self, 'gen_name', data['gen_name'])
        else:
            setattr(self, 'gen_name', None)
            print(f"Отсутствует ключ 'gen_name' в переданном словаре!")
        
        # ключ age_min
        if 'age_min' in data:
            setattr(self, 'age_min', data['age_min'])
        else:
            setattr(self, 'age_min', None)
            print(f"Отсутствует ключ 'age_min' в переданном словаре!")
        
        # ключ age_max
        if 'age_max' in data:
            setattr(self, 'age_max', data['age_max'])
        else:
            setattr(self, 'age_max', None)
            print(f"Отсутствует ключ 'age_max' в переданном словаре!")
        
        # ключ tod_name
        if 'tod_name' in data:
            setattr(self, 'tod_name', data['tod_name'])
        else:
            setattr(self, 'tod_name', None)
            print(f"Отсутствует ключ 'tod_name' в переданном словаре!")
        
        # ключ deviation_name
        if 'deviation_name' in data:
            setattr(self, 'deviation_name', data['deviation_name'])
        else:
            setattr(self, 'deviation_name', None)
            print(f"Отсутствует ключ 'deviation_name' в переданном словаре!")
        
        # ключ pos_dyn_name
        if 'pos_dyn_name' in data:
            setattr(self, 'pos_dyn_name', data['pos_dyn_name'])
        else:
            setattr(self, 'pos_dyn_name', None)
            print(f"Отсутствует ключ 'pos_dyn_name' в переданном словаре!")
        
        # ключ neg_dyn_name
        if 'neg_dyn_name' in data:
            setattr(self, 'neg_dyn_name', data['neg_dyn_name'])
        else:
            setattr(self, 'neg_dyn_name', None)
            print(f"Отсутствует ключ 'neg_dyn_name' в переданном словаре!")
        
        # ключ priority_name
        if 'priority_name' in data:
            setattr(self, 'priority_name', data['priority_name'])
        else:
            setattr(self, 'priority_name', None)
            print(f"Отсутствует ключ 'priority_name' в переданном словаре!")
        
        # ключ weight_name
        if 'weight_name' in data:
            setattr(self, 'weight_name', toFloat(data['weight_name']))
        else:
            setattr(self, 'weight_name', None)
            print(f"Отсутствует ключ 'weight_name' в переданном словаре!")
        
        if debug:
            print(f"class Parameter.__init__: End")
        
        # ключ rec_name
        if 'rec_name' in data:
            setattr(self, 'rec_name', data['rec_name'])
        else:
            setattr(self, 'rec_name', None)
            print(f"Отсутствует ключ 'rec_name' в переданном словаре!")

    @property
    def name(self):
        return self.param_name

    @property
    def system(self):
        return self.system_name

    @property
    def organ(self):
        return self.organ_name

    @property
    def state(self):
        return self.state_name

    @property
    def priority(self):
        return self.priority_name

    @property
    def weight(self):
        return self.weight_name

    @property
    def deviation(self):
        return self.deviation_name

    @property
    def tod(self):
        return self.tod_name

    @property
    def gender(self):
        return self.gen_name

    @property
    def recomendation(self):
        return self.rec_name

    @property
    def age(self):
        return type('Age', (object,), {'min': self.age_min, 'max': self.age_max})()

    @property
    def norm(self):
        return type('Norm', (object,), {'min': self.norm_min, 'max': self.norm_max})()

    @property
    def norm(self):
        return type('Norm', (object,), {'min': self.norm_min, 'max': self.norm_max})()

    @property
    def mod_dev(self):
        return type('ModDev', (object,), {'min': self.mod_dev_min, 'max': self.mod_dev_max})()

    @property
    def exp_dev(self):
        return type('ExpDev', (object,), {'min': self.exp_dev_min, 'max': self.exp_dev_max})()

    @property
    def crit_dev(self):
        return type('CritDev', (object,), {'min': self.crit_dev_min, 'max': self.crit_dev_max})()

    # вывести в лог данные объекта типа Parameter
    def print_prop(self, objName = "", extend = False):
        """
        Выводит в лог информацию о параметрах.

        Аргументы:
            objName (str, optional): Строка имени объекта, параметры которого необходимо вывести в лог
            extend (bool, optional): Если True, выводит подробную информацию о каждом параметре, включая его атрибуты. По умолчанию False.

        Результат:
            Вывод данных в лог

        Пример:
            >>> dos = database.get_dos(param_db)
            >>> dos_param_0 = interpreter.Parameter(dos[0])
            >>> dos_param_0.print_prop(objName = 'dos_param_0')
        """
        if extend:
            for key, value in self.__dict__.items():
                print(f"{objName}.{key}:{value}")
        else:
            print(f"{objName}.name = {self.name}")
            print(f"{objName}.state = {self.state}")
            print(f"{objName}.organ = {self.organ}")
            print(f"{objName}.system = {self.system}")

# класс описывает все параметры из справочника параметров dos, базы данных kdl
class Parameters:
    """
    Класс представляет собой контейнер для объектов Parameter, полученных из таблицы DOS. Используется для хранения и организации информации о параметрах.
    Консруктор в качестве аргумента принимает список словарей, описывающих параметры, возвращаемый функцией database.get_dos().
    
    Аргументы конструктора:
        dos (list(dict)): Список словарей, где каждый словарь представляет запись из таблицы DOS с данными из связанных таблиц (System, Organ, Parameter и т.д.).
                          Ключи словаря соответствуют именам столбцов в запросе к базе данных. Подробный список ключей можно найти в документации к функции database.get_dos().
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.
        В случае ошибки структуры и типов в dos в конструкторе вызывается исключение и возвращается код ошибки.

    Атрибуты класса:
        <param_name>_<id>: Объект Parameter, представляющий параметр с именем <param_name> и идентификатором <id>. Например, Ferritin_2.

    Методы класса:
        print_prop(extend=False): Выводит в лог информацию о параметрах.

    Замечания:
        - Использует класс Parameter для создания объектов описания каждого параметра.
        - Русскоязычное наименование каждого параметра из списка словарей dos преобразуется путём транслитерации и фильтрации лишних символов в имя, удовлетворяющее соглашению об именовании переменных.
        - Полученное имя используется в качестве атрибута объекта Parameters, значению которого присваивается результат конструктора объекта Parameter, принимающий в качестве аргумента словарь из списка dos.

    Пример:
        >>> dos = database.get_dos(param_db)
        >>> params_template = Parameters(dos)
        >>> print(f"params_template = {params_template}")  # Выведет список атрибутов класса
    """
    # инициализирует объект Parameters
    def __init__(self, dos, debug=False):
        """
        Инициализирует объект Parameters.

        Аргументы:
            dos (list(dict)): Список словарей, представляющих параметры из таблицы DOS.  Каждый словарь должен содержать необходимые ключи для создания объектов Parameter.
            debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

        Исключения:
            TypeError: Если `dos` не является списком словарей.
            KeyError: Если в словарях отсутствует необходимый ключ.
            ValueError: Если значения аргументов недопустимы.

        Замечания:
            - Каждый элемент списка `dos` должен быть словарём.
            - Каждый словарь должен содержать все необходимые ключи для создания объекта Parameter.
              Подробный список ключей можно найти в документации к функции database.get_dos().
        """
        if debug:
            print(f"class Parameters.__init__: Begin")
            print(f"type(data) = {type(dos)}")
        
        if not isinstance(dos, list):
            print(f"Переданный аргумент dos, для создания объекта - словаря параметров, должен быть списком словарей!")
            raise TypeError(f"Переданный аргумент dos, для создания объекта - словаря параметров, должен быть списком словарей!")
        
        GENDER_MAP = { "Male" : "M", "M" : "M", "Мужчина" : "М", "Муж" : "М", "М" : "М", "Female" : "F", "F" : "F", "Женщина" : "Ж", "Жен" : "Ж", "Ж" : "Ж", }
        
        paramsNotLoaded = list()
        
        for item in dos:
            # создаём объект Parameter
            try:
                param_obj = Parameter(item, debug)
            except TypeError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка типа при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise TypeError(f"Переданный аргумент data, для создания объекта - словаря параметров, должен быть словарём!")
                continue
            except KeyError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка ключа при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise KeyError(f"Отсутствует обязательный ключ в переданном словаре!")
                continue
            except ValueError as e:
                item['error'] = e
                paramsNotLoaded.append(item)
                print(f"Ошибка значения при создании объекта словаря параметров!\nПараметры ошибки: {e}")
                # raise ValueError(f"Ошибка при создании объекта словаря параметров!")
                continue
            
            dos_id = item.get('id')
            
            # берём имя параметра и делаем его валидным идентификатором
            param_name_raw = item.get('param_name', '')
            name = param_name_raw
            # print(f"param_name_raw = {param_name_raw}")
            
            gen = GENDER_MAP.get(str(item.get('gen_name') or '').strip().lower(), '')
            
            age_min = item.get('age_min', '')
            age_max = item.get('age_max', '')
            
            attr_name = clean_identifier(param_name_raw)
            # if gen!= '':
            #     attr_name = attr_name + "_" + gen
            # if age_min is not None:
            #     attr_name = attr_name + "_" + str(age_min)
            # if age_max is not None:
            #     attr_name = attr_name + "_" + str(age_max)
            
            attr_name = attr_name + "_" + str(dos_id)
            # attr_name = str(dos_id) + "_" + attr_name # или так, хз как лучше
            
            # связываем атрибут с объектом класса Parameter
            setattr(self, attr_name, param_obj)
            setattr(self, 'paramsNotLoaded', paramsNotLoaded)
        
        if debug:
            print(f"class Parameters.__init__: End")

    # возвращает строковое представление объекта Parameters
    def __repr__(self):
        """
        Возвращает строковое представление объекта Parameters.
        """
        # attrs = ', '.join(f'{k}={v.param_name}' for k, v in self.__dict__.items())
        # return f'<Parameters {attrs}>'
        
        # attrs = ', '.join(
        #    f'{k}={v.param_name if hasattr(v, "param_name") else repr(v)}'
        #    for k, v in self.__dict__.items()
        
        attrs = ', '.join(
            f'{k}={getattr(v, "param_name", repr(v))}'
           for k, v in self.__dict__.items()
        )
        
        return f'<Parameters {attrs}>'

    # вывести в лог данные объекта типа Parameters
    def print_prop(self, extend = False):
        """
        Выводит в лог информацию о параметрах.

        Аргументы:
            extend (bool, optional): Если True, выводит подробную информацию о каждом параметре, включая его атрибуты. По умолчанию False.

        Результат:
            Вывод данных в лог

        Пример:
            >>> params_template = Parameters(dos)       # Получит объект параметров. Желательно использовать try: except для обработки ошибок
            >>> params_template.print_prop()            # Выведет список имен параметров
            >>> params_template.print_prop(extend=True) # Выведет подробную информацию о каждом параметре
        """
        count = 0
        for attr_name, attr_value in self.__dict__.items():
            
            if not attr_name.startswith("__"):
                count += 1
                type_info = f", type = {type(attr_value).__name__}" if extend else ""
                print(f"{count} attr_name = {attr_name}{type_info}")
                if extend:
                    if isinstance(attr_value, Parameter):
                        attr_value.print_prop(attr_name, extend)
                    else:
                        print(f"{attr_name} = {attr_value}")

# вспомогательная функция используемая в функции getState
def iter_params(param_obj):
    """
    Генератор пар (ключ, значение) из любого объекта, который может быть представлен как dict или DictAttr.
    """
    # словарь или объект с методом items()
    if hasattr(param_obj, "items"):
        try:
            for k, v in param_obj.items():
                yield k, v
            return
        except TypeError:
            pass   # items() не итерируемый
    
    # атрибуты через __dict__ / vars()
    if hasattr(param_obj, "__dict__"):
        try:
            for k, v in param_obj.__dict__.items():
                yield k, v
            return
        except Exception:
            pass
    
    # параметр сам по себе итерируемый (например список кортежей)
    if hasattr(param_obj, "__iter__"):
        try:
            for k, v in param_obj: # предполагается (key, value) пары
                yield k, v
            return
        except Exception:
            pass
    
    raise TypeError(f"Не удалось распознать объект {param_obj!r} как набор параметров")

# функция определения вероятности состояния по данным измеренных параметров на основании соспоставления их со справочником параметров
def getState(params_dic, params, debug=False):
    """
    Определить состояния и их вероятности на основании сопоставления данных измеренных параметров из params со справочными данными в params_dic.

    Аргументы:
        params_dic (Parameters) : Справочник параметров - объект типа Parameters хранящий в себе словарь параметров
        params (DictAttr): Данные измеренных состояний. Список словарей типа DictAttr, хранящий экспериментальные значения параметров в виде:
                           list( DictAttr(id_research:str, id_patient:str, name:str, value:int, gender:str, age:int), )
        debug (bool, optional): Режим отладки. Если True, выводит дополнительную информацию о параметрах и SQL-запросе. По умолчанию False.

    Результат:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему. Структура словаря:
            {
                'КлючСостояния': {
                        'research_id': int,            # Идентификатор исследования
                        'patient_id': int,             # Идентификатор пациента
                        'name': str,                   # Наименование состояния
                        'probality': float,            # Вероятность состояния
                        'params_main': DictAttr,       # Основные параметры
                            # Каждый параметр: {       #
                            #   "system": str,         # Наименование Системы
                            #   "organ": str,          # Наименование Органа
                            #   "name": str,           # Наименование параметра
                            #   "value": float,        # Значение параметра
                            #   "gender": str,         # Пол
                            #   "age": int,            # Возраст
                            #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы. Допустимые значения: 2 - зона умеренного отклонения, 3 - выраженное отклонение, 4 - критическое отклонение.
                            #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                            #   "dynamic": str,        # Строковое наименование изменения состояния
                            # },                       #
                        'params_adv': DictAttr,        # Неосновные параметры. Структура как у 'params_main'
                        'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                                       # Структура словаря sort_params: {'система':{'орган':{'состояние:величина_критичности':{['отсортированный_список_наименований_отклонений:значение_отклонения']}}}}
                        'sort_params_text': str,       # Строковое представление словаря sort_params
                    },
                'sort_states': list(dict)              # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
                'sort_states_text': str                # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
            }

    Замечания:
        - У каждого состояния параметры сортируются по выраженности и отклонению от нормы.
          Результат сортировки параметров записывается в поле 'sort_params' и 'sort_params_text'.
        - Функция возвращает словарь состояний НЕ отсортированных по значению критичности.
          Для сортировки состояний необходимо использовать функцию sortedStatesText() или sortedStatesText_v2().
          Для пересортировки параметров в состояниях необходимо использовать функцию sortedParamsStateText() или sortedParamsStateText_v2().

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_patient = interpreter.getState(params_template, patientParamsList[3], debug=False)
        >>> print(f"type(state_patient) = {type(state_patient)}")
        >>> print(f"state_patient = {json.dumps(state_patient, indent=2, ensure_ascii=False, default=str)}")
        type(state_patient) = <class 'lab_data_interpreter.interpreter.DictAttr'>
        state_patient = {
          "Gipokoagulyaciya": {
            "research_id": 4,
            "patient_id": 7,
            "name": "Гипокоагуляция",
            "probality": 1.17,
            "params_main": {
              "MNO_197": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "МНО",
                "value": 1.17,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.17,
                "dynamic": "Повышение уровня МНО"
              }
            },
            "params_adv": {
              "Protrombinovoe_vremya_201": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "Протромбиновое время",
                "value": 14.3,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.1485943775100402,
                "dynamic": "Удлинение протромбинового времени"
              }
            },
            "sort_params_text": "{'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}",
            "sort_params": {
              "Свертывающая система крови": {
                "null": {
                  "Гипокоагуляция": [
                    "Повышение уровня МНО:2",
                    "Удлинение протромбинового времени:2"
                  ]
                }
              }
            }
          },
        }
    """
    if debug:
        print(f"getState: Begin")
    
    # определим с какой структурой данных словаря мы работаем. Это либо словарь, список словарей, либо словарь словарей
    paramsCheck = iter(params)
    firstKey = next(paramsCheck)
    
    if type(firstKey) is not DictAttr:
        firstVal = params[firstKey]
        if debug:
            print(f"firstKey = {firstKey}, type(firstKey) = {type(firstKey)}")
            print(f"params[firstKey] = {params[firstKey]}")
        if type(params[firstKey]) is not DictAttr:
            params_iter = [params]
        else:
            params_iter = params
    else:
        firstVal = None
        params_iter = params
    
    if debug:
        print(f"params = {params}")
        print(f"hasattr(params, 'items') = {hasattr(params, 'items')}\n")
        
        print(f"firstKey = {firstKey}")
        print(f"is_iterable(firstKey) = {is_iterable(firstKey)}")
        print(f"firstVal = {firstVal}, type(firstVal) = {type(firstVal)}")
    
    states = DictAttr()
    
    if debug: print(f"\nПеребираем элементы: в params_iter. len(params_iter) = {len(params_iter)}")
    # перебираем параметры в измеренных параметрах
    for itemKey in params_iter:
        
        if debug:
            print(f"itemKey = {itemKey}, type(itemKey) = {type(itemKey)}, type(params_iter['{itemKey}']) = {type(params_iter[itemKey])}")
            
        if type(itemKey) is DictAttr:
            item = itemKey
        else:
            item = params_iter[itemKey]
            
        if debug:
            print(f"item = {item}")
            print("; ".join(map(lambda i: f"i = {i}, item.get({i}) = {item.get(i)}", item)))
            # for i in item:
                # print(f"i = {i}, item.get(i, None) = {item.get(i, None)}")
                
            #print(f"item.name = {item.name}, item.value = {item.value}, item.gender = {item.gender}, item.age = {item.age}")
        
        id_research = item.get('research_id', None)
        id_patient = item.get('patient_id', None)
        item_val = toFloat(item.value)
        
        if item_val is not None:
            # перебираем параметры в справочнике
            for keyD, valD in iter_params(params_dic):
                
                if debug:
                    print(f"keyD = {keyD}, type(keyD) = {type(keyD)}")
                if keyD=='paramsNotLoaded':
                    continue
                
                if debug:
                    print(f"valD = {valD}, type(valD) = {type(valD)}")
                    print(f"type(item) = {type(item)}")
                    print(f"item = {item}")
                    print(f"type(valD) = {type(valD)}")
                    print(f"valD = {valD.print_prop(objName = 'valD', extend=True)}")
                # if valD.name.find(item.name)>=0 or item.name.find(valD.name)>=0:
                scoreMatch = fuzz.ratio(item.name.lower(), valD.name.lower())
                if debug:
                    print(f"item.name = {item.name}, valD.name = {valD.name}, scoreMatch = {scoreMatch}")
                if scoreMatch>94:
                    if debug:
                        print(f"\nСовпадение параметра {item.name} в словаре параметров")
                        print(f"keyD = {keyD}")
                        print(f"valD.name = {valD.name}, valD.state = {valD.state}, valD.organ = {valD.organ}, valD.system = {valD.system}, valD.tod_name = {valD.tod_name}, valD.gender = {valD.gender}, valD.age.min = {valD.age.min}, valD.age.max = {valD.age.max}, valD.deviation = {valD.deviation}")
                        print(f"valD.gender = {valD.gender}, item.gender = {item.gender}")
                        print(f"valD.gender==None = {valD.gender==None}, valD.gender.find(item.gender)>=0 = {valD.gender.find(item.gender) if valD.gender!=None else None}, item.gender.find(valD.gender)>=0 = {item.gender.find(valD.gender) if valD.gender!=None else None}")
                    
                    if valD.gender==None or valD.gender.find(item.gender)>=0 or item.gender.find(valD.gender)>=0:
                        if debug:
                            print(f"Совпадение по полу {item.gender} в словаре параметров")
                            print(f"type(valD.age.min) = {type(valD.age.min)}, type(valD.age.max) = {type(valD.age.max)}, type(item.age) = {type(item.age)}")
                        
                        checkRangeAge = FloatInterval.closed(valD.age.min, valD.age.max)
                        if debug:
                            print(f"item.age in checkRangeAge = {item.age in checkRangeAge}")
                        
                        if item.age in checkRangeAge:
                            if debug:
                                print(f"Совпадение по возрасту {item.age} в словаре параметров")
                            
                            # определяем среднее у нормы (по сути ядро нечёткого множества терма норма)
                            arrayValsNorm = list(filter(lambda x: x is not None, [toFloat(valD.norm.min), toFloat(valD.norm.max)]))
                            if debug: print(f"arrayValsNorm = {arrayValsNorm}")
                            countValsNorm = len(arrayValsNorm)
                            if debug:
                                print(f"arrayValsNorm = {arrayValsNorm}, countValsNorm = {countValsNorm}")
                            if countValsNorm>0:
                                avgNorm = sum(arrayValsNorm)/countValsNorm # корректное вычисление среднего
                            else:
                                avgNorm = None
                                if debug:
                                    print(f"В справочнике отсутствуют опорные данные по норме параметра {valD.name}!")
                                continue # переходим к следующему параметру
                            if debug:
                                print(f"avgNorm = {avgNorm}")
                            checkRangeNorm = FloatInterval.closed(toFloat(valD.norm.min), toFloat(valD.norm.max))
                            if debug:
                                print(f"checkRangeNorm = {checkRangeNorm}")
                            
                            # определяем среднее у умеренного отклонения (по сути ядро нечёткого множества терма умеренное отклонение)
                            arrayValsModDev = list(filter(lambda x: x is not None, [toFloat(valD.mod_dev.min), toFloat(valD.mod_dev.max)]))
                            if debug: print(f"arrayValsModDev = {arrayValsModDev}")
                            countValsModDev = len(arrayValsModDev)
                            if countValsModDev>0:
                                avgModDev = sum(arrayValsModDev)/countValsModDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    # checkRangeModDev = FloatInterval.closed(toFloat(valD.mod_dev.min, 1), toFloat(valD.mod_dev.max, 1))
                                    checkRangeModDev = FloatInterval.closed(toFloat(getMin([valD.mod_dev.min, checkRangeNorm.upper]), 1), toFloat(valD.mod_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeModDev = FloatInterval.closed(toFloat(valD.mod_dev.min, -1), toFloat(getMax([valD.mod_dev.max, checkRangeNorm.lower]), -1))
                            else:
                                avgModDev = None
                                print(f"В справочнике отсутствуют опорные данные по умеренному отклонению параметра {valD.name}!")
                                continue # переходим к следующему параметру
                            
                            if debug:
                                print(f"avgModDev = {avgModDev}")
                                print(f"checkRangeModDev = {checkRangeModDev}")
                            
                            # определяем среднее у выраженного отклонения (по сути ядро нечёткого множества терма выраженное отклонение)
                            arrayValsExpDev = list(filter(lambda x: x is not None, [toFloat(valD.exp_dev.min), toFloat(valD.exp_dev.max)]))
                            if debug: print(f"arrayValsExpDev = {arrayValsExpDev}")
                            countValsExpDev = len(arrayValsExpDev)
                            if debug: print(f"avgNorm<avgModDev = {avgNorm<avgModDev}")
                            if countValsExpDev>0:
                                avgExpDev = sum(arrayValsExpDev)/countValsExpDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    checkRangeExpDev = FloatInterval.closed(toFloat(getMin([valD.exp_dev.min, checkRangeModDev.upper]), 1), toFloat(valD.exp_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeExpDev = FloatInterval.closed(toFloat(valD.exp_dev.min, -1), toFloat(getMax([valD.exp_dev.max, checkRangeModDev.lower]), -1))
                            elif avgNorm<avgModDev:
                                avgExpDev = float('inf')
                                checkRangeExpDev = FloatInterval.closed(checkRangeModDev.upper, float('inf'))
                            else:
                                avgExpDev = -float('inf')
                                checkRangeExpDev = FloatInterval.closed(-float('inf'), checkRangeModDev.lower)
                            if debug:
                                print(f"avgExpDev = {avgModDev}")
                                print(f"checkRangeExpDev = {checkRangeExpDev}")
                            
                            # определяем среднее у критического отклонения (по сути ядро нечёткого множества терма выраженное отклонение)
                            arrayValsCritDev = list(filter(lambda x: x is not None, [toFloat(valD.crit_dev.min), toFloat(valD.crit_dev.max)]))
                            if debug: print(f"arrayValsCritDev = {arrayValsCritDev}")
                            countValsCritDev = len(arrayValsCritDev)
                            if debug: print(f"avgNorm<avgModDev = {avgNorm<avgModDev}")
                            if countValsCritDev>0:
                                avgCritDev = sum(arrayValsCritDev)/countValsCritDev
                                # отклонение от нормы в сторону повышения значения
                                if avgNorm<avgModDev:
                                    checkRangeCritDev = FloatInterval.closed(toFloat(getMin([valD.crit_dev.min, checkRangeExpDev.upper]), 1), toFloat(valD.crit_dev.max, 1))
                                # отклонение от нормы в сторону понижения значения
                                else:
                                    checkRangeCritDev = FloatInterval.closed(toFloat(valD.crit_dev.min, -1), toFloat(getMax([valD.crit_dev.max, checkRangeExpDev.lower]), -1))
                            elif avgNorm<avgModDev:
                                avgCritDev = float('inf')
                                checkRangeCritDev = FloatInterval.closed(checkRangeExpDev.upper, float('inf'))
                            else:
                                avgCritDev = -float('inf')
                                checkRangeCritDev = FloatInterval.closed(-float('inf'), checkRangeExpDev.lower)
                            if debug:
                                print(f"avgCritDev = {avgCritDev}")
                                print(f"checkRangeCritDev = {checkRangeCritDev}")
                            
                            priority = 0.5 if valD.priority.lower().find('неоснов')>=0 else 1
                            weight = 1 if valD.weight is None else toFloat(valD.weight)
                            if debug:
                                print(f"priority = {priority}, weight = {weight}")
                            
                            # вхождение в checkRangeNorm не проверяем
                            
                            if debug: print(f"item.value = {item.value}")
                            
                            item_val = toFloat(item.value)
                            devZone = 0 # зона в которую отклонился параметр
                            # начинаем проверку с вхождения в критический диапазон значений (это необходимо для качественных параметров, типа положительно/отрицательно)
                            if item_val in checkRangeCritDev:
                                devZone = 4 # зона критического отклонения
                                
                            elif item_val in checkRangeExpDev:
                                devZone = 3 # зона выраженного отклонения
                                
                            elif item_val in checkRangeModDev:
                                devZone = 2 # зона умеренного отклонения
                                
                            
                            if debug:
                                print(f"devZone = {devZone}")
                            if devZone>1:
                                stateName = clean_identifier(valD.state)
                                
                                if stateName in states:
                                    # обрабатываем качественный параметр типа, отрицательно/положительно
                                    if not math.isinf(avgNorm) or not math.isinf(item_val):
                                        dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val
                                        states[stateName].probality = weight * dev_value
                                    else:
                                        if avgNorm==float(-inf) or item_val==float(-inf):
                                            dev_value = '-nan'
                                        else:
                                            dev_value = 'nan'
                                        states[stateName].probality = item_val
                                    
                                    if debug:
                                        print(f"Ветка 'else:'")
                                        print(f"dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val = ")
                                        print(f"item_val = {item_val}, avgNorm = {avgNorm}")
                                    
                                else:
                                    states.setdefault(stateName, DictAttr())
                                    states[stateName].setdefault('research_id', id_research)
                                    states[stateName].setdefault('patient_id', id_patient)
                                    states[stateName].setdefault('name', valD.state)
                                    states[stateName].setdefault('probality', 0.)
                                    states[stateName].setdefault('params_main', DictAttr())
                                    states[stateName].setdefault('params_adv', DictAttr())
                                    
                                    # обрабатываем качественный параметр типа, отрицательно/положительно
                                    if not math.isinf(avgNorm) or not math.isinf(item_val):
                                        dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val
                                        states[stateName].probality = weight * dev_value
                                    else:
                                        if avgNorm==float(-inf) or item_val==float(-inf):
                                            dev_value = '-nan'
                                        else:
                                            dev_value = 'nan'
                                        states[stateName].probality = item_val
                                    
                                    if debug:
                                        print(f"Ветка 'else:'")
                                        print(f"dev_value = item_val/avgNorm if avgNorm<item_val else avgNorm/item_val = ")
                                        print(f"item_val = {item_val}, avgNorm = {avgNorm}")
                                    
                                
                                # добавляем информацию о параметре использованном для определении состояния
                                # если параметр для состояния основной (обязательный)
                                if priority>=1:
                                    states[stateName].params_main.setdefault(keyD, DictAttr())
                                    # states[stateName].params_main[valD.name] = DictAttr()
                                    states[stateName].params_main[keyD].setdefault('system', valD.system)
                                    states[stateName].params_main[keyD].setdefault('organ', valD.organ)
                                    states[stateName].params_main[keyD].setdefault('name', item.name)
                                    states[stateName].params_main[keyD].setdefault('value', item.value)
                                    states[stateName].params_main[keyD].setdefault('gender', item.gender)
                                    states[stateName].params_main[keyD].setdefault('age', item.age)
                                    states[stateName].params_main[keyD].setdefault('dev_zone', devZone)
                                    states[stateName].params_main[keyD].setdefault('dev_value', dev_value)
                                    states[stateName].params_main[keyD].setdefault('dynamic', valD.deviation)
                                    states[stateName].params_main[keyD].setdefault('tod_name', valD.tod_name)
                                    states[stateName].params_main[keyD].setdefault('rec_name', valD.rec_name)
                                else:
                                    states[stateName].params_adv.setdefault(keyD, DictAttr())
                                    # states[stateName].params_adv[valD.name] = DictAttr()
                                    states[stateName].params_adv[keyD].setdefault('system', valD.system)
                                    states[stateName].params_adv[keyD].setdefault('organ', valD.organ)
                                    states[stateName].params_adv[keyD].setdefault('name', item.name)
                                    states[stateName].params_adv[keyD].setdefault('value', item.value)
                                    states[stateName].params_adv[keyD].setdefault('gender', item.gender)
                                    states[stateName].params_adv[keyD].setdefault('age', item.age)
                                    states[stateName].params_adv[keyD].setdefault('dev_zone', devZone)
                                    states[stateName].params_adv[keyD].setdefault('dev_value', dev_value)
                                    states[stateName].params_adv[keyD].setdefault('dynamic', valD.deviation)
                                    states[stateName].params_adv[keyD].setdefault('tod_name', valD.tod_name)
                                    states[stateName].params_adv[keyD].setdefault('rec_name', valD.rec_name)
                                    
                                
                                # if 'params_main' in states[stateName].keys():
                                    # params_main_sort = sorted(states[stateName]['params_main'].values(), key=lambda x: x['dev_zone'], reverse=True)
                                    # if debug:
                                        # print(f"params_main_sort = {params_main_sort}")
                                        
                                    
                                
                                # if 'params_adv' in states[stateName].keys():
                                    # params_adv_sort = sorted(states[stateName]['params_adv'].values(), key=lambda x: x['dev_zone'], reverse=True)
                                    # if debug:
                                        # print(f"params_adv_sort = {params_adv_sort}")
                                        
                                    
                                
                                # для формирования текста результата интерпретации по параметру
                                system_str = str(valD.system)
                                organ_str = str(valD.organ)
                                state_str = str(valD.state)
                                
                                # формируем текст результата
                                text_dict = dict()
                                text_dict[system_str] = dict()
                                text_dict[system_str][organ_str] = dict() # получаем справочник в виде {система{орган{состояние{}}}}
                                
                                # формируем отсортированный по dev_zone отклонения
                                dev_str_list = list()
                                # parmainadv_str_list = list()
                                if 'params_main' in states[stateName].keys() and 'params_adv' in states[stateName].keys():
                                    params_mainadv_values = list(states[stateName]['params_main'].values()) + list(states[stateName]['params_adv'].values())
                                    params_mainadv_sort = sorted(params_mainadv_values, key=lambda x: x['dev_zone'], reverse=True)
                                    
                                    if debug:
                                        print(f"params_mainadv_values = {params_mainadv_values}")
                                        print(f"params_mainadv_sort = {params_mainadv_sort}")
                                    
                                    # копируем строки описания наименования отклонений с отсортированного списка параметров
                                    for ipar in params_mainadv_sort:
                                        if debug:
                                            print(f"ipar = {ipar}")
                                            print(f"ipar.dynamic = {ipar.dynamic}")
                                        dev_str_list.append(ipar.dynamic)
                                        # dev_str_list.append(ipar[''])
                                    
                                    if debug: print(f"dev_str_list = {dev_str_list}")
                                
                                text_dict[system_str][organ_str][state_str] = dev_str_list # получаем справочник в виде {система{орган{состояние{[отсортированный_список_наименований_отклонений]}}}}
                                states[stateName]['sort_params_text'] = str(text_dict)
                                
                            
        
        if debug:
            print(f"states = {states}\n")
    
    if debug:
        print(f"len(states) = {len(states)}")
        print(f"states = {states}")
    
    if debug:
        print(f"getState: End")
    
    return states

# функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
def getState_by_reseach_id_and_save_to_base_v1(param_db, research_id, addValue=True, to_json=False, debug=False):
    """
    Определить состояния и их вероятности по данным измеренных параметров исследования по его идентификатору, на основании соспоставления их со справочником параметров, 
    отсортировать состояния по степени их значимости и сохранить результаты в таблицу 'Conclusion' базы данных.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        research_id (int): ID исследования с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug (bool, optional): Режим отладки. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему. Структура словаря:
            {
                'КлючСостояния': {
                        'research_id': int,            # Идентификатор исследования
                        'patient_id': int,             # Идентификатор пациента
                        'name': str,                   # Наименование состояния
                        'probality': float,            # Вероятность состояния
                        'params_main': DictAttr,       # Основные параметры
                            # Каждый параметр: {       #
                            #   "system": str,         # Наименование Системы
                            #   "organ": str,          # Наименование Органа
                            #   "name": str,           # Наименование параметра
                            #   "value": float,        # Значение параметра
                            #   "gender": str,         # Пол
                            #   "age": int,            # Возраст
                            #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                            #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                            #   "dynamic": str,        # Строковое наименование изменения состояния
                            # },                       #
                        'params_adv': DictAttr,        # Неосновные параметры. Структура как у 'params_main'
                        'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                        'sort_params_text': str,       # Строковое представление словаря sort_params
                    },
                'sort_states': list(dict)              # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
                'sort_states_text': str                # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
            }
        Идентификатор записи: int
    
    Замечания:
        Сохранение результатов выполняется в следующие поля таблицы 'Conclusion' базы данных и следующих данных:
            research_id - идентификатор исследования;
            patient_id - идентификатор пациента;
            date_create - дата и время выполнения записи в базу;
            inter_results - строка данных интерпретации лабораторных данных;
            raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией getState() и обработанный сортировкой.

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_by_reseach_id = interpreter.getState_by_reseach_id_and_save_to_base(param_db, 4, addValue=True)
        >>> print(f"type(state_by_reseach_id) = {type(state_by_reseach_id)}")
        >>> print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
        type(state_by_reseach_id) = <class 'lab_data_interpreter.interpreter.DictAttr'>
        state_by_reseach_id = {
          "Gipokoagulyaciya": {
            "research_id": 4,
            "patient_id": 7,
            "name": "Гипокоагуляция",
            "probality": 1.17,
            "params_main": {
              "MNO_197": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "МНО",
                "value": 1.17,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.17,
                "dynamic": "Повышение уровня МНО"
              }
            },
            "params_adv": {
              "Protrombinovoe_vremya_201": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "Протромбиновое время",
                "value": 14.3,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.1485943775100402,
                "dynamic": "Удлинение протромбинового времени"
              }
            },
            "sort_params_text": "{'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}",
            "sort_params": {
              "Свертывающая система крови": {
                "null": {
                  "Гипокоагуляция": [
                    "Повышение уровня МНО:2",
                    "Удлинение протромбинового времени:2"
                  ]
                }
              }
            }
          },
          ...
        }
    """
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base_v1(): Begin")
        print(f"Считываем с базы справочник параметров")
    dos = database.get_dos(param_db)
    
    if debug:
        print("\nСоздаём объект-справочник параметров из dos-таблицы")
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos, debug)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    if debug:
        print(f"Считываем с базы по id запись по измеренным анализам пациента")
    params_patient = database.get_research_by_id(param_db, research_id)
    # params_patient_dict = buildResearchParams(params_patient, debug=False)
    params_patient_dict = buildResearchParams(params_patient, debug)
    if debug:
        print(f"params_patient_dict = {json.dumps(params_patient_dict, indent=2, ensure_ascii=False, default=str)}")
    
    if debug:
        print(f"Определяем состояния по данным исследования пациента")
    # определяем состояния и их вероятности
    # state_by_reseach_id = getState(params_template, params_patient_dict, debug=False)
    state_by_reseach_id = getState(params_template, params_patient_dict, debug)
    if debug:
        print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
    
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    if debug:
        print(f"id_research, id_patient = {id_research, id_patient}")
    
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug=False)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item], debug=False)
            if debug:
                # print(f"sortParamStr = {sortParamStr}")
                print(f"sortParamStr = {json.dumps(sortParamStr, indent=2, ensure_ascii=False, default=str)}")
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json, debug)
    # sortStates = sortedStatesText_v2(state_patient, debug=False)
    if debug:
        # print(f"sortStatesText = {sortStatesText}")
        print(f"sortStatesText = {json.dumps(sortStatesText, indent=2, ensure_ascii=False, default=str)}")
    
    if not to_json:
        result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(sortStates), str(state_by_reseach_id), debug)
    else:
        sortStatesText_json = json.dumps(sortStates, indent=None, ensure_ascii=False, default=str)
        result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStatesText_json, str(state_by_reseach_id), debug)
    
    if debug:
        print(f"Результаты записи в таблицу conclusion базы данных")
        print(f"result, record_id = {result, record_id}")
    
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base_v1(): End")
    
    return state_by_reseach_id, record_id

# функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
def getState_by_reseach_id_and_save_to_base(param_db, research_id, addValue=True, to_json=False, debug=False):
    """
    Определить состояния и их вероятности по данным измеренных параметров исследования по его идентификатору, на основании соспоставления их со справочником параметров, 
    отсортировать состояния по степени их значимости и сохранить результаты в таблицу 'Conclusion' базы данных.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        research_id (int): ID исследования с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug (bool, optional): Режим отладки. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему. Структура словаря:
            {
                'КлючСостояния': {
                        'research_id': int,            # Идентификатор исследования
                        'patient_id': int,             # Идентификатор пациента
                        'name': str,                   # Наименование состояния
                        'probality': float,            # Вероятность состояния
                        'params_main': DictAttr,       # Основные параметры
                            # Каждый параметр: {       #
                            #   "system": str,         # Наименование Системы
                            #   "organ": str,          # Наименование Органа
                            #   "name": str,           # Наименование параметра
                            #   "value": float,        # Значение параметра
                            #   "gender": str,         # Пол
                            #   "age": int,            # Возраст
                            #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                            #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                            #   "dynamic": str,        # Строковое наименование изменения состояния
                            # },                       #
                        'params_adv': DictAttr,        # Неосновные параметры. Структура как у 'params_main'
                        'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                        'sort_params_text': str,       # Строковое представление словаря sort_params
                    },
                'sort_states': list(dict)              # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
                'sort_states_text': str                # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
            }
        Возвращает идентификатор записи в таблице Conclusion базы данных: int
    
    Замечания:
        Сохранение результатов выполняется в следующие поля таблицы 'Conclusion' базы данных и следующих данных:
            research_id - идентификатор исследования;
            patient_id - идентификатор пациента;
            date_create - дата и время выполнения записи в базу;
            inter_results - словарь со строкой данных интерпретации лабораторных данных, вывода в виде списка состояний и списка рекомендаций;
            raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией getState() и обработанный сортировками параметров и состояний.

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json
        >>> state_by_reseach_id, record_id = interpreter.getState_by_reseach_id_and_save_to_base(param_db, 4, addValue=True)
        >>> print(f"type(state_by_reseach_id) = {type(state_by_reseach_id)}")
        >>> print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
        type(state_by_reseach_id) = <class 'lab_data_interpreter.interpreter.DictAttr'>
        state_by_reseach_id = {
          "Gipokoagulyaciya": {
            "research_id": 4,
            "patient_id": 7,
            "name": "Гипокоагуляция",
            "probality": 1.17,
            "params_main": {
              "MNO_197": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "МНО",
                "value": 1.17,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.17,
                "dynamic": "Повышение уровня МНО"
              }
            },
            "params_adv": {
              "Protrombinovoe_vremya_201": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "Протромбиновое время",
                "value": 14.3,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.1485943775100402,
                "dynamic": "Удлинение протромбинового времени"
              }
            },
            "sort_params_text": "{'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}",
            "sort_params": {
              "Свертывающая система крови": {
                "null": {
                  "Гипокоагуляция": [
                    "Повышение уровня МНО:2",
                    "Удлинение протромбинового времени:2"
                  ]
                }
              }
            }
          },
          ...
        }
    """
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base(): Begin")
        print(f"Считываем с базы справочник параметров")
    dos = database.get_dos(param_db) # считаем данные справочник с базы данных
    
    if debug:
        print("\nСоздаём объект-справочник параметров из dos-таблицы")
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos, debug)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"Ошибка создания объекта словаря параметров! Информация об ошибке e: {e}")
    
    # 1. считываем с базы по id запись исследования по измеренным анализам пациента
    if debug:
        print(f"Считываем с базы по id запись по измеренным анализам пациента")
    params_patient = database.get_research_by_id(param_db, research_id)
    # params_patient_dict = buildResearchParams(params_patient, debug=False)
    params_patient_dict = buildResearchParams(params_patient, debug)
    if debug:
        print(f"params_patient_dict = {json.dumps(params_patient_dict, indent=2, ensure_ascii=False, default=str)}")
    
    # 2. определяем состояния и их вероятности
    if debug:
        print(f"Определяем состояния по данным исследования пациента")
    # state_by_reseach_id = getState(params_template, params_patient_dict, debug=False)
    state_by_reseach_id = getState(params_template, params_patient_dict, debug)
    if debug:
        print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    if debug:
        print(f"id_research, id_patient = {id_research, id_patient}")
    
    # 4. сформируем отсортированный список состояний для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug=False)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item], debug=False)
            if debug:
                # print(f"sortParamStr = {sortParamStr}")
                print(f"sortParamStr = {json.dumps(sortParamStr, indent=2, ensure_ascii=False, default=str)}")
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json, debug)
    if debug:
        # print(f"sortStates = {sortStates}")
        print(f"sortStates = {json.dumps(sortStates, indent=2, ensure_ascii=False, default=str)}")
    
    # 5. сформируем строку списка состояний для текста вывода в протоколе
    if debug:
        print(f"Сформируем строку вывода для протокола")
    list_state_name = list() # список состояний
    sortedStates = getListSortedStates(state_by_reseach_id, debug) # получим отсортированный список состояний
    i = 0
    while i<len(sortedStates):
        if debug: print(f"sortedStates[{i}] = {sortedStates[i]}")
        state = sortedStates[i]
        if 'name' in state:
            list_state_name.append(state['name'])
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        i += 1
    recap_str = 'Выявлены лабораторные признаки: ' + ', '.join(list_state_name) # сформируем строку списка состояний перечисленных через запятую
    if debug:
        # print(f"recap_str = {recap_str}")
        print(f"recap_str = {json.dumps(recap_str, indent=2, ensure_ascii=False, default=str)}")
    
    # 6. сформируем строку рекомендаций для текста рекомендаций в протоколе
    if debug:
        print(f"Сформируем строку рекомендаций для текста рекомендаций в протоколе")
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        if debug: print(f"sortedStates[{i}] = {sortedStates[i]}")
        state = sortedStates[i]
        if debug: print(f"state = {state}")
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        if debug: print("Формируем список основных рекомендаций из списка отсортированных основных параметров.")
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            if debug: print(f"params_main_sort = {params_main_sort}")
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        if debug: print("Формируем список неосновных рекомендаций из списка отсортированных неосновных параметров.")
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            if debug: print(f"params_adv_sort = {params_adv_sort}")
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        if debug: print("Формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров.")
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            if debug: print(f"params_mainadv_sort = {params_mainadv_sort}")
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        if debug:
            print("function get_states_patient_async(): Формируем список параметров требующих контроль.")
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            if debug:
                print(f"params_mainadv_sort = {params_mainadv_sort}")
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        if debug:
            print(f"Полученная строка контроля динамики лабораторных показателей params_str_check = {params_str_check}")
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    elif debug:
        print(f"params_str_check = {params_str_check}")
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient, debug=False)
    if debug:
        # print(f"inter_result = {inter_result}")
        print(f"inter_result = {json.dumps(inter_result, indent=2, ensure_ascii=False, default=str)}")
    
    if not to_json:
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, str(inter_result), str(state_by_reseach_id), debug)
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            print(f"function getState_by_reseach_id_and_save_to_base():  End")
            return None, e
        
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = database.save_conclusion_v2(param_db, id_research, id_patient, sortStates_json, str(state_by_reseach_id), debug)
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base(): При сохранении результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных возникла ошибка: {e}")
            print(f"function getState_by_reseach_id_and_save_to_base():  End")
            return None, e
    
    if debug:
        print(f"Результаты записи в таблицу conclusion базы данных")
        print(f"result, record_id = {result, record_id}")
    
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base(): End")
    
    return state_by_reseach_id, record_id

# асинхронная функция определения состояния и их вероятности по данным измеренных параметров исследования по указанному идентификатору, на основании соспоставления их со справочником параметров
# в результат добавлены словари вывода и рекомендаций для протокола {recap:str, recomend:list}
async def getState_by_reseach_id_and_save_to_base_async(param_db, research_id, addValue=True, to_json=False, debug=False):
    """
    Определить состояния и их вероятности по данным измеренных параметров исследования по его идентификатору, на основании соспоставления их со справочником параметров, 
    отсортировать состояния по степени их значимости и сохранить результаты в таблицу 'Conclusion' базы данных.
    Функция асинхронная. Вызов через await (требует работающий event loop), или через asyncio.run.

    Аргументы:
        param_db (dict): Параметры подключения к базе данных (host, port, database, user, password, client_encoding).
        research_id (int): ID исследования с данными измеренных параметров (маркеров).
        addValue (bool, optional): bool. Если True, то в строке результата за наименованием состояния и параметра через ':' будет добавлено числовое значение вероятности состояния и зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug (bool, optional): Режим отладки. По умолчанию False.

    Результаты:
        Возвращает словарь с атрибутами DictAttr, по каждому из которых хранится словарь состояния DictAttr с данными по нему. Структура словаря:
            {
                'КлючСостояния': {
                        'research_id': int,            # Идентификатор исследования
                        'patient_id': int,             # Идентификатор пациента
                        'name': str,                   # Наименование состояния
                        'probality': float,            # Вероятность состояния
                        'params_main': DictAttr,       # Основные параметры
                            # Каждый параметр: {       #
                            #   "system": str,         # Наименование Системы
                            #   "organ": str,          # Наименование Органа
                            #   "name": str,           # Наименование параметра
                            #   "value": float,        # Значение параметра
                            #   "gender": str,         # Пол
                            #   "age": int,            # Возраст
                            #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                            #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                            #   "dynamic": str,        # Строковое наименование изменения состояния
                            # },                       #
                        'params_adv': DictAttr,        # Неосновные параметры. Структура как у 'params_main'
                        'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                        'sort_params_text': str,       # Строковое представление словаря sort_params
                    },
                'sort_states': list(dict)              # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
                'sort_states_text': str                # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
            }
        Возвращает идентификатор записи в таблице Conclusion базы данных: int
    
    Замечания:
        Сохранение результатов выполняется в следующие поля таблицы 'Conclusion' базы данных и следующих данных:
            research_id - идентификатор исследования;
            patient_id - идентификатор пациента;
            date_create - дата и время выполнения записи в базу;
            inter_results - словарь со строкой данных интерпретации лабораторных данных, вывода в виде списка состояний и списка рекомендаций;
            raw_data - объект данных интерпретации лабораторных анализов, возвращённый функцией getState() и обработанный сортировками параметров и состояний.

    Пример:
        >>> import lab_data_interpreter.interpreter as interpreter
        >>> import json, asyncio
        >>> state_by_reseach_id, record_id = await getState_by_reseach_id_and_save_to_base_async.getState_by_reseach_id_and_save_to_base(param_db, 4, addValue=True)
        или 
        >>> state_by_reseach_id, record_id = asyncio.run(getState_by_reseach_id_and_save_to_base_async.getState_by_reseach_id_and_save_to_base(param_db, 4, addValue=True))
        >>> print(f"type(state_by_reseach_id) = {type(state_by_reseach_id)}")
        >>> print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
        type(state_by_reseach_id) = <class 'lab_data_interpreter.interpreter.DictAttr'>
        state_by_reseach_id = {
          "Gipokoagulyaciya": {
            "research_id": 4,
            "patient_id": 7,
            "name": "Гипокоагуляция",
            "probality": 1.17,
            "params_main": {
              "MNO_197": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "МНО",
                "value": 1.17,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.17,
                "dynamic": "Повышение уровня МНО"
              }
            },
            "params_adv": {
              "Protrombinovoe_vremya_201": {
                "system": "Свертывающая система крови",
                "organ": null,
                "name": "Протромбиновое время",
                "value": 14.3,
                "gender": "женский",
                "age": 80,
                "dev_zone": 2,
                "dev_value": 1.1485943775100402,
                "dynamic": "Удлинение протромбинового времени"
              }
            },
            "sort_params_text": "{'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}",
            "sort_params": {
              "Свертывающая система крови": {
                "null": {
                  "Гипокоагуляция": [
                    "Повышение уровня МНО:2",
                    "Удлинение протромбинового времени:2"
                  ]
                }
              }
            }
          },
          ...
        }
    """
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base_async(): Begin")
        print(f"Считываем с базы справочник параметров")
    
    # считаем данные справочник с базы данных
    try:
        dos = await database_async.get_dos_async(param_db, debug)
    except Exception as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): При запросе справочных данных параметров из таблицы 'DOS' у базы данных возникла ошибка: {e}")
        return None, e
    
    if debug:
        print("\nСоздаём объект-справочник параметров из dos-таблицы")
    # создаём объект-справочник эталонных значений параметров для оценки измеренных анализов пациентов
    try:
        params_template = Parameters(dos, debug)
        # params_template.print_prop(extend=False)
        # params_template_json = json.dumps(params_template, indent=2, ensure_ascii=False, default=str)
        # print(f"\nparams_template = \n{params_template}")
        # print(f"\nparams_template_json = \n{params_template_json}")
    except (TypeError, KeyError, ValueError) as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): При создании объекта словаря параметров возникала ошибка: {e}")
    
    # 1. считываем с базы по id запись исследования по измеренным анализам пациента
    if debug:
        print(f"Считываем с базы по id запись по измеренным анализам пациента")
    try:
        params_patient = await database_async.get_research_by_id_async(param_db, research_id, debug)
    except Exception as e:
        print(f"function getState_by_reseach_id_and_save_to_base_async(): Возникла ошибка при попытке запроса по id запись по измеренным анализам пациента из таблицы 'Research' у базы данных {e}")
        return None, e
    
    # params_patient_dict = buildResearchParams(params_patient, debug=False)
    params_patient_dict = buildResearchParams(params_patient, debug)
    if debug:
        print(f"params_patient_dict = {json.dumps(params_patient_dict, indent=2, ensure_ascii=False, default=str)}")
    
    # 2. определяем состояния и их вероятности
    if debug:
        print(f"Определяем состояния по данным исследования пациента")
    # state_by_reseach_id = getState(params_template, params_patient_dict, debug=False)
    state_by_reseach_id = getState(params_template, params_patient_dict, debug)
    if debug:
        print(f"state_by_reseach_id = {json.dumps(state_by_reseach_id, indent=2, ensure_ascii=False, default=str)}")
    
    # 3. определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state_by_reseach_id.values()), (None, None) )
    if debug:
        print(f"id_research, id_patient = {id_research, id_patient}")
    
    # 4. сформируем отсортированный список состояний для текста заключения в протоколе
    # сортируем по значимости параметры в каждом состоянии
    if len(state_by_reseach_id)>0:
        for item in state_by_reseach_id:
            # sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug=False)
            sortParamStr = sortedParamsStateText(state_by_reseach_id[item], addValue, to_json, debug)
            # sortParamStr2 = sortedParamsStateText_v2(state_by_reseach_id[item], debug=False)
            if debug:
                # print(f"sortParamStr = {sortParamStr}")
                print(f"sortParamStr = {json.dumps(sortParamStr, indent=2, ensure_ascii=False, default=str)}")
    
    sortStates = sortedStatesText(state_by_reseach_id, addValue, to_json, debug)
    if debug:
        # print(f"sortStates = {sortStates}")
        print(f"sortStates = {json.dumps(sortStates, indent=2, ensure_ascii=False, default=str)}")
    
    # 5. сформируем строку списка состояний для текста вывода в протоколе
    if debug:
        print(f"Сформируем строку вывода для протокола")
    list_state_name = list() # список состояний
    sortedStates = getListSortedStates(state_by_reseach_id, debug) # получим отсортированный список состояний
    i = 0
    while i<len(sortedStates):
        if debug: print(f"sortedStates[{i}] = {sortedStates[i]}")
        state = sortedStates[i]
        if 'name' in state:
            if state['name'] not in list_state_name:
                list_state_name.append(state['name'])
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ name в словаре состояния полученного от getState()!")
        i += 1
    recap_str = 'Выявлены лабораторные признаки: ' + ', '.join(list_state_name) # сформируем строку списка состояний перечисленных через запятую
    if debug:
        # print(f"recap_str = {recap_str}")
        print(f"recap_str = {json.dumps(recap_str, indent=2, ensure_ascii=False, default=str)}")
    
    # 6. сформируем строку рекомендаций для текста рекомендаций в протоколе
    if debug:
        print(f"Сформируем строку рекомендаций для текста рекомендаций в протоколе")
    list_rec_name = list() # общий список рекомендаций
    list_rec_name_main = list() # список рекомендаций из списка основных параметров
    list_rec_name_adv = list() # список рекомендаций из списка неосновных параметров
    list_params_check = list() # список параметров для формирования строки списка параметров требующих контроль
    i = 0
    while i<len(sortedStates):
        if debug: print(f"sortedStates[{i}] = {sortedStates[i]}")
        state = sortedStates[i]
        if debug: print(f"state = {state}")
        
        # формируем список основных рекомендаций из списка отсортированных основных параметров
        if debug: print("Формируем список основных рекомендаций из списка отсортированных основных параметров.")
        params_main_sort = None
        if 'params_main_sort' in state:
            params_main_sort = sortedStates[i]['params_main_sort']
            if debug: print(f"params_main_sort = {params_main_sort}")
            
            iP = 0
            while iP<len(params_main_sort):
                param = params_main_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_main:
                        list_rec_name_main.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_main_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем список неосновных рекомендаций из списка отсортированных неосновных параметров
        if debug: print("Формируем список неосновных рекомендаций из списка отсортированных неосновных параметров.")
        params_adv_sort = None
        if 'params_adv_sort' in state:
            params_adv_sort = sortedStates[i]['params_adv_sort']
            if debug: print(f"params_adv_sort = {params_adv_sort}")
            
            iP = 0
            while iP<len(params_adv_sort):
                param = params_adv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name_adv:
                        list_rec_name_adv.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_adv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров
        if debug: print("Формируем общий список рекомендаций из общего списка отсортированных основных и неосновных параметров.")
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            if debug: print(f"params_mainadv_sort = {params_mainadv_sort}")
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'rec_name' in param:
                    if param['rec_name'] not in list_rec_name:
                        list_rec_name.append(param['rec_name'])
                else:
                    print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
        else:
            print(f"getState_by_reseach_id_and_save_to_base_async(): Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        # формируем общий список параметров для строки списка параметров требующих контроль
        if debug:
            print("function get_states_patient_async(): Формируем список параметров требующих контроль.")
        params_mainadv_sort = None
        if 'params_mainadv_sort' in state:
            params_mainadv_sort = sortedStates[i]['params_mainadv_sort']
            if debug:
                print(f"params_mainadv_sort = {params_mainadv_sort}")
            
            iP = 0
            while iP<len(params_mainadv_sort):
                param = params_mainadv_sort[iP]
                if 'name' in param:
                    if param['name'] not in list_params_check:
                        list_params_check.append(param['name'])
                else:
                    print(f"Ошибка в логике исполнения! Отсутствует ключ rec_name в словаре параметра состояния полученного от getState()!")
                
                iP += 1
                
        else:
            print(f"Ошибка в логике исполнения! Отсутствует ключ params_mainadv_sort в словаре состояния полученного при сортировке от sortedParamsStateText()!")
        
        i += 1
    
    # в конец списка рекомендаций добавляем список параметров на основании которых определены ненормальные состояния
    params_str_check = ""
    if len(list_params_check)>0:
        params_str_check = "Контроль динамики лабораторных показателей: " + ", ".join(list_params_check)
        if debug:
            print(f"Полученная строка контроля динамики лабораторных показателей params_str_check = {params_str_check}")
        list_rec_name.append(params_str_check) # добавляем в коен списка рекомендаций
    elif debug:
        print(f"params_str_check = {params_str_check}")
    
    # recomend_str = ', '.join(list_rec_name) # сформируем строку списка рекомендаций перечисленных через запятую
    list_rec_name_json = json.dumps(list_rec_name, indent=None, ensure_ascii=False, default=str)
    
    # 7. сформируем словарь заключений, вывода и рекомендаций для протокола
    inter_result = None
    if not to_json:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':str(list_rec_name) }
    else:
        inter_result = { 'conclusion':sortStates, 'recap':recap_str, 'recomend':list_rec_name_json }
    
    # sortStates = sortedStatesText_v2(state_patient, debug=False)
    if debug:
        # print(f"inter_result = {inter_result}")
        print(f"inter_result = {json.dumps(inter_result, indent=2, ensure_ascii=False, default=str)}")
    
    if not to_json:
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, str(inter_result), str(state_by_reseach_id), debug)
            
        except Exception as e:
            print(f"function getState_by_reseach_id_and_save_to_base_async(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            print(f"function getState_by_reseach_id_and_save_to_base_async():  End")
            return None, e
    else:
        sortStates_json = json.dumps(inter_result, indent=None, ensure_ascii=False, default=str)
        try:
            result, record_id = await database_async.save_conclusion_v2_async(param_db, id_research, id_patient, sortStates_json, str(state_by_reseach_id), debug)
            
        except Exception as e:
            print(f"function get_states(): Возникла ошибка при попытке сохранения результатов интерпретации лабораторных данных в таблицу 'Conclusion' базы данных {e}")
            print(f"getState_by_reseach_id_and_save_to_base_async(): End")
            return None, e
        
    
    if debug:
        print(f"Результаты записи в таблицу conclusion базы данных")
        print(f"result, record_id = {result, record_id}")
    
    if debug:
        print(f"getState_by_reseach_id_and_save_to_base_async(): End")
    
    return state_by_reseach_id, record_id





# функции для определения критичности состояния
# отсортировать в тексте интерпретации объекта списка состояний, возвращённой функцией getState(), основные и неосновные параметры отклонений по выраженности и отклонению от нормы
def sortedParamsStateText(state, addParamValue=True, to_json=False, debug=False):
    """
    Сортирует основные и неосновные параметры отклонений по выраженности и отклонению от нормы в состояниях в объекте списка состояний, возвращённой функцией getState().
    
    Аргументы:
        state: DictAttr. Объект типа DictAttr содержащий данные о основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str,        # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояний с отсортированными параметрами
                'sort_params_text': str        # Строковое преставление словаря sort_params
            }
        addParamValue (bool, optional): bool. Если True, то в результат будет добавлено числовое значение зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug (bool, optional): Если True, выводит отладочную информацию. По умолчанию False.
    
    Результат:
        В переданном объекте state типа DictAttr изменяются/добавляются поля:
         - 'sort_params' содержащий полученный объект состояния с отсортированными параметрами
         - 'sort_params_text' содержащий строковое преставление 'sort_params'
         Для последующих анализов сохраняются также списки отсортированных параметров:
         - 'params_main_sort' - список отсортированных основных параметров
         - 'params_adv_sort' - список отсортированных неосновных параметров
         - 'params_mainadv_sort'' - список отсортированных основных и неосновных параметров
         
        Структура данных в поле 'sort_params':
        {'Наименование_системы':{'Наименование_органа':{'Наименование_состояния:Значение':['Наименование_параметра:Значение_зона_в_которую_отклонился_параметр_от_зоны_нормы']}}}
        При включённом addParamValue к каждому параметру добавляется значение зоны, в которую отклонился параметр.
        Допустимые значения зоны отклонения: 2 - зона умеренного отклонения, 3 - выраженное отклонение, 4 - критическое отклонение.
    
    Замечания:
        - Сортировка параметров выполняется по комбинированному критерию: 
          - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.
    
    Пример:
        >>> result = sortedParamsStateText(state, addParamValue=True)
        >>> print(result)
        >>> print(state.sort_params_text)
        {'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}
        {'Свертывающая система крови': {None: {'Гипокоагуляция': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}
    """
    
    if debug:
        print(f"\nsortedParamsStateText: Begin\n")
        print(f"state['sort_params_text'] = {state.get('sort_params_text')}")
        print(f"type(state) = {type(state)}, \nstate = {state}")
        print(f"state.name = {state.name}")
        print(f"state.probality = {state.probality}")
        print(f"state.research_id = {state.research_id}")
        print(f"state.patient_id = {state.patient_id}")
        print(f"state.params_main = {state.params_main}, len(state.params_main) = {len(state.params_main)}")
        print(f"state.params_adv = {state.params_adv}, len(state.params_adv) = {len(state.params_adv)}")
        
        for k,v in state.items():
            print(f"k = {k}, v = {v}, type(v) = {type(v)}")
    
    # для формирования текста результата интерпретации по параметру
    system_str = '' # система
    organ_str = '' # органы
    state_str = state.name # состояние
    
    if len(state.params_main)>0:
        for k,v in state.params_main.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    else:
        for k,v in state.params_adv.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    
    if debug: print(f"system_str = {system_str}, organ_str = {organ_str}, state_str = {state_str}")
    
    # формируем текст результата
    sort_params_dict = dict()
    sort_params_dict[system_str] = dict()
    sort_params_dict[system_str][organ_str] = dict()
    
    # формируем отсортированный по dev_zone отклонения
    dev_str_list = list()
    # parmainadv_str_list = list()
    if 'params_main' in state.keys() and 'params_adv' in state.keys():
        params_main_sort = sorted(list(state['params_main'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_adv_sort = sorted(list(state['params_adv'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_mainadv_sort = params_main_sort + params_adv_sort
        
        if debug:
            params_mainadv_values = list(state['params_main'].values()) + list(state['params_adv'].values())
            params_all_sort = sorted(params_mainadv_values, key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
            print(f"params_mainadv_values = {params_mainadv_values}, type(params_mainadv_values) = {type(params_mainadv_values)}")
            print(f"params_main_sort = {params_main_sort}, type(params_main_sort) = {type(params_main_sort)}")
            print(f"params_adv_sort = {params_adv_sort}, type(params_adv_sort) = {type(params_adv_sort)}")
            print(f"params_mainadv_sort = {params_mainadv_sort}, type(params_mainadv_sort) = {type(params_mainadv_sort)}")
            print(f"params_all_sort = {params_all_sort}, type(params_all_sort) = {type(params_all_sort)}")
        
        # копируем строки описания наименования отклонений с отсортированного списка параметров
        for ipar in params_mainadv_sort:
            if debug:
                print(f"ipar = {ipar}")
                print(f"ipar.dynamic = {ipar.dynamic}")
            if addParamValue:
                dev_str_list.append( ''.join([str(ipar.dynamic), ' (', str(ipar.value), ' ', str(ipar.tod_name), '):', str(ipar.dev_zone)]) )
            else:
                dev_str_list.append(ipar.dynamic)
            # dev_str_list.append(ipar[''])
        
        if debug: print(f"dev_str_list = {dev_str_list}")
    
    sort_params_dict[system_str][organ_str][state_str] = dev_str_list # получаем словарь в виде {система{орган{состояние{[отсортированный_список_наименований_отклонений]}}}}
    state['params_main_sort'] = params_main_sort
    state['params_adv_sort'] = params_adv_sort
    state['params_mainadv_sort'] = params_mainadv_sort
    state['sort_params'] = sort_params_dict
    if not to_json:
        state['sort_params_text'] = str(sort_params_dict)
    else:
        state['sort_params_text'] = json.dumps(sort_params_dict, indent=None, ensure_ascii=False, default=str)
    
    if debug:
        print(f"state['sort_params_text'] = {state['sort_params_text']}")
        print(f"\nsortedParamsStateText: End\n")
    return sort_params_dict

# отсортировать в тексте интерпретации объекта списка состояний, возвращённой функцией getState(), основные и неосновные параметры отклонений по выраженности и отклонению от нормы
def sortedParamsStateText_v2(state, debug=False):
    """
    Сортирует основные и неосновные параметры отклонений по выраженности и отклонению от нормы в состояниях в объекте списка состояний, возвращённой функцией getState().
    
    Аргументы:
        state: DictAttr. Объект типа DictAttr содержащий данные о основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str         # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                'sort_params_text': str,       # Строковое представление словаря sort_params
                'sort_params_v2': dict,        # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Аналог 'sort_params' но более подробный и структурированный
                'sort_params_text_v2': str,    # Строковое представление словаря sort_params_v2
            }
        debug (bool, optional): Если True, выводит отладочную информацию. По умолчанию False.
    
    Результат:
        В переданном объекте state типа DictAttr изменяются/добавляются поля:
         - 'sort_params_v2' содержащий полученный объект состояния с отсортированными параметрами
         - 'sort_params_text_v2' содержащий строковое преставление 'sort_params_v2'
        Структура данных в поле 'sort_params_v2':
        {'system': [{'name': str, 'organ': [{'name': str, 'state': [{'name': 'str', 'probality': float, 'params_main': [{'name': str, 'value': float, 'dev_zone': int, 'dev_value': float, 'dynamic': str}], 'params_adv': [{'name': str, 'value': float, 'dev_zone': int, 'dev_value': float, 'dynamic': str}]}]}]}]}
    
    Замечания:
        - Сортировка параметров выполняется по комбинированному критерию: 
          - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.
    
    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> if len(state_patient)>0:
        >>>     for item in state_patient:
        >>>         # сортируем в каждом состоянии параметры. Объект state_patient модифицируется
        >>>         sortParamStr = interpreter.sortedParamsStateText_v2(state_patient[item])
        >>>     # сортируем состояния. объект state_patient модифицируется
        >>>     sortStatesTest = interpreter.sortedStatesText_v2(state_patient, debug=False)
    """
    
    if debug:
        print(f"\nsortedParamsStateText_v2: Begin\n")
        print(f"state['sort_params_text'] = {state.get('sort_params_text')}")
        print(f"type(state) = {type(state)}, \nstate = {state}")
        print(f"state.name = {state.name}")
        print(f"state.probality = {state.probality}")
        print(f"state.research_id = {state.research_id}")
        print(f"state.patient_id = {state.patient_id}")
        print(f"state.params_main = {state.params_main}, len(state.params_main) = {len(state.params_main)}")
        print(f"state.params_adv = {state.params_adv}, len(state.params_adv) = {len(state.params_adv)}")
        
        for k,v in state.items():
            print(f"k = {k}, v = {v}, type(v) = {type(v)}")
    
    # для формирования текста результата интерпретации по параметру
    system_str = '' # система
    organ_str = '' # органы
    state_str = state.name # состояние
    
    if len(state.params_main)>0:
        for k,v in state.params_main.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    else:
        for k,v in state.params_adv.items():
            organ_str = v.get('organ')
            system_str = v.get('system')
    
    if debug: print(f"system_str = {system_str}, organ_str = {organ_str}, state_str = {state_str}")
    
    # формируем текст результата
    sort_params_dict = dict()
    sort_params_dict[system_str] = dict()
    sort_params_dict[system_str][organ_str] = dict()
    
    # формируем отсортированный по dev_zone отклонения
    if 'params_main' in state.keys() and 'params_adv' in state.keys():
        params_main_sort = sorted(list(state['params_main'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_adv_sort = sorted(list(state['params_adv'].values()), key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
        params_mainadv_sort = params_main_sort + params_adv_sort
        
        if debug:
            params_mainadv_values = list(state['params_main'].values()) + list(state['params_adv'].values())
            params_all_sort = sorted(params_mainadv_values, key=lambda x: (x['dev_zone'], x['dev_value']), reverse=True)
            print(f"params_mainadv_values = {params_mainadv_values}, type(params_mainadv_values) = {type(params_mainadv_values)}")
            print(f"params_main_sort = {params_main_sort}, type(params_main_sort) = {type(params_main_sort)}")
            print(f"params_adv_sort = {params_adv_sort}, type(params_adv_sort) = {type(params_adv_sort)}")
            print(f"params_mainadv_sort = {params_mainadv_sort}, type(params_mainadv_sort) = {type(params_mainadv_sort)}")
            print(f"params_all_sort = {params_all_sort}, type(params_all_sort) = {type(params_all_sort)}")
        
    
    # сформируем отсортированные параметры в другом формате данных
    # перебирём отсортированные основные параметры
    params_main_list = list()
    i = 0
    while i<len(params_main_sort):
        param_sys = params_main_sort[i].get('system', None)
        param_org = params_main_sort[i].get('organ', None)
        param_name = params_main_sort[i].get('name', None)
        param_value = params_main_sort[i].get('value', None)
        param_dev_value = params_main_sort[i].get('dev_value', None)
        param_dev_zone = params_main_sort[i].get('dev_zone', None)
        param_dynamic = params_main_sort[i].get('dynamic', None)
        param_data = {'name':param_name, 'value':param_value, 'dev_zone':param_dev_zone, 'dev_value':param_dev_value, 'dynamic':param_dynamic }
        params_main_list.append(param_data)
        
        i += 1
    
    # перебирём отсортированные неосновные параметры
    params_adv_list = list()
    i = 0
    while i<len(params_adv_sort):
        param_sys = params_adv_sort[i].get('system', None)
        param_org = params_adv_sort[i].get('organ', None)
        param_name = params_adv_sort[i].get('name', None)
        param_value = params_adv_sort[i].get('value', None)
        param_dev_value = params_adv_sort[i].get('dev_value', None)
        param_dev_zone = params_adv_sort[i].get('dev_zone', None)
        param_dynamic = params_adv_sort[i].get('dynamic', None)
        param_data = {'name':param_name, 'value':param_value, 'dev_zone':param_dev_zone, 'dev_value':param_dev_value, 'dynamic':param_dynamic }
        params_adv_list.append(param_data)
        
        i += 1
    
    states_list = list()
    state_dic = {'name':state['name'], 'probality':state['probality'], 'params_main':params_main_list, 'params_adv':params_adv_list}
    states_list.append(state_dic)
    
    organ_list = list()
    organ_dic = {'name':organ_str, 'state':states_list}
    organ_list.append(organ_dic)
    
    system_list = list()
    system_dic = {'name':system_str, 'organ':organ_list}
    system_list.append(system_dic)
    
    sort_params_v2 = {'system':system_list}
    
    if debug:
        print(f"sort_params_v2 = {sort_params_v2}")
        print(f"sort_params_v2 = {json.dumps(sort_params_v2, indent=None, ensure_ascii=False, default=str)}")
    
    state['sort_params_v2'] = sort_params_v2
    state['sort_params_text_v2'] = str(sort_params_v2)
    # state['sort_params_text_v2'] = json.dumps(sort_params_v2, indent=None, ensure_ascii=False, default=str)
    
    if debug:
        print(f"state['sort_params_text'] = {state['sort_params_text']}")
        print(f"state['sort_params_text'] = {json.dumps(state['sort_params_text'], indent=2, ensure_ascii=False, default=str)}")
        print(f"\nsortedParamsStateText_v2: End\n")
    
    return sort_params_v2

# получить список отсортированных элементов словаря в порядке наиболее критичных по вероятности, так и по значениям отклонения основных и неосновных параметров от нормы
def getListSortedStates(states, debug=False):
    """
    Сортирует элементы-состояния словаря 'states'.
    
    Аргументы:
        states: DictAttr. Объект типа DictAttr хранящий данные по состояниям в виде следующей структуры:
        {
            state: DictAttr. Объект типа DictAttr содержащий данные состоянии, основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str         # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Структура словаря sort_params: {'система':{'орган':{'состояние:величина_критичности':{['отсортированный_список_наименований_отклонений:значение_отклонения']}}}}
                'sort_params_text': str,       # Строковое представление словаря sort_params
                'sort_params_v2': dict,        # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Аналог 'sort_params' но более подробный и структурированный
                'sort_params_text_v2': str,    # Строковое представление словаря sort_params_v2
            },
        }
    
    Результат:
        Возвращает список элементов list(DictAttr) словаря 'states', отсортированный по следующим критериям:
        - probality (по убыванию)
        - params_main.dev_zone и params_main.dev_value 
        (если params_main содержит данные, то сначала dev_zone, потом dev_value)
        - params_adv.dev_zone и params_adv.dev_value 
        (если params_adv содержит данные, то сначала dev_zone, потом dev_value)
    
    Пример:
        >>> states_patient = interpreter.getState(params_template, patientParams)
        >>> sorted_states_list = getListSortedStates(states_patient)
    """
    
    if debug:
        print(f"\ngetListSortedStates: Begin\n")
        
        for k,v in states.items():
            print(f"k = {k}, v = {v}, type(v) = {type(v)}")
            if type(v) is dict:
                print(f"\nv['sort_states_text'] = {v.get('sort_states_text')}")
                print(f"type(v) = {type(v)}, \nv = {v}")
                print(f"v.research_id = {v.research_id}")
                print(f"v.params_main = {v.params_main}, len(v.params_main) = {len(v.params_main)}")
                print(f"v.params_adv = {v.params_adv}, len(v.params_adv) = {len(v.params_adv)}\n")
    
    # подфункция получения значений ключей, по который выполняется сортировка
    def sorting_key(state):
        probality = state.get('probality', None)
        params_main = state.get('params_main')
        params_adv = state.get('params_adv')
        
        # сформируем кортеж для сортировки по нескольким критериям. Отсутствующие значения обозначим -inf
        dev_zone_main = float('-inf')
        dev_value_main = float('-inf')
        if params_main:
            for item in params_main.values():
                value = item.get("dev_zone", float('-inf'))
                if value>dev_zone_main:
                    dev_zone_main = value
                value = item.get("dev_value", float('-inf'))
                if value>dev_value_main:
                    dev_value_main = value
        
        dev_zone_adv = float('inf')
        dev_value_adv = float('inf')
        if params_adv:
            for item in params_main.values():
                value = item.get("dev_zone", float('-inf'))
                if value>dev_zone_adv:
                    dev_zone_adv = value
                value = item.get("dev_value", float('-inf'))
                if value>dev_value_adv:
                    dev_value_adv = value
        
        return (dev_zone_main, dev_value_main, probality, dev_zone_adv, dev_value_adv) # сортировка выполняется сначала по dev_zone_main, потом dev_value_main и т.д.
    
    filtered_states = (state for state in states.values() if isinstance(state, dict) and 'probality' in state)
    sorted_states = sorted(filtered_states, key=sorting_key, reverse=True)
    
    if debug:
        print(f"sorted_states = {sorted_states}")
        # print(f"states['sort_states_text'] = {states['sort_states_text']}")
        print(f"\ngetListSortedStates: End\n")
    
    return sorted_states

# в объекте словаря состояний, возвращённой функцией getState(), сформировать строку отсортированных состояний по их степени тяжести
def sortedStatesText(states, addStateValue=True, to_json=False, debug=False):
    """
    Сортирует состояния по их степени тяжести (выраженности и отклонению параметров от нормы) в объекте словаря состояний, возвращённой функцией getState().

    Аргументы:
        states: DictAttr. Объект типа DictAttr хранящий данные по состояниям в виде следующей структуры:
        {
            state: DictAttr. Объект типа DictAttr содержащий данные состоянии, основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str         # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Структура словаря sort_params: {'система':{'орган':{'состояние:величина_критичности':{['отсортированный_список_наименований_отклонений:значение_отклонения']}}}}
                'sort_params_text': str,       # Строковое представление словаря sort_params
                'sort_params_v2': dict,        # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Аналог 'sort_params' но более подробный и структурированный
                'sort_params_text_v2': str,    # Строковое представление словаря sort_params_v2
            },
            'sort_states': list(dict),         # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
            'sort_states_text': str            # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
        }
        addStateValue: bool. Признак необхомости к наименованию состояния через ':' добавлять значение её степени тяжести.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug: bool. Признак необходимости выводить в лог отладочные сообщения.

    Результат:
        В переданном объекте states типа DictAttr изменяются/добавляются поля:
         - 'sort_states' содержащее полученный объект списка осортированных состояний с отсортированными в них параметрами
         - 'sort_params_text' содержащее строковое представление словаря sort_states
        Структура данных в поле 'sort_states':
        [{'Наименование_системы':{'Наименование_органа':{'Наименование_состояния:Величина_критичности_состояния':['Наименование_параметра:Величина_отклонения',]}}},]
        
        При addStateValue=True к каждому параметру добавляется значение зоны, в которую отклонился параметр.
        Допустимые значения зоны отклонения: 2 - зона умеренного отклонения, 3 - выраженное отклонение, 4 - критическое отклонение.

    Замечания:
        - Сортировка параметров выполняется по комбинированному критерию:
          - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.

    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> sortStatesTest = interpreter.sortedStatesText(state_patient, addStateValue=True)
        >>> print(sortStatesTest)
        >>> print(state_patient.sortStatesTest)
        [{'Свертывающая система крови': {None: {'Гипокоагуляция:1.17': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}, ...]
        [{'Свертывающая система крови': {None: {'Гипокоагуляция:1.17': ['Повышение уровня МНО:2', 'Удлинение протромбинового времени:2']}}}, ...]
    """
    
    if debug:
        print(f"\nsortedStatesText: Begin\n")
        print(f"len(states) = {len(states)}")
        for k,v in states.items():
            print(f"k = {k}, v = {v}, type(v) = {type(v)}")
            
            print(f"\nv['sort_states_text'] = {v.get('sort_states_text')}")
            print(f"type(v) = {type(v)}, \nv = {v}")
            print(f"v.research_id = {v.research_id}")
            print(f"v.params_main = {v.params_main}, len(v.params_main) = {len(v.params_main)}")
            print(f"v.params_adv = {v.params_adv}, len(v.params_adv) = {len(v.params_adv)}\n")
    
    # для формирования текста результата интерпретации по параметру
    system_str = None # система
    organ_str = None # органы
    state_str = None # состояние
    params_str = None # отсортированный список параметров
    
    sort_states_list = list()
    
    sortedStates = getListSortedStates(states, debug) # получим список состояний отсортированных по тяжести
    if debug: print(f"type(sortedStates) = {type(sortedStates)}, \nsortedStates = {sortedStates}")
    sortedStatesTest_json = json.dumps(sortedStates, indent=2, ensure_ascii=False, default=str)
    if debug: print(f"type(sortedStatesTest_json) = {type(sortedStatesTest_json)}, \nsortedStatesTest_json = {sortedStatesTest_json}")
    
    for item in sortedStates:
        if debug: print(f"item = {item}")
        if addStateValue:
            state_str = ':'.join([str(item.name), str(round(toFloat(item.probality), 2))])
        else:
            state_str = item.name
        
        if 'params_main' in item and item.params_main and len(item.params_main):
            system_str, organ_str = next(((v.get('system', None), v.get('organ', None)) for v in item.params_main.values()), (None,None))
        
        elif 'params_adv' in item and item.params_adv and len(item.params_adv):
            system_str, organ_str = next(((v.get('system', None), v.get('organ', None)) for v in item.params_adv.values()), (None,None))
        
        if debug: print(f"state_str = {state_str}, system_str = {system_str}, organ_str = {organ_str}")
        sort_params = item.get('sort_params_text', None)
        if debug:
            print(f"type(sort_params) = {type(sort_params)}")
            print(f"type(eval(sort_params)) = {type(eval(sort_params))}")
            print(f"type(eval(sort_params))==dict = {type(eval(sort_params))==dict}")
        
        sort_params_dict = dict()
        sort_params_list = list()
        if type(eval(sort_params))==dict:
            sort_params_dict = eval(sort_params)
            if debug: print(f"len(sort_params_dict) = {len(sort_params_dict)}")
            valList = None
            if len(sort_params_dict)>0:
                valList = next( v3 for v3 in next( v2 for v2 in next( v1 for v1 in sort_params_dict.values() ).values() ).values() )
            if debug: print(f"valList = {valList}, type(valList) = {type(valList)}")
            if type(valList)==list:
                sort_params_list = valList
        if debug: print(f"sort_params_list = {sort_params_list}, \ntype(sort_params_list) = {type(sort_params_list)}")
        
        sort_params_dict = {system_str:{organ_str:{state_str:sort_params_list}}}
        if debug: print(f"sort_params_dict = {sort_params_dict}, \ntype(sort_params_dict) = {type(sort_params_dict)}")
        
        sort_states_list.append(sort_params_dict)
    
    states['sort_states'] = sort_states_list
    if not to_json:
        states['sort_states_text'] = str(sort_states_list)
    else:
        states['sort_states_text'] = json.dumps(sort_states_list, indent=None, ensure_ascii=False, default=str)
    
    if debug:
        # print(f"sort_states_list = {sort_states_list}")
        print(f"states['sort_states_text'] = {states['sort_states_text']}")
        print(f"\nsortedStatesText: End\n")
    
    return sort_states_list

# в объекте словаря состояний, возвращённой функцией getState(), сформировать строку отсортированных состояний по их степени тяжести
def sortedStatesText_v2(states, debug=False):
    """
    Сортирует состояния по их степени тяжести (выраженности и отклонению параметров от нормы) в объекте словаря состояний, возвращённой функцией getState().

    Аргументы:
        states: DictAttr. Объект типа DictAttr хранящий данные по состояниям в виде следующей структуры:
        {
            state: DictAttr. Объект типа DictAttr содержащий данные состоянии, основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str         # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                'sort_params_text': str,       # Строковое представление словаря sort_params
                'sort_params_v2': dict,        # Словарь состояния, у которого основные и неосновные параметры отклонений отсортированы по выраженности и отклонению от нормы
                                               # Аналог 'sort_params' но более подробный и структурированный
                'sort_params_text_v2': str,    # Строковое представление словаря sort_params_v2
            },
            'sort_states': list(dict),         # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
            'sort_states_text': str,           # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
            'sort_states_v2': list(dict),      # Список отсортированных по значению критичности словарей состояний. Записывается в поле raw_data таблицы Conclusion
            'sort_states_text_v2': str         # Строковое представление списка словарей состояний sort_states. Записывается в поле inter_results таблицы Conclusion
        }
        addStateValue: bool. Признак необхомости к наименованию состояния через ':' добавлять значение её степени тяжести.
        debug: bool. Признак необходимости выводить в лог отладочные сообщения.

    Результат:
        В переданном объекте states типа DictAttr изменяются/добавляются поля:
         - 'sort_states_v2' содержащее полученный объект списка осортированных состояний с отсортированными в них параметрами
         - 'sort_states_text_v2' содержащее строковое представление словаря sort_states_v2
        Структура данных в поле 'sort_states_v2':
        {'system': [{'name': str, 'organ': [{'name': str, 'state': [{'name': 'str', 'probality': float, 'params_main': [{'name': str, 'value': float, 'dev_zone': int, 'dev_value': float, 'dynamic': str}], 'params_adv': [{'name': str, 'value': float, 'dev_zone': int, 'dev_value': float, 'dynamic': str}]}]}]}]}

    Замечания:
        - Сортировка параметров выполняется по комбинированному критерию:
          - основные параметры в приоритете, затем — неосновные, с учётом 'dev_zone' и 'dev_value'.

    Пример:
        >>> state_patient = interpreter.getState(params_template, patientParams)
        >>> sortStatesTest2 = interpreter.sortedStatesText_v2(state_patient)
        >>> print(sortStatesTest2)
        >>> print(state_patient.sortStatesTest2)
        {'system': [{'name': 'Свертывающая система крови', 'organ': [{'name': None, 'state': [{'name': 'Гипокоагуляция', 'probality': 1.17, 'params_main': [{'name': 'МНО', 'value': 1.17, 'dev_zone': 2, 'dev_value': 1.17, 'dynamic': 'Повышение уровня МНО'}], 'params_adv': [{'name': 'Протромбиновое время', 'value': 14.3, 'dev_zone': 2, 'dev_value': 1.1485943775100402, 'dynamic': 'Удлинение протромбинового времени'}]}]}]}, {'name': 'Свертывающая система крови', 'organ': [{'name': None, 'state': [{'name': 'Активация свертывающей и фибринолитической  системы', 'probality': 34.64, 'params_main': [], 'params_adv': [{'name': 'Д-димер', 'value': 8.66, 'dev_zone': 4, 'dev_value': 34.64, 'dynamic': 'Повышение уровня Д-димера'}]}]}]}, {'name': 'Иммунная система', 'organ': [{'name': None, 'state': [{'name': 'Воспалительный ответ', 'probality': 1.6551724137931034, 'params_main': [], 'params_adv': [{'name': 'Фибриноген', 'value': 4.8, 'dev_zone': 2, 'dev_value': 1.6551724137931034, 'dynamic': 'Повышение уровня фибриногена'}]}]}]}]}
        {'system': [{'name': 'Свертывающая система крови', 'organ': [{'name': None, 'state': [{'name': 'Гипокоагуляция', 'probality': 1.17, 'params_main': [{'name': 'МНО', 'value': 1.17, 'dev_zone': 2, 'dev_value': 1.17, 'dynamic': 'Повышение уровня МНО'}], 'params_adv': [{'name': 'Протромбиновое время', 'value': 14.3, 'dev_zone': 2, 'dev_value': 1.1485943775100402, 'dynamic': 'Удлинение протромбинового времени'}]}]}]}, {'name': 'Свертывающая система крови', 'organ': [{'name': None, 'state': [{'name': 'Активация свертывающей и фибринолитической  системы', 'probality': 34.64, 'params_main': [], 'params_adv': [{'name': 'Д-димер', 'value': 8.66, 'dev_zone': 4, 'dev_value': 34.64, 'dynamic': 'Повышение уровня Д-димера'}]}]}]}, {'name': 'Иммунная система', 'organ': [{'name': None, 'state': [{'name': 'Воспалительный ответ', 'probality': 1.6551724137931034, 'params_main': [], 'params_adv': [{'name': 'Фибриноген', 'value': 4.8, 'dev_zone': 2, 'dev_value': 1.6551724137931034, 'dynamic': 'Повышение уровня фибриногена'}]}]}]}]}
    """
    
    if debug:
        print(f"\nsortedStatesText_v2: Begin\n")
        print(f"len(states) = {len(states)}")
        for k,v in states.items():
            print(f"k = {k}, v = {v}, type(v) = {type(v)}")
            if type(v) is dict:
                print(f"v['sort_states_text'] = {v.get('sort_states_text')}")
                print(f"type(v) = {type(v)}, \nv = {v}")
                print(f"v.research_id = {v.research_id}")
                print(f"v.params_main = {v.params_main}, len(v.params_main) = {len(v.params_main)}")
                print(f"v.params_adv = {v.params_adv}, len(v.params_adv) = {len(v.params_adv)}\n")
    
    # для формирования текста результата интерпретации по параметру
    system_str = None # система
    organ_str = None # органы
    state_str = None # состояние
    params_str = None # отсортированный список параметров
    
    sort_states_list = list()
    states_json = json.dumps(states, indent=2, ensure_ascii=False, default=str)
    if debug:
        print(f"до сортировки:")
        print(f"states = {states}")
        print(f"states_json = {states_json}")
        
    sortedStates = getListSortedStates(states, debug) # получим список состояний отсортированных по тяжести
    sortedStatesTest_json = json.dumps(sortedStates, indent=2, ensure_ascii=False, default=str)
    if debug:
        print(f"после сортировки:")
        print(f"type(sortedStates) = {type(sortedStates)}, \nsortedStates = {sortedStates}")
        print(f"type(sortedStatesTest_json) = {type(sortedStatesTest_json)}, \nsortedStatesTest_json = {sortedStatesTest_json}")
    
    # перебираем отсортированные состояния для формирования строки отчёта
    if debug: print(f"Перебираем отсортированные состояния")
    
    for item in sortedStates:
        if debug: print(f"item = {item}")
        ''' # сформируем строковое наименование состояния и значение её отклонения от нормы
        if addStateValue:
            state_str = ':'.join([str(item.name), str(round(toFloat(item.probality), 2))])
        else:
            state_str = item.name
        
        # получим из первого основного параметра строковые наименования системы и органа
        if 'params_main' in item and item.params_main and len(item.params_main):
            system_str, organ_str = next( ( (v.get('system', None), v.get('organ', None)) for v in item.params_main.values() ), (None,None) )
        
        # получим из первого неосновного параметра строковые наименования системы и органа
        elif 'params_adv' in item and item.params_adv and len(item.params_adv):
            system_str, organ_str = next(((v.get('system', None), v.get('organ', None)) for v in item.params_adv.values()), (None,None))
        
        if debug: print(f"state_str = {state_str}, system_str = {system_str}, organ_str = {organ_str}") '''
        
        sort_params = item.get('sort_params_text_v2', None)
        if debug:
            print(f"type(sort_params) = {type(sort_params)}")
            print(f"type(eval(sort_params)) = {type(eval(sort_params))}")
            print(f"type(eval(sort_params))==dict = {type(eval(sort_params))==dict}")
        
        sort_params_dict = dict()
        
        # sort_params_list = list()
        
        if type(eval(sort_params))==dict:
            sort_params_dict = eval(sort_params)
            
            if debug:
                print(f"преобразовали sort_params_text_v2 в sort_params_dict")
                print(f"type(sort_params_dict) = {type(sort_params_dict)}")
                print(f"len(sort_params_dict) = {len(sort_params_dict)}")
                print(f"sort_params_dict = {sort_params_dict}")
            
        
        sort_states_list.extend(sort_params_dict.get('system', None))
    
    sort_states_dict = {'system':sort_states_list }
    
    states['sort_states_v2'] = sort_states_dict
    states['sort_states_text_v2'] = str(sort_states_dict)
    
    if debug:
        # print(f"sort_states_list = {sort_states_list}")
        print(f"states['sort_states_v2'] = {states['sort_states_v2']}")
        print(f"states['sort_states_v2'] = {json.dumps(states['sort_states_v2'], indent=2, ensure_ascii=False, default=str)}")
        print(f"\nsortedStatesText_v2: End\n")
    
    return sort_states_dict



# вспомогательные функции обработки данных объекта состояния
# функция разбивает текст с измеренными параметрами анализов на отдельные наименования анализова и их значения
# учитывается два разделителя ';' и ' ' в значениях параметров
def parsParamsText(strDatRsch:str, sepLine:str, debug=False):
    """
    Разбивает текст с измеренными параметрами анализов на отдельные наименования анализова и их значения

    Аргументы:
        strDatRsch:str. Строка данных, содержащая наименования параметров, и их значения.
        sepLine:str. Строка разделителя данных параметров друг от друга

    Результат:
    Возвращает словарь типа DictAttr с атрибутами в качестве параметров.

    Пример:
        >>> # считываем с базы список исследований
        >>> researchs = database.get_researchs(param_db)
        >>> strDatRschList = list()
        >>> i = 0
        >>> while i<len(researchs):
        >>>     strDatRschList.append(researchs[i]['data'])
        >>>     i += 1
        >>> 
        >>> # формируем список словарей записей исследований используя функцию parsParamsText_v2()")
        >>> patientParams = list()
        >>> i = 0
        >>> while i<len(strDatRschList):
        >>>     paramsDict = interpreter.parsParamsText_v2(strDatRschList[i], '\r\n', debug=False)
        >>>     patientParams.append(paramsDict)
        >>>     i += 1
    """
    if debug:
        print(f"parsParamsText_v2(): Begin")
    
    params = DictAttr()
    for line in strDatRsch.split(sepLine):
        if debug: print(f"line = {line}")
        
        sep = [':']
        temp = split_by_separators(line, sep, 1)
        if debug: print(f"temp = {temp}")
        
        if len(temp)>0:
            sep = [';',' ']
            temp1 = split_by_separators(temp[1], sep)
            if debug: print(f"temp = {temp1}")
            
            iVal, Val = find_number_with_index(temp1)
            if debug: print(f"iVal, Val  = {iVal, Val}")
        
        nameParam = clean_identifier(temp[0])
        
        params.setdefault(nameParam, DictAttr())
        params[nameParam].setdefault('name', temp[0])
        if iVal is not None:
            params[nameParam].setdefault('value', toFloat(temp1[iVal]))
        else:
            params[nameParam].setdefault('value', None)
    
    if debug:
        print(f"params = {params}")
        print(f"parsParamsText_v2(): End\n")
    return params

# извлекает из 'data' словаря с данными иследования данные, и формирует словарь с атрибутами из данных параметров
def buildResearchParams(data_research:dict, debug=False):
    """
    Извлекает из 'data' словаря с данными иследования данные параметров, и формирует словарь с атрибутами из данных параметров.

    Аргументы:
        data_research (dict): Словарь данных исследования пациента из таблицы 'research' базы данных.
        debug (bool, optional): Режим отладки. Если True, выводит промежуточные сообщения о состоянии выполнения. По умолчанию False.

    Результат:
        DictAttr: Список с атрибутами, где каждый словарь представляет запись о пациенте с ключами, соответствующими названиям столбцов в таблице Patient.
                  Структура возвращаемого словаря с атрибутами:
                  { str: {'name': str, 'value': float, 'research_id': int, 'patient_id': int, 'date': datetime, 'gender': str, 'age': int}, }
        Возвращает None, если не удается получить данные.

    Пример:
        # считываем с базы список исследований
        researchs = database.get_researchs(param_db)
        patientParamsList = list()
        # извлечём из списка иследований лабораторные данные
        i = 0
        while i<len(researchs):
            patientParamsList.append(interpreter.buildResearchParams(researchs[i], debug=False))
            i += 1
    """
    if debug:
        print(f"\buildResearchParams: Begin")
        for item in data_research:
            print(f"data_research: item = {item}, data_research.get(item) = {data_research.get(item)}")
    
    result = None
    if 'data' in data_research:
        patientParams = DictAttr()
        patientParams = parsParamsText(data_research.get('data'), '\r\n', debug)
        
        # идентификатор исследования
        if debug: print(f"data_research.get('id') = {data_research.get('id')}")
        id_research = data_research.get('id', None)
        id_patient = data_research.get('patient_id', None)
        date = data_research.get('date', None)
        
        # пол пациента
        if 'gender' in data_research:
            if debug: print(f"data_research.get('gender') = {data_research.get('gender')}")
            gender = data_research.get('gender', None)
        
        # определим возраст пациента по дате его рождения и
        if 'date_birth' in data_research:
            
            age = None
            if debug: print(f"age = {age}, age is None = {age is None}")
            date_birth = data_research.get('date_birth')
            # дате исследования
            if 'date' in data_research:
                date_research = data_research.get('date')
                
                if debug:
                    print(f"date_birth = {date_birth}, type(date_birth) = {type(date_birth)}")
                    print(f"date_research = {date_research}, type(date_research) = {type(date_research)}")
                age = getAge(date_birth, date_research)
            
            # или текущей дате
            else:
                date_now = datetime.now()
                if debug: print(f"data_research.get('date_birth') = {date_birth}, datetime.now() = {date_now}")
                age = getAge(data_research.get('date_birth'))
                
            if debug: print(f"age = {age}, age is None = {age is None}")
        
        for item in patientParams:
            if debug: print(f"item = {item}, patientParams.get(item) = {patientParams.get(item)}")
            patientParams[item].setdefault('research_id', id_research)
            patientParams[item].setdefault('patient_id', id_patient)
            patientParams[item].setdefault('date', date)
            patientParams[item].setdefault('gender', gender)
            patientParams[item].setdefault('age', age)
            
        
        result = patientParams
    else:
        print(f"Неверный формат данных исследования пациента!")
    
    if debug: print(f"buildResearchParams: End\n")
    return result

# получить идентификаторы исследования и пациента из объекта состояния
def getResearchID_PatientID(state, debug=False):
    """
    Возвращает идентификаторы исследования и пациента из заданного объекта состояния.
    
    Аргументы:
        state: DictAttr. Объект типа DictAttr содержащий данные о основных и неосновных параметрах по которым было определено состояние:
            {
                'research_id': int,            # Идентификатор исследования
                'patient_id': int,             # Идентификатор пациента
                'name': str,                   # Наименование состояния
                'probality': float,            # Вероятность состояния
                'params_main': dict,           # Основные параметры
                    # Каждый параметр: {
                    #   "system": str,         # Наименование Системы
                    #   "organ": str,          # Наименование Органа
                    #   "name": str,           # Наименование параметра
                    #   "value": float,        # Значение параметра
                    #   "gender": str,         # Пол
                    #   "age": int,            # Возраст
                    #   "dev_zone": int,       # Зона в которую отклонился параметр от зоны нормы
                    #   "dev_value": float,    # Величина степени отклонения праметра от нормы
                    #   "dynamic": str,        # Строковое наименование изменения состояния
                    # },
                'params_adv': dict,            # Неосновные параметры. Структура как 'params_main'
                'sort_params': dict,           # Словарь состояний с отсортированными параметрами
                'sort_params_text': str        # Строковое преставление словаря sort_params
            }
        addParamValue (bool, optional): bool. Если True, то в результат будет добавлено числовое значение зоны в которую отклонился параметр. По умолчанию True.
        to_json (bool, optional): Если True, то строка результата будет формироваться как json-строка. По умолчанию False - результат формируется как строка.
        debug (bool, optional): Если True, выводит отладочную информацию. По умолчанию False.
    
    Результат:
        Возвращает идентификаторы исследования и пациента или None для обоих
         
    Пример:
        >>> id_research, id_patient = getResearchID_PatientID(state_patient)
        >>> print(f"id_research, id_patient = {id_research, id_patient}")
        id_research, id_patient = 8, 4
    """
    if debug:
        print(f"getResearchID_PatientID: Begin")
        print(f"state = {json.dumps(state, indent=2, ensure_ascii=False, default=str)}")
    # определим идентификаторы исследования и пациента для передачи в функцию save_conclusion_v2()
    id_research, id_patient = next( ((v.get('research_id', None), v.get('patient_id', None)) for v in state.values()), (None, None) )
    if debug:
        print(f"getResearchID_PatientID: End")
        print(f"id_research = {id_research}, id_patient = {id_patient}")
    return id_research, id_patient








