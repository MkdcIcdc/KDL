import re # для функции clean_identifier()
import datetime
import math # нужны inf литерал бесконечности и парочка других функций типа math.round

# транслитерация русских букв в латиницу
def translit(text: str) -> str:
    table = {
        'а':'a',  'б':'b',  'в':'v',  'г':'g',  'д':'d',
        'е':'e',  'ё':'yo','ж':'zh', 'з':'z',  'и':'i',
        'й':'y',  'к':'k',  'л':'l',  'м':'m',  'н':'n',
        'о':'o',  'п':'p',  'р':'r',  'с':'s',  'т':'t',
        'у':'u',  'ф':'f',  'х':'h',  'ц':'c',  'ч':'ch',
        'ш':'sh', 'щ':'sch','ъ':'',   'ы':'y',  'ь':'',
        'э':'e',  'ю':'yu', 'я':'ya'
    }
    result = []
    for ch in text:
        lower = ch.lower()
        if lower in table:
            rep = table[lower]
            # сохраняем регистр: если оригинал был заглавным, ставим первую букву заглавной
            if ch.isupper():
                rep = rep.capitalize()
            result.append(rep)
        else:
            result.append(ch)
    return ''.join(result)

# разбить строку используя список разделителей
def split_by_separators(text, separators, maxsplit=0):
    """
    Разбивает строку по списку разделителей.

    Аргументы:
        text: исходная строка
        separators: список строк-разделителей
        maxsplit: максимальное количество разбиений (-1 = без ограничений)

    Результат:
        Список подстрок
    """
    if not separators:
        return [text]
    
    # Если среди разделителей есть None — добавляем \s+ (любые пробельные символы)
    if None in separators:
        sep = [s for s in separators if s is not None] + [r'\s+']
    else:
        sep = [re.escape(s) for s in separators]
    
    pattern = '|'.join(sep)
    txt_list = re.split(pattern, text, 0)
    return re.split(pattern, text, maxsplit)

# привести строку к виду, пригодному для имени атрибута Python.
def clean_identifier(name: str) -> str:
    name = translit(name ) # транслитерация

    # заменяем все символы, которые не являются буквой/цифрой/_, на подчёркивание, используя регулярку.
    name = re.sub(r'[^A-Za-z0-9_]', '_', name)

    # если имя начинается с цифры — добавляем префикс (Python не позволяет)
    if re.match(r'^\d', name):
        name = f'id_{name}'

    return name

# преобразовать строковое представление числа с запятой в качестве разделителя целой и дробной части
def toFloat(value, inf=None):
    """
    Корректно преобразовывает представление числа в виде строки с запятой в качестве разделителя целой и дробной части или None как None
    value : Объект типа int, float, str или Nonetype
    inf : Направление бесконечности. При Value = None и положительном значении inf возвратит float('inf'), при отрицательном значении inf возвратит -float('inf')
    """
    if value is None and (inf is None or inf==0):
        return None
    if value is None and inf>0:
        return float('inf')
    if value is None and inf<0:
        return -float('inf')
    if isinstance(value, (int, float)):
        return float(value)
    
    # наименование положительно заменяем на +бесконечность
    if str(value).lower().find("positiv")>=0:
        return float('inf')
    if str(value).lower().find("положит")>=0:
        return float('inf')
    # наименование отрицательно заменяем на -бесконечность
    if str(value).lower().find("negativ")>=0:
        return -float('inf')
    elif str(value).lower().find("отрицат")>=0:
        return -float('inf')
    # убираем пробелы и меняем запятую на точку
    else:
        value = str(value).replace(',', '.')
    
    return float(value)

# получить минимальное значение в списке игнорируя значения None
def getMin(data):
    """
    Находит минимальное значение в списке, игнорируя значения None.
    
    Аргументы:
        data: Список чисел (float или int), содержащий возможно None.
    
    Результат:
        Минимальное значение в списке, исключая None. Возвращает None, если список не содержит ни одного числа.
    """
    valid_data = [x for x in data if x is not None]
    if not valid_data:
        return None
    return min(valid_data)

# получить максимальное значение в списке игнорируя значения None
def getMax(data):
    """
    Находит максимальное значение в списке, игнорируя значения None.
    
    Аргументы:
        data: Список чисел (float или int), содержащий возможно None.
    
    Результат:
        Максимальное значение в списке, исключая None.  Возвращает None, если список не содержит ни одного числа.
    """
    valid_data = [x for x in data if x is not None]
    if not valid_data:
        return None
    return max(valid_data)

# определить первый индекс в списке, по которому хранится числовое значение
def find_number_with_index(lst, start=0):
    """
    Ищет первый элемент в списке, начиная с индекса `start`, который является:
      - числом (int/float, но не bool),
      - или строкой, представляющей число (с точкой или запятой как разделителем).
    
    Возвращает кортеж (индекс, значение) первого найденного числа.
    Если ничего не найдено — возвращает (None, None).
    
    :param lst: список элементов
    :param start: индекс, с которого начинать поиск (по умолчанию 0)
    :return: (индекс, значение) или (None, None)
    """
    if start<0:
        start = max(0, len(lst) + start)  # поддержка отрицательных индексов, как в Python
    
    for i in range(start, len(lst)):
        item = lst[i]
        
        # Проверка на настоящие числа (исключая bool)
        if isinstance(item, (int, float)) and not isinstance(item, bool):
            return i, item
        
        # Проверка на строку, которая может быть числом
        if isinstance(item, str):
            normalized = item.replace(',', '.')
            try:
                num = float(normalized)
                return i, num  # или return i, item — если нужно вернуть исходную строку
            except ValueError:
                continue  # Не число — идём дальше
    
    return None, None

# проверить является ли объект итерируемым
def is_iterable(obj):
    try:
        iter(obj)
        return True
    except TypeError:
        return False

# определить направление смещения интервала зон отклонения от зоны нормы
def getDirectFromBounds_v1(intervals: dict, norm_key: str):
    """
    Определяет направление отклонения по расположению границ интервалов.
    Учитывает: пустые интервалы, None, ±inf.
    """
    if norm_key not in intervals:
        return 'unknown'
    
    norm = intervals[norm_key]
    if not hasattr(norm, 'lower') or not hasattr(norm, 'upper') or norm.empty:
        return 'unknown'
    
    norm_lower = norm.lower
    norm_upper = norm.upper
    
    # Проверка на None или inf у нормы
    if norm_lower is None or norm_upper is None or \
       math.isinf(norm_lower) or math.isinf(norm_upper):
        return 'unknown'
    
    left_mass = 0.0
    right_mass = 0.0
    
    for key, val in intervals.items():
        if key == norm_key:
            continue
        if hasattr(val, 'empty') and val.empty:
            continue
        if not hasattr(val, 'lower') or not hasattr(val, 'upper'):
            continue

        for bound in [val.lower, val.upper]:
            if bound is None or math.isinf(bound):
                # Пропускаем None и ±inf — они не несут смысла для смещения
                continue
            if bound < norm_lower:
                left_mass += abs(bound - norm_lower)
            elif bound > norm_upper:
                right_mass += abs(bound - norm_upper)
            # внутри нормы — не учитываем
    
    # Защита от inf в накопленных массах
    if math.isinf(left_mass):
        left_mass = float('inf')
    if math.isinf(right_mass):
        right_mass = float('inf')
    
    # Нормализуем: если одна из масс inf, а другая — конечна, считаем, что inf "перевешивает"
    if left_mass > 0 and right_mass == 0:
        return 'left'
    elif right_mass > 0 and left_mass == 0:
        return 'right'
    elif left_mass > 0 and right_mass > 0:
        return 'both'
    else:
        return 'unknown'

# определить, увеличивается или уменьшается тенденция значений в последовательности
def getDirectInList_v1(sequence:list):
    """
    Определить, увеличивается или уменьшается тенденция значений в последовательности
    
    Аргументы:
        sequence:(list) - список значений
    
    Результат:
        Возвращает:
            положительное число в случае если значения увеличиваются;
            отрицательное - тенденция уменьшается;
            нуль - направление отсутствует
    """
    valid_data = [x for x in sequence if x is not None]
    direct = 0
    i = 0
    # print(f"getDirectInList_v1: len(valid_data) = {len(valid_data)}")
    while i<len(valid_data)-1:
        # print(f"getDirectInList_v1: i = {i}, valid_data[{i}+1] = {valid_data[i+1]}, valid_data[{i}] = {valid_data[i]}")
        # val1 = 0 if sequence[i]==None else sequence[i]
        # val2 = 0 if sequence[i+1]==None else sequence[i+1]
        # val3 = val2 - val1
        direct += valid_data[i+1] - valid_data[i]
        # print(f"getDirectInList_v1: direct = {direct}")
        i += 1
    
    # print(f"getDirectInList_v1: return direct = {direct}")
    return direct

# преобразовать строку даты и времени в datetime-объект
def parse_date(s):
    # пробуем несколько форматов
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            pass
    raise ValueError(f"Не удалось преобразовать строку даты и времени: {s}")

# определить возраст относительно переданного времени
def getAge(date_birth, date_now=None):
    # print(f"date_birth = {date_birth}, type(date_birth) = {type(date_birth)}, isinstance(date_birth, (datetime.datetime, datetime.date)) = {isinstance(date_birth, (datetime.datetime, datetime.date))}")
    # print(f"date_now = {date_now}, type(date_now) = {type(date_now)}, isinstance(date_now, (datetime.datetime, datetime.date)) = {isinstance(date_now, (datetime.datetime, datetime.date))}")
    # проверяем, является ли date_birth уже объектом datetime
    if isinstance(date_birth, (datetime.datetime, datetime.date)):
        birth_date = date_birth
    elif isinstance(date_birth, str):
        birth_date = parse_date(date_birth)
    else:
        # генерируем исключение по неправильному типу данных
        raise TypeError(f"Неверный тип входных данных. Ожидается datetime или строка, получено: {type(date_birth)}")
    
    # аналогично для date_now
    if date_now is None:
        now = datetime.now()
    elif isinstance(date_now, (datetime.datetime, datetime.date)):
        now = date_now
    elif isinstance(date_now, str):
        now = parse_date(date_now)
    else:
        # генерируем исключение по неправильному типу данных
        raise TypeError(f"Неверный тип входных данных. Ожидается datetime, строка или None, получено: {type(date_now)}")
    
    # проверяем, был ли уже день рождения в этом году
    # если текущий месяц и день меньше, чем у дня рождения, то ещё не было
    age = now.year - birth_date.year
    if (now.month, now.day) < (birth_date.month, birth_date.day):
        age -= 1
    
    return age
